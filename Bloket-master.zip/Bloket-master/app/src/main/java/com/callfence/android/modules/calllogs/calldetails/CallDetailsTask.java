package com.callfence.android.modules.calllogs.calldetails;

import android.annotation.SuppressLint;
import android.content.ContentProviderClient;
import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.os.AsyncTask;
import android.provider.CallLog;
import android.util.Log;

import com.callfence.android.modules.calllogs.CallLogDataPair;
import com.callfence.android.utilities.helpers.database.DatabaseHelper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class CallDetailsTask extends AsyncTask<Void, Void, Void> {

    private ArrayList<CallLogDataPair> mCallList;
    private CallLogResponse mResponse;
    @SuppressLint("StaticFieldLeak")
    private Context mContext;
    private String mPhoneNumber;
    private int mCallType, mCallCount;
    private long mRawDate;

    public CallDetailsTask(Context mContext, int mCallType, String mPhoneNumber, long mRawDate, int mCallCount, CallLogResponse mResponse) {
        this.mContext = mContext;
        this.mCallType = mCallType;
        this.mPhoneNumber = mPhoneNumber;
        this.mRawDate = mRawDate;
        this.mCallCount = mCallCount;
        this.mResponse = mResponse;
    }

    @SuppressWarnings("ConstantConditions")
    @Override
    protected Void doInBackground(Void... mVoid) {
        try {

            // Initialize contact list
            mCallList = new ArrayList<>();

            // Fetch block log
            if (mCallType == CallLog.Calls.BLOCKED_TYPE) {
                DatabaseHelper mDbHelper = new DatabaseHelper(mContext);
                mCallList = mDbHelper.getBlockLogsSlab(mPhoneNumber, mRawDate, mCallCount);
                return null;
            }

            // Fetch call log
            ContentResolver mContactResolver = mContext.getContentResolver();
            @SuppressLint("Recycle") ContentProviderClient mProviderClient = mContactResolver.acquireContentProviderClient(CallLog.Calls.CONTENT_URI);
            @SuppressLint("Recycle") Cursor mCursor = mProviderClient.query(
                    CallLog.Calls.CONTENT_URI,
                    new String[]{
                            CallLog.Calls._ID,
                            CallLog.Calls.TYPE,
                            CallLog.Calls.CACHED_NAME,
                            CallLog.Calls.CACHED_PHOTO_URI,
                            CallLog.Calls.NUMBER,
                            CallLog.Calls.DATE,
                            CallLog.Calls.DURATION},
                    CallLog.Calls.NUMBER + " = ? AND " + CallLog.Calls.DATE + " <= " + mRawDate,
                    new String[]{mPhoneNumber},
                    CallLog.Calls.DATE + " DESC LIMIT " + mCallCount);

            // Add data to call log list
            if (mCursor != null && mCursor.getCount() > 0) {
                Date mRawDate;
                SimpleDateFormat mDateFormat = new SimpleDateFormat("EEEE, MMM dd, hh:mm a", Locale.getDefault());
                while (mCursor.moveToNext()) {
                    mRawDate = new Date(Long.valueOf(mCursor.getString(5)));
                    mCallList.add(new CallLogDataPair(
                            mCursor.getString(0),
                            mCursor.getInt(1),
                            mCursor.getString(2),
                            mCursor.getString(3),
                            mCursor.getString(4),
                            mDateFormat.format(mRawDate),
                            mCursor.getString(6),
                            1,
                            mRawDate));
                }
            }
            mCursor.close();
            mProviderClient.close();
        } catch (
                Exception mException) {
            Log.d("BLOKET_LOGS", "ContactPickerTask: Error fetching contacts for contact picker, Details: " + mException.toString());
        }
        return null;
    }

    @Override
    protected void onPostExecute(Void mVoid) {
        mResponse.onTaskCompletion(mCallList);
    }

    public interface CallLogResponse {

        void onTaskCompletion(ArrayList<CallLogDataPair> mCallList);

    }
}