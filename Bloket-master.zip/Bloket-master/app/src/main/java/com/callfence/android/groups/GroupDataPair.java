package com.callfence.android.groups;

public class GroupDataPair {

    private String mGroupId, mGroupName;
    private boolean mSelected;

    public GroupDataPair(String mGroupId, String mGroupName) {
        this.mGroupId = mGroupId;
        this.mGroupName = mGroupName;
    }

    public String getGroupId() {
        return mGroupId;
    }

    void setGroupId(String mGroupId) {
        this.mGroupId = mGroupId;
    }

    public String getGroupName() {
        return mGroupName;
    }

    void setGroupName(String mGroupName) {
        this.mGroupName = mGroupName;
    }

    public boolean isSelected() {
        return mSelected;
    }

    public void setSelected(boolean mSelected) {
        this.mSelected = mSelected;
    }
}