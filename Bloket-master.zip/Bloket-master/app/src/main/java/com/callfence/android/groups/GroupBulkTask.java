package com.callfence.android.groups;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.os.AsyncTask;

import com.callfence.android.utilities.helpers.database.DatabaseHelper;
import com.callfence.android.utilities.helpers.ui.UIHelper;
import com.callfence.android.utilities.picker.contact.ContactPickerIdNumber;
import com.callfence.android.utilities.picker.group.GroupPickerIdName;
import com.callfence.android.utilities.picker.group.GroupPickerResult;

import java.util.ArrayList;

public class GroupBulkTask extends AsyncTask<Void, Void, Void> {

    private ArrayList<GroupPickerResult> mSelectedGroups;
    @SuppressLint("StaticFieldLeak")
    private Context mContext;
    private Dialog mProgressDialog;
    private GroupBulkResponse mResponse;
    private boolean mFromBlacklist;

    public GroupBulkTask(Context mContext, ArrayList<GroupPickerResult> mSelectedGroups, boolean mFromBlacklist, GroupBulkResponse mResponse) {
        this.mContext = mContext;
        this.mSelectedGroups = mSelectedGroups;
        this.mFromBlacklist = mFromBlacklist;
        this.mResponse = mResponse;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        mProgressDialog = UIHelper.makeProgressDialog(mContext);
        mProgressDialog.setOnCancelListener(mDialog -> GroupBulkTask.this.cancel(true));
        mProgressDialog.show();
    }

    @Override
    protected Void doInBackground(Void... mVoid) {
        DatabaseHelper mDbHelper = new DatabaseHelper(mContext);
        ArrayList<GroupPickerIdName> mOldSelection = mFromBlacklist ? mDbHelper.getBlacklistGroup() : mDbHelper.getWhitelistGroup();
        ArrayList<GroupPickerIdName> mNewSelection = new ArrayList<>();
        for (GroupPickerResult mGroup : mSelectedGroups)
            mNewSelection.add(new GroupPickerIdName(mGroup.getGroupId(), mGroup.getGroupName()));

        ArrayList<GroupPickerIdName> mIntersection = new ArrayList<>(mOldSelection);
        mIntersection.retainAll(mNewSelection);
        mNewSelection.removeAll(mIntersection);
        mOldSelection.removeAll(mIntersection);

        for (GroupPickerIdName mGroup : mOldSelection) {
            if (mGroup.getGroupId() == null) continue;
            if (mFromBlacklist)
                mDbHelper.delBlacklistGroup(mGroup.getGroupId());
            else
                mDbHelper.delWhitelistGroup(mGroup.getGroupId());
        }

        for (GroupPickerIdName mGroup : mNewSelection) {
            ArrayList<ContactPickerIdNumber> mContacts = mDbHelper.getGroupListContact(mGroup.getGroupId());
            for (ContactPickerIdNumber mContact : mContacts)
                if (mFromBlacklist) {
                    mDbHelper.putBlacklistData(DatabaseHelper.BW_ENTRY_TYPE_GROUP, mGroup.getGroupId(), mGroup.getGroupName(), mContact.getContactId(), mContact.getPhoneNumber(), "", "", "", "");
                } else {
                    mDbHelper.putWhitelistData(DatabaseHelper.BW_ENTRY_TYPE_GROUP, mGroup.getGroupId(), mGroup.getGroupName(), mContact.getContactId(), mContact.getPhoneNumber(), "", "", "");

                }
        }
        return null;
    }

    @Override
    protected void onPostExecute(Void mVoid) {
        if (mProgressDialog.isShowing()) mProgressDialog.dismiss();
        mResponse.onTaskCompletion(true);
    }

    public interface GroupBulkResponse {

        void onTaskCompletion(boolean mSuccess);

    }
}