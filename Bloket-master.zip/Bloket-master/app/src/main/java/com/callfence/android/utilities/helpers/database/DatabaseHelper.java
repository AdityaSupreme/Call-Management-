package com.callfence.android.utilities.helpers.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.CallLog;

import com.callfence.android.groups.GroupDataPair;
import com.callfence.android.modules.blacklist.BlacklistDataPair;
import com.callfence.android.modules.calllogs.CallLogDataPair;
import com.callfence.android.modules.whitelist.WhitelistDataPair;
import com.callfence.android.utilities.picker.contact.ContactPickerIdNumber;
import com.callfence.android.utilities.picker.group.GroupPickerIdName;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database
    private static final String DB_NAME = "BloketDB";
    private static final int DB_VERSION = 1;

    // Tables
    private static final String TB_BLACKLIST = "Blacklist";
    private static final String TB_WHITELIST = "Whitelist";
    private static final String TB_GROUPLIST = "GroupList";

    // Columns
    private static final String CL_SURROGATE_ID = "ID";
    private static final String CL_GROUP_ID = "GroupId";
    private static final String CL_GROUP_NAME = "GroupName";
    private static final String CL_GROUP_DATA = "GroupData";
    private static final String CL_CONTACT_ID = "ContactId";
    private static final String CL_MATCH_DATA = "MatchData";
    private static final String CL_RANGE_DATA = "RangeData";
    private static final String CL_TIME_START = "TimeStart";
    private static final String CL_TIME_END = "TimeEnd";
    private static final String CL_ENTRY_TYPE = "EntryType";
    // Blacklist / Whitelist entry types
    public static final int BW_ENTRY_TYPE_CONTACT = 1;
    @SuppressWarnings("unused")
    public static final int BL_ENTRY_TYPE_MESG = 2;
    public static final int BW_ENTRY_TYPE_GROUP = 2;
    public static final int BW_ENTRY_TYPE_NUMBER = 3;
    public static final int BW_ENTRY_TYPE_STARTS = 4;
    public static final int BW_ENTRY_TYPE_ENDS = 5;
    public static final int BW_ENTRY_TYPE_CONTAINS = 6;
    public static final int BW_ENTRY_TYPE_RANGE = 7;

    // Block logs entry type
    public static final int BL_ENTRY_TYPE_CALL = 1;
    private static final String CL_TIMESTAMP = "Timestamp";

    // Default values
    public static final String DEFAULT_GROUP_ID = "NONE";
    private static final String TB_BLOCKLOGS = "BlockLogs";
    private static final String CL_REPLY_MSG = "ReplyMessage";
    private static final String CL_ENTRY_DATA = "EntryData";
    private static final String CL_ENTRY_DESC = "EntryDesc";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase mDatabase) {
        mDatabase.execSQL("CREATE TABLE IF NOT EXISTS " + TB_BLACKLIST + "("
                + CL_SURROGATE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,"
                + CL_ENTRY_TYPE + " TINYINT,"
                + CL_GROUP_ID + " TEXT,"
                + CL_GROUP_NAME + " TEXT,"
                + CL_CONTACT_ID + " TEXT,"
                + CL_MATCH_DATA + " TEXT,"
                + CL_RANGE_DATA + " TEXT,"
                + CL_TIME_START + " TEXT,"
                + CL_TIME_END + " TEXT,"
                + CL_REPLY_MSG + " TEXT,"
                + CL_TIMESTAMP + " TEXT )");

        mDatabase.execSQL("CREATE TABLE IF NOT EXISTS " + TB_WHITELIST + "("
                + CL_SURROGATE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,"
                + CL_ENTRY_TYPE + " TINYINT,"
                + CL_GROUP_ID + " TEXT,"
                + CL_GROUP_NAME + " TEXT,"
                + CL_CONTACT_ID + " TEXT,"
                + CL_MATCH_DATA + " TEXT,"
                + CL_RANGE_DATA + " TEXT,"
                + CL_TIME_START + " TEXT,"
                + CL_TIME_END + " TEXT,"
                + CL_TIMESTAMP + " TEXT )");

        mDatabase.execSQL("CREATE TABLE IF NOT EXISTS " + TB_BLOCKLOGS + "("
                + CL_SURROGATE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,"
                + CL_ENTRY_TYPE + " TINYINT,"
                + CL_ENTRY_DATA + " TEXT,"
                + CL_ENTRY_DESC + " TEXT,"
                + CL_TIMESTAMP + " TEXT )");

        mDatabase.execSQL("CREATE TABLE IF NOT EXISTS " + TB_GROUPLIST + "("
                + CL_SURROGATE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,"
                + CL_GROUP_ID + " TEXT,"
                + CL_GROUP_NAME + " TEXT,"
                + CL_CONTACT_ID + " TEXT,"
                + CL_GROUP_DATA + " TEXT,"
                + CL_TIMESTAMP + " TEXT )");
    }

    @Override
    public void onUpgrade(SQLiteDatabase mDatabase, int mOldVersion, int mNewVersion) {

    }

    public ArrayList<BlacklistDataPair> getBlacklistData() {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "SELECT * FROM " + TB_BLACKLIST + " ORDER BY " + CL_TIMESTAMP + " DESC";
        Cursor mCursor = mDatabase.rawQuery(mQuery, null);
        try {
            ArrayList<BlacklistDataPair> mData = new ArrayList<>();
            if (mCursor != null && mCursor.moveToFirst()) {
                HashSet<String> mGroups = new HashSet<>();
                do {
                    if (mCursor.getInt(1) == BW_ENTRY_TYPE_GROUP)
                        if (mGroups.contains(mCursor.getString(2))) continue;
                        else mGroups.add(mCursor.getString(2));
                    mData.add(new BlacklistDataPair(
                            mCursor.getInt(0),
                            mCursor.getInt(1),
                            mCursor.getString(2),
                            mCursor.getString(3),
                            mCursor.getString(4),
                            mCursor.getString(5),
                            mCursor.getString(6),
                            mCursor.getString(7),
                            mCursor.getString(8),
                            mCursor.getString(9)));
                } while (mCursor.moveToNext());
            }
            return mData;
        } finally {
            if (mCursor != null) mCursor.close();
            mDatabase.close();
        }
    }

    public void putBlacklistData(int mEntryType, String mGroupId, String mGroupName, String mContactId, String mMatchData, String mRangeData, String mTimeStart, String mTimeEnd, String mReplyMessage) {
        SQLiteDatabase mDatabase = this.getWritableDatabase();
        ContentValues mValues = new ContentValues();
        mValues.put(CL_ENTRY_TYPE, mEntryType);
        mValues.put(CL_GROUP_ID, mGroupId);
        mValues.put(CL_GROUP_NAME, mGroupName);
        mValues.put(CL_CONTACT_ID, mContactId);
        mValues.put(CL_MATCH_DATA, mMatchData);
        mValues.put(CL_RANGE_DATA, mRangeData);
        mValues.put(CL_TIME_START, mTimeStart);
        mValues.put(CL_TIME_END, mTimeEnd);
        mValues.put(CL_REPLY_MSG, mReplyMessage);
        mValues.put(CL_TIMESTAMP, System.currentTimeMillis());
        mDatabase.insert(TB_BLACKLIST, null, mValues);
        mDatabase.close();
    }

    public int chkBlacklistData(String mPhoneNumber, String mSearchableNumber) {
        int mId = -1;
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        Cursor mCursor = null;
        try {
            String mQuery = "SELECT " + CL_SURROGATE_ID + " FROM " + TB_BLACKLIST + " WHERE (" + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_CONTACT + " OR " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_NUMBER + " OR " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_GROUP + ") AND " + CL_MATCH_DATA + " LIKE '%" + mSearchableNumber + "';";
            mCursor = mDatabase.rawQuery(mQuery, null);
            if (mCursor != null && mCursor.moveToFirst()) return mCursor.getInt(0);

            mQuery = "SELECT " + CL_SURROGATE_ID + " FROM " + TB_BLACKLIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_STARTS + " AND '" + mPhoneNumber + "' LIKE " + CL_MATCH_DATA + " || '%';";
            mCursor = mDatabase.rawQuery(mQuery, null);
            if (mCursor != null && mCursor.moveToFirst()) return mCursor.getInt(0);

            mQuery = "SELECT " + CL_SURROGATE_ID + " FROM " + TB_BLACKLIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_ENDS + " AND '" + mPhoneNumber + "' LIKE '%' || " + CL_MATCH_DATA + ";";
            mCursor = mDatabase.rawQuery(mQuery, null);
            if (mCursor != null && mCursor.moveToFirst()) return mCursor.getInt(0);

            mQuery = "SELECT " + CL_SURROGATE_ID + " FROM " + TB_BLACKLIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_CONTAINS + " AND '" + mPhoneNumber + "' LIKE '%' || " + CL_MATCH_DATA + " || '%';";
            mCursor = mDatabase.rawQuery(mQuery, null);
            if (mCursor != null && mCursor.moveToFirst()) return mCursor.getInt(0);

            mQuery = "SELECT " + CL_SURROGATE_ID + " FROM " + TB_BLACKLIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_RANGE + " AND '" + mPhoneNumber + "' BETWEEN " + CL_MATCH_DATA + " AND " + CL_RANGE_DATA + ";";
            mCursor = mDatabase.rawQuery(mQuery, null);
            if (mCursor != null && mCursor.moveToFirst()) return mCursor.getInt(0);
        } finally {
            if (mCursor != null) mCursor.close();
            mDatabase.close();
        }
        return mId;
    }

    public ArrayList<ContactPickerIdNumber> getBlacklistContacts() {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "SELECT " + CL_CONTACT_ID + ", " + CL_MATCH_DATA + " FROM " + TB_BLACKLIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_CONTACT + " ORDER BY " + CL_TIMESTAMP + " DESC";
        Cursor mCursor = mDatabase.rawQuery(mQuery, null);
        try {
            ArrayList<ContactPickerIdNumber> mData = new ArrayList<>();
            if (mCursor != null && mCursor.moveToFirst()) {
                do mData.add(new ContactPickerIdNumber(mCursor.getString(0), mCursor.getString(1)));
                while (mCursor.moveToNext());
            }
            return mData;
        } finally {
            if (mCursor != null) mCursor.close();
            mDatabase.close();
        }
    }

    public String[] getBlacklistSchedule(int mId) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "SELECT " + CL_TIME_START + ", " + CL_TIME_END + " FROM " + TB_BLACKLIST + " WHERE " + CL_SURROGATE_ID + " = " + mId + ";";
        Cursor mCursor = mDatabase.rawQuery(mQuery, null);
        try {
            if (mCursor != null && mCursor.moveToFirst())
                return new String[]{mCursor.getString(0), mCursor.getString(1)};
        } finally {
            if (mCursor != null) mCursor.close();
            mDatabase.close();
        }
        return null;
    }

    public String getBlacklistMessage(int mId) {
        String mMessage = "";
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "SELECT " + CL_REPLY_MSG + " FROM " + TB_BLACKLIST + " WHERE " + CL_SURROGATE_ID + " = " + mId + ";";
        Cursor mCursor = mDatabase.rawQuery(mQuery, null);
        try {
            if (mCursor != null && mCursor.moveToFirst()) mMessage = mCursor.getString(0);
            return mMessage;
        } finally {
            if (mCursor != null) mCursor.close();
            mDatabase.close();
        }
    }

    public void updBlacklistSchedule(int mId, String mStartTime, String mEndTime) {
        SQLiteDatabase mDatabase = this.getWritableDatabase();
        ContentValues mValues = new ContentValues();
        mValues.put(CL_TIME_START, mStartTime);
        mValues.put(CL_TIME_END, mEndTime);
        String mGroupId = isGroup(mId, mDatabase);
        if (mGroupId == null)
            mDatabase.update(TB_BLACKLIST, mValues, CL_SURROGATE_ID + " = " + mId, null);
        else
            mDatabase.update(TB_BLACKLIST, mValues, CL_GROUP_ID + " = '" + mGroupId + "'", null);
        mDatabase.close();
    }

    public void updBlacklistMessage(int mId, String mReplyMessage) {
        SQLiteDatabase mDatabase = this.getWritableDatabase();
        ContentValues mValues = new ContentValues();
        mValues.put(CL_REPLY_MSG, mReplyMessage);
        String mGroupId = isGroup(mId, mDatabase);
        if (mGroupId == null)
            mDatabase.update(TB_BLACKLIST, mValues, CL_SURROGATE_ID + " = " + mId, null);
        else
            mDatabase.update(TB_BLACKLIST, mValues, CL_GROUP_ID + " = '" + mGroupId + "'", null);
        mDatabase.close();
    }

    public void updBlacklistGroup(String mOldGroupId, String mNewGroupId, String mGroupName) {
        SQLiteDatabase mDatabase = this.getWritableDatabase();
        ContentValues mValues = new ContentValues();
        mValues.put(CL_GROUP_ID, mNewGroupId);
        mValues.put(CL_GROUP_NAME, mGroupName);
        mDatabase.update(TB_BLACKLIST, mValues, CL_GROUP_ID + " = '" + mOldGroupId + "'", null);
        mDatabase.close();
    }

    public void updWhitelistGroup(String mOldGroupId, String mNewGroupId, String mGroupName) {
        SQLiteDatabase mDatabase = this.getWritableDatabase();
        ContentValues mValues = new ContentValues();
        mValues.put(CL_GROUP_ID, mNewGroupId);
        mValues.put(CL_GROUP_NAME, mGroupName);
        mDatabase.update(TB_WHITELIST, mValues, CL_GROUP_ID + " = '" + mOldGroupId + "'", null);
        mDatabase.close();
    }

    public boolean chkBlacklistSchedule(int mId) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "SELECT " + CL_TIME_START + ", " + CL_TIME_END + " FROM " + TB_BLACKLIST + " WHERE " + CL_SURROGATE_ID + " = " + mId + ";";
        Cursor mCursor = mDatabase.rawQuery(mQuery, null);
        try {
            boolean mResult = true;
            long mCurrentTime = System.currentTimeMillis();
            if (mCursor != null && mCursor.moveToFirst()) {
                if (mCursor.getLong(0) > 0)
                    mResult = mCurrentTime >= mCursor.getLong(0) && mCurrentTime <= mCursor.getLong(1) + 999;
            }
            return mResult;
        } finally {
            if (mCursor != null) mCursor.close();
            mDatabase.close();
        }
    }

    @SuppressWarnings("BooleanMethodIsAlwaysInverted")
    public boolean chkBlacklistContact(String mContactId, String mPhoneNumber) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "SELECT " + CL_SURROGATE_ID + " FROM " + TB_BLACKLIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_CONTACT + " AND " + CL_CONTACT_ID + " = '" + mContactId + "' AND " + CL_MATCH_DATA + " = '" + mPhoneNumber + "';";
        Cursor mCursor = mDatabase.rawQuery(mQuery, null);
        try {
            return mCursor.getCount() > 0;
        } finally {
            if (mCursor != null) mCursor.close();
            mDatabase.close();
        }
    }

    @SuppressWarnings("BooleanMethodIsAlwaysInverted")
    public boolean chkBlacklistNumber(String mPhoneNumber) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "SELECT " + CL_SURROGATE_ID + " FROM " + TB_BLACKLIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_NUMBER + " AND " + CL_MATCH_DATA + " = '" + mPhoneNumber + "';";
        Cursor mCursor = mDatabase.rawQuery(mQuery, null);
        try {
            return mCursor.getCount() > 0;
        } finally {
            if (mCursor != null) mCursor.close();
            mDatabase.close();
        }
    }

    public boolean chkBlacklistStarts(String mPhoneNumber) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "SELECT " + CL_SURROGATE_ID + " FROM " + TB_BLACKLIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_STARTS + " AND " + CL_MATCH_DATA + " = '" + mPhoneNumber + "';";
        Cursor mCursor = mDatabase.rawQuery(mQuery, null);
        try {
            return mCursor.getCount() > 0;
        } finally {
            if (mCursor != null) mCursor.close();
            mDatabase.close();
        }
    }

    public boolean chkBlacklistEnds(String mPhoneNumber) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "SELECT " + CL_SURROGATE_ID + " FROM " + TB_BLACKLIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_ENDS + " AND " + CL_MATCH_DATA + " = '" + mPhoneNumber + "';";
        Cursor mCursor = mDatabase.rawQuery(mQuery, null);
        try {
            return mCursor.getCount() > 0;
        } finally {
            if (mCursor != null) mCursor.close();
            mDatabase.close();
        }
    }

    public boolean chkBlacklistContains(String mPhoneNumber) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "SELECT " + CL_SURROGATE_ID + " FROM " + TB_BLACKLIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_CONTAINS + " AND " + CL_MATCH_DATA + " = '" + mPhoneNumber + "';";
        Cursor mCursor = mDatabase.rawQuery(mQuery, null);
        try {
            return mCursor.getCount() > 0;
        } finally {
            if (mCursor != null) mCursor.close();
            mDatabase.close();
        }
    }

    public boolean chkBlacklistRange(String mRangeFrom, String mRangeUpto) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "SELECT " + CL_SURROGATE_ID + " FROM " + TB_BLACKLIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_RANGE + " AND " + CL_MATCH_DATA + " = '" + mRangeFrom + "' AND " + CL_RANGE_DATA + " = '" + mRangeUpto + "';";
        Cursor mCursor = mDatabase.rawQuery(mQuery, null);
        try {
            return mCursor.getCount() > 0;
        } finally {
            if (mCursor != null) mCursor.close();
            mDatabase.close();
        }
    }

    public boolean chkBlacklistGroup(String mGroupId) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "SELECT " + CL_SURROGATE_ID + " FROM " + TB_BLACKLIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_GROUP + " AND " + CL_GROUP_ID + " = '" + mGroupId + "';";
        Cursor mCursor = mDatabase.rawQuery(mQuery, null);
        try {
            return mCursor.getCount() > 0;
        } finally {
            if (mCursor != null) mCursor.close();
            mDatabase.close();
        }
    }

    public void delBlacklistContact(int mContactId, String mPhoneNumber) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "DELETE FROM " + TB_BLACKLIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_CONTACT + " AND " + CL_CONTACT_ID + " = " + mContactId + " AND " + CL_MATCH_DATA + " = '" + mPhoneNumber + "';";
        mDatabase.execSQL(mQuery);
        mDatabase.close();
    }

    public void delBlacklistNumber(String mPhoneNumber) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "DELETE FROM " + TB_BLACKLIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_NUMBER + " AND " + CL_MATCH_DATA + " = '" + mPhoneNumber + "';";
        mDatabase.execSQL(mQuery);
        mDatabase.close();
    }

    public void delBlacklistStarts(String mPhoneNumber) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "DELETE FROM " + TB_BLACKLIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_STARTS + " AND " + CL_MATCH_DATA + " = '" + mPhoneNumber + "';";
        mDatabase.execSQL(mQuery);
        mDatabase.close();
    }

    public void delBlacklistEnds(String mPhoneNumber) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "DELETE FROM " + TB_BLACKLIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_ENDS + " AND " + CL_MATCH_DATA + " = '" + mPhoneNumber + "';";
        mDatabase.execSQL(mQuery);
        mDatabase.close();
    }

    public void delBlacklistContains(String mPhoneNumber) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "DELETE FROM " + TB_BLACKLIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_CONTAINS + " AND " + CL_MATCH_DATA + " = '" + mPhoneNumber + "';";
        mDatabase.execSQL(mQuery);
        mDatabase.close();
    }

    public void delBlacklistRange(String mStartRange, String mEndRange) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "DELETE FROM " + TB_BLACKLIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_RANGE + " AND " + CL_MATCH_DATA + " = '" + mStartRange + "' AND " + CL_RANGE_DATA + " = '" + mEndRange + "';";
        mDatabase.execSQL(mQuery);
        mDatabase.close();
    }

    public void delBlacklistGroup(String mGroupId) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "DELETE FROM " + TB_BLACKLIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_GROUP + " AND " + CL_GROUP_ID + " = '" + mGroupId + "';";
        mDatabase.execSQL(mQuery);
        mDatabase.close();
    }

    public void delBlacklistGroupItem(String mGroupId, String mContactId, String mPhoneNumber) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "DELETE FROM " + TB_BLACKLIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_GROUP + " AND " + CL_GROUP_ID + " = '" + mGroupId + "' AND " + CL_CONTACT_ID + " = '" + mContactId + "' AND " + CL_MATCH_DATA + " = '" + mPhoneNumber + "';";
        mDatabase.execSQL(mQuery);
        mDatabase.close();
    }

    public void delBlacklistInvalidGroupItem(String mContactId) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "DELETE FROM " + TB_BLACKLIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_GROUP + " AND " + CL_CONTACT_ID + " = '" + mContactId + "';";
        mDatabase.execSQL(mQuery);
        mDatabase.close();
    }

    public ArrayList<WhitelistDataPair> getWhitelistData() {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "SELECT * FROM " + TB_WHITELIST + " ORDER BY " + CL_TIMESTAMP + " DESC";
        Cursor mCursor = mDatabase.rawQuery(mQuery, null);
        try {
            ArrayList<WhitelistDataPair> mData = new ArrayList<>();
            if (mCursor != null && mCursor.moveToFirst()) {
                HashSet<String> mGroups = new HashSet<>();
                do {
                    if (mCursor.getInt(1) == BW_ENTRY_TYPE_GROUP)
                        if (mGroups.contains(mCursor.getString(2))) continue;
                        else mGroups.add(mCursor.getString(2));
                    mData.add(new WhitelistDataPair(
                            mCursor.getInt(0),
                            mCursor.getInt(1),
                            mCursor.getString(2),
                            mCursor.getString(3),
                            mCursor.getString(4),
                            mCursor.getString(5),
                            mCursor.getString(6),
                            mCursor.getString(7),
                            mCursor.getString(8)));
                } while (mCursor.moveToNext());
            }
            return mData;
        } finally {
            if (mCursor != null) mCursor.close();
            mDatabase.close();
        }
    }

    public void putWhitelistData(int mEntryType, String mGroupId, String mGroupName, String mContactId, String mMatchData, String mRangeData, String mTimeStart, String mTimeEnd) {
        SQLiteDatabase mDatabase = this.getWritableDatabase();
        ContentValues mValues = new ContentValues();
        mValues.put(CL_ENTRY_TYPE, mEntryType);
        mValues.put(CL_GROUP_ID, mGroupId);
        mValues.put(CL_GROUP_NAME, mGroupName);
        mValues.put(CL_CONTACT_ID, mContactId);
        mValues.put(CL_MATCH_DATA, mMatchData);
        mValues.put(CL_RANGE_DATA, mRangeData);
        mValues.put(CL_TIME_START, mTimeStart);
        mValues.put(CL_TIME_END, mTimeEnd);
        mValues.put(CL_TIMESTAMP, System.currentTimeMillis());
        mDatabase.insert(TB_WHITELIST, null, mValues);
        mDatabase.close();
    }

    public int chkWhitelistData(String mPhoneNumber, String mSearchableNumber) {
        int mId = -1;
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        Cursor mCursor = null;
        try {
            String mQuery = "SELECT " + CL_SURROGATE_ID + " FROM " + TB_WHITELIST + " WHERE (" + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_CONTACT + " OR " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_NUMBER + " OR " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_GROUP + ") AND " + CL_MATCH_DATA + " LIKE '%" + mSearchableNumber + "';";
            mCursor = mDatabase.rawQuery(mQuery, null);
            if (mCursor != null && mCursor.moveToFirst()) return mCursor.getInt(0);

            mQuery = "SELECT " + CL_SURROGATE_ID + " FROM " + TB_WHITELIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_STARTS + " AND '" + mPhoneNumber + "' LIKE " + CL_MATCH_DATA + " || '%';";
            mCursor = mDatabase.rawQuery(mQuery, null);
            if (mCursor != null && mCursor.moveToFirst()) return mCursor.getInt(0);

            mQuery = "SELECT " + CL_SURROGATE_ID + " FROM " + TB_WHITELIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_ENDS + " AND '" + mPhoneNumber + "' LIKE '%' || " + CL_MATCH_DATA + ";";
            mCursor = mDatabase.rawQuery(mQuery, null);
            if (mCursor != null && mCursor.moveToFirst()) return mCursor.getInt(0);

            mQuery = "SELECT " + CL_SURROGATE_ID + " FROM " + TB_WHITELIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_CONTAINS + " AND '" + mPhoneNumber + "' LIKE '%' || " + CL_MATCH_DATA + " || '%';";
            mCursor = mDatabase.rawQuery(mQuery, null);
            if (mCursor != null && mCursor.moveToFirst()) return mCursor.getInt(0);

            mQuery = "SELECT " + CL_SURROGATE_ID + " FROM " + TB_WHITELIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_RANGE + " AND '" + mPhoneNumber + "' BETWEEN " + CL_MATCH_DATA + " AND " + CL_RANGE_DATA + ";";
            mCursor = mDatabase.rawQuery(mQuery, null);
            if (mCursor != null && mCursor.moveToFirst()) return mCursor.getInt(0);
        } finally {
            if (mCursor != null) mCursor.close();
            mDatabase.close();
        }
        return mId;
    }

    public ArrayList<ContactPickerIdNumber> getWhitelistContacts() {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "SELECT " + CL_CONTACT_ID + ", " + CL_MATCH_DATA + " FROM " + TB_WHITELIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_CONTACT + " ORDER BY " + CL_TIMESTAMP + " DESC";
        Cursor mCursor = mDatabase.rawQuery(mQuery, null);
        try {
            ArrayList<ContactPickerIdNumber> mData = new ArrayList<>();
            if (mCursor != null && mCursor.moveToFirst()) {
                do mData.add(new ContactPickerIdNumber(mCursor.getString(0), mCursor.getString(1)));
                while (mCursor.moveToNext());
            }
            return mData;
        } finally {
            if (mCursor != null) mCursor.close();
            mDatabase.close();
        }
    }

    public String[] getWhitelistSchedule(int mId) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "SELECT " + CL_TIME_START + ", " + CL_TIME_END + " FROM " + TB_WHITELIST + " WHERE " + CL_SURROGATE_ID + " = " + mId + ";";
        Cursor mCursor = mDatabase.rawQuery(mQuery, null);
        try {
            if (mCursor != null && mCursor.moveToFirst())
                return new String[]{mCursor.getString(0), mCursor.getString(1)};
        } finally {
            if (mCursor != null) mCursor.close();
            mDatabase.close();
        }
        return null;
    }

    public void updWhitelistSchedule(int mId, String mStartTime, String mEndTime) {
        SQLiteDatabase mDatabase = this.getWritableDatabase();
        ContentValues mValues = new ContentValues();
        mValues.put(CL_TIME_START, mStartTime);
        mValues.put(CL_TIME_END, mEndTime);
        String mGroupId = isGroup(mId, mDatabase);
        if (mGroupId == null)
            mDatabase.update(TB_WHITELIST, mValues, CL_SURROGATE_ID + " = " + mId, null);
        else
            mDatabase.update(TB_WHITELIST, mValues, CL_GROUP_ID + " = '" + mGroupId + "'", null);
        mDatabase.close();
    }

    public boolean chkWhitelistSchedule(int mId) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "SELECT " + CL_TIME_START + ", " + CL_TIME_END + " FROM " + TB_WHITELIST + " WHERE " + CL_SURROGATE_ID + " = " + mId + ";";
        Cursor mCursor = mDatabase.rawQuery(mQuery, null);
        try {
            boolean mResult = true;
            long mCurrentTime = System.currentTimeMillis();
            if (mCursor != null && mCursor.moveToFirst()) {
                if (mCursor.getLong(0) > 0)
                    mResult = mCurrentTime >= mCursor.getLong(0) && mCurrentTime <= mCursor.getLong(1) + 999;
            }
            return mResult;
        } finally {
            if (mCursor != null) mCursor.close();
            mDatabase.close();
        }
    }

    @SuppressWarnings("BooleanMethodIsAlwaysInverted")
    public boolean chkWhitelistContact(String mContactId, String mPhoneNumber) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "SELECT " + CL_SURROGATE_ID + " FROM " + TB_WHITELIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_CONTACT + " AND " + CL_CONTACT_ID + " = '" + mContactId + "' AND " + CL_MATCH_DATA + " = '" + mPhoneNumber + "';";
        Cursor mCursor = mDatabase.rawQuery(mQuery, null);
        try {
            return mCursor.getCount() > 0;
        } finally {
            if (mCursor != null) mCursor.close();
            mDatabase.close();
        }
    }

    @SuppressWarnings("BooleanMethodIsAlwaysInverted")
    public boolean chkWhitelistNumber(String mPhoneNumber) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "SELECT " + CL_SURROGATE_ID + " FROM " + TB_WHITELIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_NUMBER + " AND " + CL_MATCH_DATA + " = '" + mPhoneNumber + "';";
        Cursor mCursor = mDatabase.rawQuery(mQuery, null);
        try {
            return mCursor.getCount() > 0;
        } finally {
            if (mCursor != null) mCursor.close();
            mDatabase.close();
        }
    }

    public boolean chkWhitelistStarts(String mPhoneNumber) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "SELECT " + CL_SURROGATE_ID + " FROM " + TB_WHITELIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_STARTS + " AND " + CL_MATCH_DATA + " = '" + mPhoneNumber + "';";
        Cursor mCursor = mDatabase.rawQuery(mQuery, null);
        try {
            return mCursor.getCount() > 0;
        } finally {
            if (mCursor != null) mCursor.close();
            mDatabase.close();
        }
    }

    public boolean chkWhitelistEnds(String mPhoneNumber) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "SELECT " + CL_SURROGATE_ID + " FROM " + TB_WHITELIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_ENDS + " AND " + CL_MATCH_DATA + " = '" + mPhoneNumber + "';";
        Cursor mCursor = mDatabase.rawQuery(mQuery, null);
        try {
            return mCursor.getCount() > 0;
        } finally {
            if (mCursor != null) mCursor.close();
            mDatabase.close();
        }
    }

    public boolean chkWhitelistContains(String mPhoneNumber) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "SELECT " + CL_SURROGATE_ID + " FROM " + TB_WHITELIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_CONTAINS + " AND " + CL_MATCH_DATA + " = '" + mPhoneNumber + "';";
        Cursor mCursor = mDatabase.rawQuery(mQuery, null);
        try {
            return mCursor.getCount() > 0;
        } finally {
            if (mCursor != null) mCursor.close();
            mDatabase.close();
        }
    }

    public boolean chkWhitelistRange(String mRangeFrom, String mRangeUpto) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "SELECT " + CL_SURROGATE_ID + " FROM " + TB_WHITELIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_RANGE + " AND " + CL_MATCH_DATA + " = '" + mRangeFrom + "' AND " + CL_RANGE_DATA + " = '" + mRangeUpto + "';";
        Cursor mCursor = mDatabase.rawQuery(mQuery, null);
        try {
            return mCursor.getCount() > 0;
        } finally {
            if (mCursor != null) mCursor.close();
            mDatabase.close();
        }
    }

    public boolean chkWhitelistGroup(String mGroupId) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "SELECT " + CL_SURROGATE_ID + " FROM " + TB_WHITELIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_GROUP + " AND " + CL_GROUP_ID + " = '" + mGroupId + "';";
        Cursor mCursor = mDatabase.rawQuery(mQuery, null);
        try {
            return mCursor.getCount() > 0;
        } finally {
            if (mCursor != null) mCursor.close();
            mDatabase.close();
        }
    }

    public void delWhitelistContact(int mContactId, String mPhoneNumber) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "DELETE FROM " + TB_WHITELIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_CONTACT + " AND " + CL_CONTACT_ID + " = " + mContactId + " AND " + CL_MATCH_DATA + " = '" + mPhoneNumber + "';";
        mDatabase.execSQL(mQuery);
        mDatabase.close();
    }

    public void delWhitelistNumber(String mPhoneNumber) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "DELETE FROM " + TB_WHITELIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_NUMBER + " AND " + CL_MATCH_DATA + " = '" + mPhoneNumber + "';";
        mDatabase.execSQL(mQuery);
        mDatabase.close();
    }

    public void delWhitelistStarts(String mPhoneNumber) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "DELETE FROM " + TB_WHITELIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_STARTS + " AND " + CL_MATCH_DATA + " = '" + mPhoneNumber + "';";
        mDatabase.execSQL(mQuery);
        mDatabase.close();
    }

    public void delWhitelistEnds(String mPhoneNumber) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "DELETE FROM " + TB_WHITELIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_ENDS + " AND " + CL_MATCH_DATA + " = '" + mPhoneNumber + "';";
        mDatabase.execSQL(mQuery);
        mDatabase.close();
    }

    public void delWhitelistContains(String mPhoneNumber) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "DELETE FROM " + TB_WHITELIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_CONTAINS + " AND " + CL_MATCH_DATA + " = '" + mPhoneNumber + "';";
        mDatabase.execSQL(mQuery);
        mDatabase.close();
    }

    public void delWhitelistRange(String mStartRange, String mEndRange) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "DELETE FROM " + TB_WHITELIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_RANGE + " AND " + CL_MATCH_DATA + " = '" + mStartRange + "' AND " + CL_RANGE_DATA + " = '" + mEndRange + "';";
        mDatabase.execSQL(mQuery);
        mDatabase.close();
    }

    public void delWhitelistGroup(String mGroupId) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "DELETE FROM " + TB_WHITELIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_GROUP + " AND " + CL_GROUP_ID + " = '" + mGroupId + "';";
        mDatabase.execSQL(mQuery);
        mDatabase.close();
    }

    public void delWhitelistGroupItem(String mGroupId, String mContactId, String mPhoneNumber) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "DELETE FROM " + TB_WHITELIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_GROUP + " AND " + CL_GROUP_ID + " = '" + mGroupId + "' AND " + CL_CONTACT_ID + " = '" + mContactId + "' AND " + CL_MATCH_DATA + " = '" + mPhoneNumber + "';";
        mDatabase.execSQL(mQuery);
        mDatabase.close();
    }

    public void delWhitelistInvalidGroupItem(String mContactId) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "DELETE FROM " + TB_WHITELIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_GROUP + " AND " + CL_CONTACT_ID + " = '" + mContactId + "';";
        mDatabase.execSQL(mQuery);
        mDatabase.close();
    }

    public ArrayList<CallLogDataPair> getBlockLogsCall() {
        SimpleDateFormat mDateFormat = new SimpleDateFormat("EEEE, MMM dd, hh:mm a", Locale.getDefault());
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "SELECT * FROM " + TB_BLOCKLOGS + " WHERE " + CL_ENTRY_TYPE + " = " + BL_ENTRY_TYPE_CALL + " ORDER BY " + CL_TIMESTAMP + " DESC";
        Cursor mCursor = mDatabase.rawQuery(mQuery, null);
        try {
            ArrayList<CallLogDataPair> mData = new ArrayList<>();
            if (mCursor != null && mCursor.getCount() > 0) {
                Date mRawDate;
                while (mCursor.moveToNext()) {
                    mRawDate = new Date(Long.valueOf(mCursor.getString(4)));
                    mData.add(new CallLogDataPair(
                            mCursor.getString(0),
                            CallLog.Calls.BLOCKED_TYPE, null, null,
                            mCursor.getString(2),
                            mDateFormat.format(mRawDate), null,
                            1,
                            mRawDate));
                }
            }
            return mData;
        } finally {
            if (mCursor != null) mCursor.close();
            mDatabase.close();
        }
    }

    public ArrayList<CallLogDataPair> getBlockLogsSlab(String mPhoneNumber, long mTimeStamp, int mLimit) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "SELECT * FROM " + TB_BLOCKLOGS + " WHERE " + CL_ENTRY_TYPE + " = " + BL_ENTRY_TYPE_CALL + " AND " + CL_ENTRY_DATA + " = '" + mPhoneNumber + "' AND " + CL_TIMESTAMP + " <= " + mTimeStamp + " ORDER BY " + CL_TIMESTAMP + " DESC LIMIT " + mLimit;
        Cursor mCursor = mDatabase.rawQuery(mQuery, null);
        try {
            ArrayList<CallLogDataPair> mData = new ArrayList<>();
            Date mRawDate;
            SimpleDateFormat mDateFormat = new SimpleDateFormat("EEEE, MMM dd, hh:mm a", Locale.getDefault());
            if (mCursor != null && mCursor.getCount() > 0)
                while (mCursor.moveToNext()) {
                    mRawDate = new Date(Long.valueOf(mCursor.getString(4)));
                    mData.add(new CallLogDataPair(
                            mCursor.getString(0),
                            CallLog.Calls.BLOCKED_TYPE, null, null,
                            mCursor.getString(2),
                            mDateFormat.format(mRawDate), null,
                            1,
                            mRawDate));
                }
            return mData;
        } finally {
            if (mCursor != null) mCursor.close();
            mDatabase.close();
        }
    }

    public void putBlockLogs(int mEntryType, String mEntryData, String mEntryDesc) {
        SQLiteDatabase mDatabase = this.getWritableDatabase();
        ContentValues mValues = new ContentValues();
        mValues.put(CL_ENTRY_TYPE, mEntryType);
        mValues.put(CL_ENTRY_DATA, mEntryData);
        mValues.put(CL_ENTRY_DESC, mEntryDesc);
        mValues.put(CL_TIMESTAMP, System.currentTimeMillis());
        mDatabase.insert(TB_BLOCKLOGS, null, mValues);
        mDatabase.close();
    }

    public void delBlockLogs(String mSurrogateKey) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "DELETE FROM " + TB_BLOCKLOGS + " WHERE " + CL_SURROGATE_ID + " = " + mSurrogateKey + ";";
        mDatabase.execSQL(mQuery);
        mDatabase.close();
    }

    public ArrayList<GroupDataPair> getGroupList() {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "SELECT " + CL_GROUP_ID + ", " + CL_GROUP_NAME + " FROM " + TB_GROUPLIST + " ORDER BY " + CL_GROUP_ID + ";";
        Cursor mCursor = mDatabase.rawQuery(mQuery, null);
        try {
            ArrayList<GroupDataPair> mData = new ArrayList<>();
            if (mCursor != null && mCursor.getCount() > 0) {
                String mCurrId, mLastId = "";
                while (mCursor.moveToNext()) {
                    mCurrId = mCursor.getString(0);
                    if (!mLastId.equals(mCurrId))
                        mData.add(new GroupDataPair(mCursor.getString(0), mCursor.getString(1)));
                    mLastId = mCurrId;
                }
            }
            return mData;
        } finally {
            if (mCursor != null) mCursor.close();
            mDatabase.close();
        }
    }

    public void putGroupList(String mGroupId, String mGroupName, String mContactId, String mGroupData) {
        SQLiteDatabase mDatabase = this.getWritableDatabase();
        ContentValues mValues = new ContentValues();
        mValues.put(CL_GROUP_ID, mGroupId);
        mValues.put(CL_GROUP_NAME, mGroupName);
        mValues.put(CL_CONTACT_ID, mContactId);
        mValues.put(CL_GROUP_DATA, mGroupData);
        mValues.put(CL_TIMESTAMP, System.currentTimeMillis());
        mDatabase.insert(TB_GROUPLIST, null, mValues);
        mDatabase.close();
    }

    public ArrayList<GroupPickerIdName> getBlacklistGroup() {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "SELECT " + CL_GROUP_ID + ", " + CL_GROUP_NAME + " FROM " + TB_BLACKLIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_GROUP + ";";
        Cursor mCursor = mDatabase.rawQuery(mQuery, null);
        try {
            ArrayList<GroupPickerIdName> mData = new ArrayList<>();
            if (mCursor != null && mCursor.moveToFirst()) {
                HashSet<String> mGroups = new HashSet<>();
                do {
                    if (mGroups.contains(mCursor.getString(0))) continue;
                    else mGroups.add(mCursor.getString(0));
                    mData.add(new GroupPickerIdName(mCursor.getString(0), mCursor.getString(1)));
                } while (mCursor.moveToNext());
            }
            return mData;
        } finally {
            if (mCursor != null) mCursor.close();
            mDatabase.close();
        }
    }

    public ArrayList<String> getBlacklistGroupContacts() {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "SELECT " + CL_CONTACT_ID + " FROM " + TB_BLACKLIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_GROUP + ";";
        Cursor mCursor = mDatabase.rawQuery(mQuery, null);
        try {
            ArrayList<String> mData = new ArrayList<>();
            if (mCursor != null && mCursor.moveToFirst())
                do mData.add(mCursor.getString(0));
                while (mCursor.moveToNext());
            return mData;
        } finally {
            if (mCursor != null) mCursor.close();
            mDatabase.close();
        }
    }

    public ArrayList<GroupPickerIdName> getWhitelistGroup() {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "SELECT " + CL_GROUP_ID + ", " + CL_GROUP_NAME + " FROM " + TB_WHITELIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_GROUP + ";";
        Cursor mCursor = mDatabase.rawQuery(mQuery, null);
        try {
            ArrayList<GroupPickerIdName> mData = new ArrayList<>();
            if (mCursor != null && mCursor.moveToFirst()) {
                HashSet<String> mGroups = new HashSet<>();
                do {
                    if (mGroups.contains(mCursor.getString(0))) continue;
                    else mGroups.add(mCursor.getString(0));
                    mData.add(new GroupPickerIdName(mCursor.getString(0), mCursor.getString(1)));
                } while (mCursor.moveToNext());
            }
            return mData;
        } finally {
            if (mCursor != null) mCursor.close();
            mDatabase.close();
        }
    }

    public ArrayList<String> getWhitelistGroupContacts() {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "SELECT " + CL_CONTACT_ID + " FROM " + TB_WHITELIST + " WHERE " + CL_ENTRY_TYPE + " = " + BW_ENTRY_TYPE_GROUP + ";";
        Cursor mCursor = mDatabase.rawQuery(mQuery, null);
        try {
            ArrayList<String> mData = new ArrayList<>();
            if (mCursor != null && mCursor.moveToFirst())
                do mData.add(mCursor.getString(0));
                while (mCursor.moveToNext());
            return mData;
        } finally {
            if (mCursor != null) mCursor.close();
            mDatabase.close();
        }
    }

    public ArrayList<ContactPickerIdNumber> getGroupListContact(String mGroupId) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "SELECT " + CL_CONTACT_ID + ", " + CL_GROUP_DATA + " FROM " + TB_GROUPLIST + " WHERE " + CL_GROUP_ID + " = '" + mGroupId + "' ORDER BY " + CL_TIMESTAMP + " DESC";
        Cursor mCursor = mDatabase.rawQuery(mQuery, null);
        try {
            ArrayList<ContactPickerIdNumber> mData = new ArrayList<>();
            if (mCursor != null && mCursor.moveToFirst()) {
                do mData.add(new ContactPickerIdNumber(mCursor.getString(0), mCursor.getString(1)));
                while (mCursor.moveToNext());
            }
            return mData;
        } finally {
            if (mCursor != null) mCursor.close();
            mDatabase.close();
        }
    }

    @SuppressWarnings("BooleanMethodIsAlwaysInverted")
    public boolean chkGroupListName(String mGroupName) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "SELECT " + CL_GROUP_ID + " FROM " + TB_GROUPLIST + " WHERE " + CL_GROUP_NAME + " = '" + mGroupName + "';";
        Cursor mCursor = mDatabase.rawQuery(mQuery, null);
        try {
            return mCursor.getCount() > 0;
        } finally {
            if (mCursor != null) mCursor.close();
            mDatabase.close();
        }
    }

    public void updGroupList(String mOldGroupId, String mNewGroupId, String mGroupName) {
        SQLiteDatabase mDatabase = this.getWritableDatabase();
        ContentValues mValues = new ContentValues();
        mValues.put(CL_GROUP_ID, mNewGroupId);
        mValues.put(CL_GROUP_NAME, mGroupName);
        mDatabase.update(TB_GROUPLIST, mValues, CL_GROUP_ID + " = '" + mOldGroupId + "'", null);
        mDatabase.close();
    }

    public void delGroupList(String mGroupId) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "DELETE FROM " + TB_GROUPLIST + " WHERE " + CL_GROUP_ID + " = '" + mGroupId + "';";
        mDatabase.execSQL(mQuery);
        mDatabase.close();
    }

    public void delGroupListContact(String mGroupId, String mContactId, String mPhoneNumber) {
        SQLiteDatabase mDatabase = this.getReadableDatabase();
        String mQuery = "DELETE FROM " + TB_GROUPLIST + " WHERE " + CL_GROUP_ID + " = '" + mGroupId + "' AND " + CL_CONTACT_ID + " = '" + mContactId + "' AND " + CL_GROUP_DATA + " = '" + mPhoneNumber + "';";
        mDatabase.execSQL(mQuery);
        mDatabase.close();
    }

    private String isGroup(int mId, SQLiteDatabase mDatabase) {
        String mQuery = "SELECT " + CL_GROUP_ID + " FROM " + TB_GROUPLIST + " WHERE " + CL_SURROGATE_ID + " = " + mId + ";";
        try (Cursor mCursor = mDatabase.rawQuery(mQuery, null)) {
            if (mCursor.getCount() > 0) return mCursor.getString(0);
            else return null;
        } catch (Exception mException) {
            return null;
        }
    }
}