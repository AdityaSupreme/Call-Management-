package com.callfence.android.modules.calllogs;

import java.util.Date;

public class CallLogDataPair {

    private Date mRawDate;
    private int mCallType, mCallCount;
    private String mCallLogId, mDisplayName, mPhotoUri, mPhoneNumber, mCallDate, mCallDuration;

    public CallLogDataPair(String mCallLogId, int mCallType, String mDisplayName, String mPhotoUri, String mPhoneNumber, String mCallDate, String mCallDuration, int mCallCount, Date mRawDate) {
        this.mCallLogId = mCallLogId;
        this.mCallType = mCallType;
        this.mDisplayName = mDisplayName;
        this.mPhotoUri = mPhotoUri;
        this.mPhoneNumber = mPhoneNumber;
        this.mCallDate = mCallDate;
        this.mCallDuration = mCallDuration;
        this.mCallCount = mCallCount;
        this.mRawDate = mRawDate;
    }

    void incCallCount() {
        mCallCount++;
    }

    Date getRawDate() {
        return mRawDate;
    }

    public int getCallType() {
        return mCallType;
    }

    int getCallCount() {
        return mCallCount;
    }

    public String getDisplayName() {
        return mDisplayName;
    }

    public String getPhotoUri() {
        return mPhotoUri;
    }

    public String getCallLogId() {
        return mCallLogId;
    }

    public String getPhoneNumber() {
        return mPhoneNumber;
    }

    public String getCallDate() {
        return mCallDate;
    }

    public String getCallDuration() {
        return mCallDuration;
    }

    void setDisplayName(String mDisplayName) {
        this.mDisplayName = mDisplayName;
    }

    void setPhotoUri(String mPhotoUri) {
        this.mPhotoUri = mPhotoUri;
    }
}