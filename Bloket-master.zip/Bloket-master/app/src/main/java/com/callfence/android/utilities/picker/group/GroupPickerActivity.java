package com.callfence.android.utilities.picker.group;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.callfence.android.R;
import com.callfence.android.utilities.helpers.ui.UIHelper;

import java.util.ArrayList;

public class GroupPickerActivity extends AppCompatActivity implements View.OnClickListener {

    public static final int PICKER_REQUEST_CODE = 992;
    public static final String RESULT = "RESULT";
    private GroupPickerAdapter mAdapter;
    private RecyclerView mRecyclerView;
    private boolean mChoiceModeSingle;
    private Button mFinishPicking;
    private Dialog mProgressDialog;

    @SuppressWarnings("ConstantConditions")
    @Override
    protected void onCreate(@Nullable Bundle mSavedInstanceState) {
        super.onCreate(mSavedInstanceState);
        setContentView(R.layout.ac_group_picker);

        // Set up toolbar
        Toolbar mToolbar = findViewById(R.id.tbToolbar);
        if (mToolbar != null) {
            setSupportActionBar(mToolbar);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Select Group");
        }

        // Get choice mode
        mChoiceModeSingle = getIntent().getBooleanExtra("CHOICE_MODE", false);

        // Set up controls
        mFinishPicking = findViewById(R.id.btFinishPicking);
        mFinishPicking.setLayoutParams(doneButtonParams());
        mFinishPicking.setOnClickListener(this);
        mFinishPicking.setVisibility(View.INVISIBLE);

        // Set up contact list
        mRecyclerView = findViewById(R.id.rvRecyclerView);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Show progress bar
        mProgressDialog = UIHelper.makeProgressDialog(this);
        mProgressDialog.show();

        // Load contact list
        loadGroupList();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem mItem) {
        if (mItem.getItemId() == android.R.id.home) {
            setResult(RESULT_CANCELED);
            finish();
        }
        setResult(RESULT_CANCELED);
        finish();
        return super.onOptionsItemSelected(mItem);
    }

    @Override
    public void onClick(View mView) {
        if (mView.getId() == R.id.btFinishPicking)
            closePicker();
    }

    @Override
    public void onBackPressed() {
        setResult(RESULT_CANCELED);
        finish();
    }

    private void loadGroupList() {
        GroupPickerTask mAsyncTask = new GroupPickerTask(this, mGroupList -> {
            mAdapter = new GroupPickerAdapter(mGroupList, (mGroup, mTotalSelectedGroups) -> {
                if (mChoiceModeSingle) {
                    closePicker();
                    return;
                }
                if (mTotalSelectedGroups > 0) {
                    mFinishPicking.setVisibility(View.VISIBLE);
                    mFinishPicking.setText(getString(R.string.cp_finish_enabled, String.valueOf(mTotalSelectedGroups)));
                } else {
                    mFinishPicking.setVisibility(View.INVISIBLE);
                    mFinishPicking.setText(getString(R.string.cp_finish_disabled));
                }
            });
            mRecyclerView.setAdapter(mAdapter);

            // Set pre selected contact
            if (!mChoiceModeSingle) {
                ArrayList<GroupPickerIdName> mPreSelectList = getIntent().getParcelableArrayListExtra("PRE_SELECT_LIST");
                if (mPreSelectList != null) {
                    for (GroupPickerIdName mGroup : mPreSelectList)
                        mAdapter.setGroupPreSelected(mGroup.getGroupId());

                    int mSelectCount = mAdapter.getSelectedGroupsCount();
                    if (mSelectCount > 0) {
                        mFinishPicking.setVisibility(View.VISIBLE);
                        mFinishPicking.setText(getString(R.string.cp_finish_enabled, String.valueOf(mSelectCount)));
                    }
                }
            }

            // Close progress dialog
            if (mProgressDialog != null && mProgressDialog.isShowing()) mProgressDialog.dismiss();
        });
        mAsyncTask.execute();
    }

    private void closePicker() {
        Intent mResultIntent = new Intent();
        mResultIntent.putExtra(RESULT, GroupPickerResult.buildResult(mAdapter.getSelectedGroups()));
        setResult(RESULT_OK, mResultIntent);
        finish();
    }

    private ViewGroup.LayoutParams doneButtonParams() {
        int mWidth = getResources().getDisplayMetrics().widthPixels / 3;
        ViewGroup.LayoutParams mParams = mFinishPicking.getLayoutParams();
        mParams.width = mWidth;
        return mParams;
    }
}