package com.callfence.android.modules.calllogs;

import android.annotation.SuppressLint;
import android.content.ContentProviderClient;
import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.os.AsyncTask;
import android.provider.CallLog;
import android.util.Log;

import com.callfence.android.utilities.helpers.database.DatabaseHelper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;

class CallLogTask extends AsyncTask<Void, Void, Void> {

    private ArrayList<CallLogDataPair> mCallList;
    private CallLogsResponse mResponse;
    @SuppressLint("StaticFieldLeak")
    private Context mContext;

    CallLogTask(Context mContext, CallLogsResponse mResponse) {
        this.mContext = mContext;
        this.mResponse = mResponse;
    }

    @SuppressWarnings("ConstantConditions")
    @Override
    protected Void doInBackground(Void... mVoid) {
        try {

            // Set existing call logs list to null
            mCallList = new ArrayList<>();

            // Fetch call logs
            ContentResolver mContactResolver = mContext.getContentResolver();
            @SuppressLint("Recycle") ContentProviderClient mProviderClient = mContactResolver.acquireContentProviderClient(CallLog.Calls.CONTENT_URI);
            Cursor mCursor = mProviderClient.query(
                    CallLog.Calls.CONTENT_URI,
                    new String[]{
                            CallLog.Calls._ID,
                            CallLog.Calls.TYPE,
                            CallLog.Calls.CACHED_NAME,
                            CallLog.Calls.CACHED_PHOTO_URI,
                            CallLog.Calls.NUMBER,
                            CallLog.Calls.DATE,
                            CallLog.Calls.DURATION},
                    null, null,
                    CallLog.Calls.DATE + " DESC");

            // Add item to call logs list
            SimpleDateFormat mDateFormat = new SimpleDateFormat("EEEE, MMM dd, hh:mm a", Locale.getDefault());
            if (mCursor != null && mCursor.getCount() > 0) {
                Date mRawDate;
                while (mCursor.moveToNext()) {
                    mRawDate = new Date(Long.valueOf(mCursor.getString(5)));
                    mCallList.add(new CallLogDataPair(
                            mCursor.getString(0),
                            mCursor.getInt(1),
                            mCursor.getString(2),
                            mCursor.getString(3),
                            mCursor.getString(4),
                            mDateFormat.format(mRawDate),
                            mCursor.getString(6),
                            1,
                            mRawDate));
                }
            }
            mCursor.close();
            mProviderClient.close();

            // Fetch block logs
            DatabaseHelper mDbHelper = new DatabaseHelper(mContext);
            mCallList.addAll(mDbHelper.getBlockLogsCall());

            // Sort list
            Collections.sort(mCallList, (mPairOne, mPairTwo) -> mPairTwo.getRawDate().compareTo(mPairOne.getRawDate()));

            // Make slabs
            if (mCallList.isEmpty() || mCallList.size() <= 1) return null;
            CallLogDataPair mFirstPair = mCallList.get(0);
            int mCount = 0, mCurrType, mLastType = mFirstPair.getCallType();
            String mCurrNumber, mLastNumber = mFirstPair.getPhoneNumber();
            for (int mIterator = 1; mIterator < mCallList.size(); mIterator++) {
                CallLogDataPair mDataPair = mCallList.get(mIterator);
                mCurrType = mDataPair.getCallType();
                mCurrNumber = mDataPair.getPhoneNumber();
                if (mLastType == mCurrType && mLastNumber.equals(mCurrNumber)) {
                    mCallList.get(mCount).incCallCount();
                    mCallList.remove(mIterator--);
                } else {
                    mCount++;
                }
                mLastNumber = mCurrNumber;
                mLastType = mCurrType;
            }
        } catch (Exception mException) {
            Log.d("BLOKET_LOGS", "CallLogTask: Error fetching call logs, Details: " + mException.toString());
        }
        return null;
    }

    @Override
    protected void onPostExecute(Void mVoid) {
        mResponse.onTaskCompletion(mCallList);
    }

    public interface CallLogsResponse {

        void onTaskCompletion(ArrayList<CallLogDataPair> mCallList);

    }
}