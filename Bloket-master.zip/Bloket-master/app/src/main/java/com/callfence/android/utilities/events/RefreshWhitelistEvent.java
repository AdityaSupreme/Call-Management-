package com.callfence.android.utilities.events;

public class RefreshWhitelistEvent {

    public final Boolean mRefresh;

    public RefreshWhitelistEvent(Boolean mRefresh) {
        this.mRefresh = mRefresh;
    }
}
