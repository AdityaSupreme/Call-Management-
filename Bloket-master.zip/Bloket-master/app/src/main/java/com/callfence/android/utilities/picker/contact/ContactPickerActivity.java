package com.callfence.android.utilities.picker.contact;

import android.Manifest;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.callfence.android.R;
import com.callfence.android.utilities.helpers.ui.UIHelper;
import com.l4digital.fastscroll.FastScrollRecyclerView;

import java.util.ArrayList;

public class ContactPickerActivity extends AppCompatActivity implements View.OnClickListener {

    public static final int PICKER_REQUEST_CODE = 991;
    private ContactPickerAdapter mAdapter;
    public static final String RESULT = "RESULT";
    private FastScrollRecyclerView mRecyclerView;
    private SearchView mSearchView;
    private String mSearchText = "";
    private Button mFinishPicking;

    private static final int PERM_READ_CONTACTS = 0;
    private Dialog mProgressDialog;
    private boolean mChoiceModeSingle;

    @SuppressWarnings("ConstantConditions")
    @Override
    protected void onCreate(@Nullable Bundle mSavedInstanceState) {
        super.onCreate(mSavedInstanceState);
        setContentView(R.layout.ac_contact_picker);

        // Set up toolbar
        Toolbar mToolbar = findViewById(R.id.tbToolbar);
        if (mToolbar != null) {
            setSupportActionBar(mToolbar);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Select Contacts");
        }

        // Get choice mode
        mChoiceModeSingle = getIntent().getBooleanExtra("CHOICE_MODE", false);

        // Set up search view
        mSearchView = findViewById(R.id.svSearchView);
        View mSearchBackground = mSearchView.findViewById(androidx.appcompat.R.id.search_plate);
        mSearchBackground.setBackgroundColor(ContextCompat.getColor(this, R.color.colorTransparent));
        mSearchView.setQueryHint("Search contacts");
        mSearchView.setOnClickListener(mTempView -> mSearchView.setIconified(false));
        mSearchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String mSearchText) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String mSearchText) {
                ContactPickerActivity.this.mSearchText = mSearchText;
                if (mAdapter != null) mAdapter.getFilter().filter(mSearchText);
                return false;
            }
        });

        // Set up controls
        mFinishPicking = findViewById(R.id.btFinishPicking);
        mFinishPicking.setLayoutParams(doneButtonParams());
        mFinishPicking.setOnClickListener(this);
        mFinishPicking.setVisibility(View.INVISIBLE);

        // Set up contact list
        mRecyclerView = findViewById(R.id.rvRecyclerView);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Show progress bar
        mProgressDialog = UIHelper.makeProgressDialog(this);
        mProgressDialog.show();

        // Load contact list
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, PERM_READ_CONTACTS);
        } else {
            loadContactList();
        }

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem mItem) {
        if (mItem.getItemId() == android.R.id.home) {
            setResult(RESULT_CANCELED);
            finish();
        }
        setResult(RESULT_CANCELED);
        finish();
        return super.onOptionsItemSelected(mItem);
    }

    @Override
    public void onRequestPermissionsResult(int mRequestCode, @NonNull String[] mPermissions, @NonNull int[] mResult) {
        if (mRequestCode == PERM_READ_CONTACTS) {
            if (mResult.length > 0 && mResult[0] == PackageManager.PERMISSION_GRANTED)
                loadContactList();
            else {
                boolean mShowRationale = shouldShowRequestPermissionRationale(Manifest.permission.READ_CONTACTS);
                if (!mShowRationale)
                    UIHelper.showPermissionSnack(this, "read contacts");
                else
                    UIHelper.showImageSnack(this, "Permission denied.");
            }
        }
        super.onRequestPermissionsResult(mRequestCode, mPermissions, mResult);
    }

    @Override
    public void onClick(View mView) {
        if (mView.getId() == R.id.btFinishPicking)
            closePicker();
    }

    @Override
    public void onBackPressed() {
        if (!mSearchText.equals("")) {
            mSearchView.setQuery("", true);
            mSearchView.setIconified(true);
            mSearchView.clearFocus();
        } else {
            setResult(RESULT_CANCELED);
            finish();
        }
    }

    private void loadContactList() {
        ContactPickerTask mAsyncTask = new ContactPickerTask(this, mContactList -> {
            mAdapter = new ContactPickerAdapter(mContactList, (mContact, mTotalSelectedContacts) -> {
                if (mChoiceModeSingle) {
                    closePicker();
                    return;
                }
                if (mTotalSelectedContacts > 0) {
                    mFinishPicking.setVisibility(View.VISIBLE);
                    mFinishPicking.setText(getString(R.string.cp_finish_enabled, String.valueOf(mTotalSelectedContacts)));
                } else {
                    mFinishPicking.setVisibility(View.INVISIBLE);
                    mFinishPicking.setText(getString(R.string.cp_finish_disabled));
                }
            });
            mRecyclerView.setAdapter(mAdapter);
            mSearchView.setQueryHint("Search among your " + sizeContactList(mContactList) + " numbers");

            // Set pre selected contact
            if (!mChoiceModeSingle) {
                ArrayList<ContactPickerIdNumber> mPreSelectList = getIntent().getParcelableArrayListExtra("PRE_SELECT_LIST");
                if (mPreSelectList != null) {
                    for (ContactPickerIdNumber mContact : mPreSelectList)
                        mAdapter.setContactPreSelected(mContact.getContactId(), mContact.getPhoneNumber());

                    int mSelectCount = mAdapter.getSelectedContactsCount();
                    if (mSelectCount > 0) {
                        mFinishPicking.setVisibility(View.VISIBLE);
                        mFinishPicking.setText(getString(R.string.cp_finish_enabled, String.valueOf(mSelectCount)));
                    }
                }
            }

            // Close progress dialog
            if (mProgressDialog != null && mProgressDialog.isShowing()) mProgressDialog.dismiss();
        });
        mAsyncTask.execute();
    }

    private int sizeContactList(ArrayList<ContactPickerDataPair> mContactList) {
        int mSize = 0;
        for (ContactPickerDataPair mContact : mContactList)
            if (mContact.getContactId() != null) mSize++;
        return mSize;
    }

    private void closePicker() {
        Intent mResultIntent = new Intent();
        mResultIntent.putExtra(RESULT, ContactPickerResult.buildResult(mAdapter.getSelectedContacts()));
        setResult(RESULT_OK, mResultIntent);
        finish();
    }

    private ViewGroup.LayoutParams doneButtonParams() {
        int mWidth = getResources().getDisplayMetrics().widthPixels / 3;
        ViewGroup.LayoutParams mParams = mFinishPicking.getLayoutParams();
        mParams.width = mWidth;
        return mParams;
    }
}