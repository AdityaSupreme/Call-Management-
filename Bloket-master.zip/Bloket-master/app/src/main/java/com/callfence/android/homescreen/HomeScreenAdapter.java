package com.callfence.android.homescreen;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.callfence.android.modules.blacklist.BlacklistFragment;
import com.callfence.android.modules.calllogs.CallLogFragment;
import com.callfence.android.modules.contacts.ContactsFragment;
import com.callfence.android.modules.dialer.DialerFragment;
import com.callfence.android.modules.whitelist.WhitelistFragment;

class HomeScreenAdapter extends FragmentPagerAdapter {

    HomeScreenAdapter(FragmentManager mFragmentManager) {
        super(mFragmentManager);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                return DialerFragment.newInstance();
            case 1:
                return ContactsFragment.newInstance();
            case 2:
                return CallLogFragment.newInstance();
            case 3:
                return BlacklistFragment.newInstance();
            case 4:
                return WhitelistFragment.newInstance();
            default:
                return DialerFragment.newInstance();
        }
    }

    @Override
    public int getCount() {
        return 5;
    }
}