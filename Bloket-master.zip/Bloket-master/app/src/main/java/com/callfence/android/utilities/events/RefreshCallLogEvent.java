package com.callfence.android.utilities.events;

public class RefreshCallLogEvent {

    public final Boolean mRefresh;

    public RefreshCallLogEvent(Boolean mRefresh) {
        this.mRefresh = mRefresh;
    }
}
