package com.callfence.android.utilities.events;

public class RefreshDialerEvent {

    public final Boolean mRefresh;

    public RefreshDialerEvent(Boolean mRefresh) {
        this.mRefresh = mRefresh;
    }
}
