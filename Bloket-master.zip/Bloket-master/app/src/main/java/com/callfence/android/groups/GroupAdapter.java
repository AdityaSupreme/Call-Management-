package com.callfence.android.groups;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.callfence.android.R;
import com.callfence.android.utilities.helpers.database.DatabaseHelper;
import com.callfence.android.utilities.helpers.ui.UIHelper;
import com.callfence.android.utilities.picker.contact.ContactPickerActivity;
import com.callfence.android.utilities.picker.contact.ContactPickerIdNumber;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.ArrayList;
import java.util.regex.Pattern;

class GroupAdapter extends RecyclerView.Adapter {

    private Activity mActivity;
    private ArrayList<GroupDataPair> mGroupList;
    private DatabaseHelper mDbHelper;

    GroupAdapter(Activity mActivity, ArrayList<GroupDataPair> mGroupList) {
        this.mActivity = mActivity;
        this.mGroupList = mGroupList;
    }

    @Override
    public int getItemViewType(int mPosition) {
        if (mGroupList.isEmpty())
            return 0;
        else
            return 1;
    }

    @SuppressWarnings("NullableProblems")
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup mParent, int mViewType) {
        if (mViewType == 0) {
            View mView = LayoutInflater.from(mParent.getContext()).inflate(R.layout.ac_group_list_empty, mParent, false);
            return new EmptyViewHolder(mView);
        } else {
            View mView = LayoutInflater.from(mParent.getContext()).inflate(R.layout.ac_group_list_row, mParent, false);
            return new GroupViewHolder(mView);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder mHolder, int mPosition) {
        if (mHolder instanceof GroupViewHolder) {
            GroupViewHolder mDataHolder = ((GroupViewHolder) mHolder);
            mDataHolder.mGroupName.setText(mGroupList.get(mPosition).getGroupName());
        }
    }

    @Override
    public int getItemCount() {
        if (mGroupList.size() == 0) {
            return 1;
        } else {
            return mGroupList.size();
        }
    }

    private void updateListItem(int mPosition, String mGroupName) {
        mGroupList.get(mPosition).setGroupId(mGroupName.replaceAll(" ", "").toUpperCase());
        mGroupList.get(mPosition).setGroupName(mGroupName);
        notifyDataSetChanged();
    }

    private void removeListItem(int mPosition) {
        mGroupList.remove(mPosition);
        notifyDataSetChanged();
    }

    class GroupViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        LinearLayout mRowContainer;
        TextView mGroupName;

        GroupViewHolder(View mView) {
            super(mView);
            mGroupName = mView.findViewById(R.id.tvGroupName);
            mRowContainer = mView.findViewById(R.id.llRowContainer);

            // Set on click listener
            mRowContainer.setOnClickListener(this);
        }

        @Override
        public void onClick(View mView) {
            showOptionsDialog(getAdapterPosition());
        }

        @SuppressWarnings("ConstantConditions")
        private void showOptionsDialog(final int mPosition) {
            @SuppressLint("InflateParams") View mContentView = LayoutInflater.from(mActivity).inflate(R.layout.dg_options_group, null);
            final Dialog mDialog = new Dialog(mActivity);
            mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            mDialog.setContentView(mContentView);

            GroupDataPair mDataPair = mGroupList.get(mPosition);

            TextView mDisplayName = mDialog.findViewById(R.id.tvDisplayName);
            mDisplayName.setText(mDataPair.getGroupName());

            TextView mAddOrRemove = mContentView.findViewById(R.id.tvAddOrRemove);
            mAddOrRemove.setOnClickListener(mView -> {
                if (mDbHelper == null) mDbHelper = new DatabaseHelper(mActivity);
                GroupActivity.mGroupName = mDataPair.getGroupName();
                Intent mIntent = new Intent(mActivity, ContactPickerActivity.class);
                mIntent.putExtra("CHOICE_MODE", false);
                mIntent.putParcelableArrayListExtra("PRE_SELECT_LIST", mDbHelper.getGroupListContact(mDataPair.getGroupId()));
                mActivity.startActivityForResult(mIntent, ContactPickerActivity.PICKER_REQUEST_CODE);
                mDialog.dismiss();
            });

            TextView mRenameGroup = mContentView.findViewById(R.id.tvRenameGroup);
            mRenameGroup.setOnClickListener(mView -> {
                @SuppressLint("InflateParams") View mRenameView = LayoutInflater.from(mActivity).inflate(R.layout.ac_group_list_name, null, false);
                mDialog.setContentView(mRenameView);

                TextInputLayout mGroupNameLayout = mRenameView.findViewById(R.id.tiGroupName);
                TextInputEditText mGroupName = mRenameView.findViewById(R.id.etGroupName);
                mGroupName.setText(mDataPair.getGroupName());
                mGroupName.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence mSequence, int mStart, int mCount, int mAfter) {
                    }

                    @Override
                    public void onTextChanged(CharSequence mSequence, int mStart, int mBefore, int mCount) {
                    }

                    @Override
                    public void afterTextChanged(Editable mEditable) {
                        mGroupNameLayout.setError(null);
                    }
                });

                Button mNegative = mRenameView.findViewById(R.id.btNegative);
                mNegative.setOnClickListener(mButtonView -> {
                    UIHelper.hideSoftKeyboard(mActivity, mGroupName);
                    mDialog.dismiss();
                });

                Button mPositive = mRenameView.findViewById(R.id.btPositive);
                mPositive.setOnClickListener(mButtonView -> {
                    String mName = mGroupName.getText().toString().trim();
                    if (mName.equals(mDataPair.getGroupName())) {
                        mDialog.dismiss();
                        return;
                    }

                    Pattern mPattern = Pattern.compile("[a-zA-Z0-9 ]+");
                    if (mName.length() > 16) {
                        mGroupNameLayout.setError("Name should be less than 16 characters.");
                        return;
                    }
                    if (mName.length() > 0 && mPattern.matcher(mName).matches()) {
                        if (mDbHelper == null) mDbHelper = new DatabaseHelper(mActivity);
                        if (!mDbHelper.chkGroupListName(mName)) {
                            UIHelper.hideSoftKeyboard(mActivity, mGroupName);
                            mDbHelper.updGroupList(mDataPair.getGroupId(), mName.replaceAll(" ", "").toUpperCase(), mName);
                            mDbHelper.updBlacklistGroup(mDataPair.getGroupId(), mName.replaceAll(" ", "").toUpperCase(), mName);
                            mDbHelper.updWhitelistGroup(mDataPair.getGroupId(), mName.replaceAll(" ", "").toUpperCase(), mName);
                            updateListItem(mPosition, mName);
                            mDialog.dismiss();
                        } else {
                            mGroupNameLayout.setError("A group already exists with this name.");
                        }
                    } else {
                        mGroupNameLayout.setError("Enter a valid group name. Only letter, numbers and spaces allowed.");
                    }
                });
            });

            TextView mAddBlacklist = mContentView.findViewById(R.id.tvAddBlacklist);
            mAddBlacklist.setOnClickListener(mView -> {
                if (mDbHelper == null) mDbHelper = new DatabaseHelper(mActivity);
                if (!mDbHelper.chkBlacklistGroup(mDataPair.getGroupId())) {
                    for (ContactPickerIdNumber mContact : mDbHelper.getGroupListContact(mDataPair.getGroupId()))
                        mDbHelper.putBlacklistData(DatabaseHelper.BW_ENTRY_TYPE_GROUP, mDataPair.getGroupId(), mDataPair.getGroupName(), mContact.getContactId(), mContact.getPhoneNumber(), "", "", "", "");
                }
                Toast.makeText(mActivity, "Success", Toast.LENGTH_SHORT).show();
                mDialog.dismiss();
            });

            TextView mAddWhitelist = mContentView.findViewById(R.id.tvAddWhitelist);
            mAddWhitelist.setOnClickListener(mView -> {
                if (mDbHelper == null) mDbHelper = new DatabaseHelper(mActivity);
                if (!mDbHelper.chkWhitelistGroup(mDataPair.getGroupId())) {
                    for (ContactPickerIdNumber mContact : mDbHelper.getGroupListContact(mDataPair.getGroupId()))
                        mDbHelper.putWhitelistData(DatabaseHelper.BW_ENTRY_TYPE_GROUP, mDataPair.getGroupId(), mDataPair.getGroupName(), mContact.getContactId(), mContact.getPhoneNumber(), "", "", "");
                }
                Toast.makeText(mActivity, "Success", Toast.LENGTH_SHORT).show();
                mDialog.dismiss();
            });

            TextView mDeleteItem = mContentView.findViewById(R.id.tvDeleteItem);
            mDeleteItem.setOnClickListener(mView -> {
                if (mDbHelper == null) mDbHelper = new DatabaseHelper(mActivity);
                mDbHelper.delGroupList(mDataPair.getGroupId());
                if (mDbHelper.chkBlacklistGroup(mDataPair.getGroupId()))
                    mDbHelper.delBlacklistGroup(mDataPair.getGroupId());
                if (mDbHelper.chkWhitelistGroup(mDataPair.getGroupId()))
                    mDbHelper.delWhitelistGroup(mDataPair.getGroupId());
                removeListItem(mPosition);
                mDialog.dismiss();
            });
            mDialog.show();
        }
    }

    class EmptyViewHolder extends RecyclerView.ViewHolder {

        EmptyViewHolder(View mView) {
            super(mView);
        }
    }
}
