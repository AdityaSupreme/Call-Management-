package com.callfence.android.utilities.helpers.observers;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.ContentObserver;
import android.os.Handler;
import android.preference.PreferenceManager;

public class CallLogObserver extends ContentObserver {

    @SuppressLint("StaticFieldLeak")
    private static Context mContext;
    private static SharedPreferences mPreferences;

    public CallLogObserver(Context mContext, Handler mHandler) {
        super(mHandler);
        CallLogObserver.mContext = mContext;
    }

    public static boolean isCtsChanged(Context mContext) {
        if (CallLogObserver.mContext == null) CallLogObserver.mContext = mContext;
        if (mPreferences == null)
            mPreferences = PreferenceManager.getDefaultSharedPreferences(mContext);

        long mObTimestamp = mPreferences.getLong("BL_CL_OB_TIMESTAMP", 0);
        long mDrTimestamp = mPreferences.getLong("BL_CL_FG_TIMESTAMP", 0);
        if (mObTimestamp > mDrTimestamp) {
            putCallLogVersion(mPreferences, "BL_CL_FG_TIMESTAMP");
            return true;
        }
        return false;
    }

    public static void putCallLogVersion(SharedPreferences mPreferences, String mKeyName) {
        SharedPreferences.Editor mEditor = mPreferences.edit();
        mEditor.putLong(mKeyName, System.currentTimeMillis());
        mEditor.apply();
    }

    @Override
    public void onChange(boolean mSelfChange) {
        super.onChange(mSelfChange);
        if (mPreferences == null)
            mPreferences = PreferenceManager.getDefaultSharedPreferences(mContext);

        SharedPreferences.Editor mEditor = mPreferences.edit();
        mEditor.putLong("BL_CL_OB_TIMESTAMP", System.currentTimeMillis());
        mEditor.apply();
    }
}