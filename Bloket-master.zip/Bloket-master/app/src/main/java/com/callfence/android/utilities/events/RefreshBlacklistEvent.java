package com.callfence.android.utilities.events;

public class RefreshBlacklistEvent {

    public final Boolean mRefresh;

    public RefreshBlacklistEvent(Boolean mRefresh) {
        this.mRefresh = mRefresh;
    }
}
