package com.callfence.android.modules.whitelist;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.callfence.android.R;
import com.callfence.android.groups.GroupBulkTask;
import com.callfence.android.utilities.events.RefreshWhitelistEvent;
import com.callfence.android.utilities.helpers.database.DatabaseHelper;
import com.callfence.android.utilities.helpers.ui.UIHelper;
import com.callfence.android.utilities.picker.contact.ContactPickerActivity;
import com.callfence.android.utilities.picker.contact.ContactPickerResult;
import com.callfence.android.utilities.picker.group.GroupPickerActivity;
import com.callfence.android.utilities.picker.group.GroupPickerResult;
import com.github.florent37.singledateandtimepicker.dialog.DoubleDateAndTimePickerDialog;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.regex.Pattern;

import static android.app.Activity.RESULT_OK;

public class WhitelistFragment extends Fragment {

    public DoubleDateAndTimePickerDialog mPickerDialog;
    private WhitelistAdapter mAdapter;
    private DatabaseHelper mDbHelper;
    private RecyclerView mRecyclerView;

    public static WhitelistFragment newInstance() {
        return new WhitelistFragment();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater mInflater, @Nullable ViewGroup mContainer, @Nullable Bundle mSavedInstance) {
        View mView = mInflater.inflate(R.layout.fm_whitelist_layout, mContainer, false);
        mDbHelper = new DatabaseHelper(getContext());
        mRecyclerView = mView.findViewById(R.id.rvRecyclerView);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        return mView;
    }

    @Override
    public void onStart() {
        super.onStart();
        EventBus.getDefault().register(this);
    }

    @SuppressWarnings("ConstantConditions")
    @Override
    public void onResume() {
        super.onResume();
        if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
            return;

        mAdapter = new WhitelistAdapter(this, getContext(), mDbHelper.getWhitelistData());
        mRecyclerView.setAdapter(mAdapter);
    }

    @Override
    public void onStop() {
        EventBus.getDefault().unregister(this);
        super.onStop();
    }

    @SuppressWarnings("ConstantConditions")
    @Override
    public void onActivityResult(int mRequestCode, int mResultCode, Intent mData) {
        super.onActivityResult(mRequestCode, mResultCode, mData);
        if (mRequestCode == ContactPickerActivity.PICKER_REQUEST_CODE) {
            if (mResultCode != RESULT_OK) return;
            ArrayList<ContactPickerResult> mSelectedContacts = new ArrayList<>(ContactPickerResult.obtainResult(mData));
            WhitelistAddTask mAddTask = new WhitelistAddTask(getContext(), mSelectedContacts, mSuccess -> {
                if (mSuccess) {
                    mAdapter = new WhitelistAdapter(this, getContext(), mDbHelper.getWhitelistData());
                    mRecyclerView.setAdapter(mAdapter);
                }
            });
            mAddTask.execute();
        }

        if (mRequestCode == GroupPickerActivity.PICKER_REQUEST_CODE) {
            if (mResultCode != RESULT_OK) return;
            ArrayList<GroupPickerResult> mSelectedGroup = new ArrayList<>(GroupPickerResult.obtainResult(mData));
            GroupBulkTask mAddTask = new GroupBulkTask(getContext(), mSelectedGroup, false, mSuccess -> {
                if (mSuccess) {
                    mAdapter = new WhitelistAdapter(this, getContext(), mDbHelper.getWhitelistData());
                    mRecyclerView.setAdapter(mAdapter);
                }
            });
            mAddTask.execute();
        }
    }

    @SuppressWarnings({"unused", "ConstantConditions"})
    @Subscribe(threadMode = ThreadMode.POSTING)
    public void onMessageEvent(RefreshWhitelistEvent mEvent) {
        if (mEvent.mRefresh) {
            mAdapter = new WhitelistAdapter(this, getContext(), mDbHelper.getWhitelistData());
            mRecyclerView.setAdapter(mAdapter);
        }
    }

    public void fabClickAction() {
        showAddDialog();
    }

    @SuppressWarnings("ConstantConditions")
    private void showAddDialog() {
        @SuppressLint("InflateParams") View mContentView = LayoutInflater.from(getContext()).inflate(R.layout.fm_whitelist_option_add, null, false);
        final Dialog mDialog = new Dialog(getContext());
        mDialog.setCanceledOnTouchOutside(false);
        mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        mDialog.setContentView(mContentView);

        TextView mAddContact = mContentView.findViewById(R.id.tvAddContact);
        mAddContact.setOnClickListener(mView -> {
            if (mDbHelper == null) mDbHelper = new DatabaseHelper(getContext());
            Intent mIntent = new Intent(getActivity(), ContactPickerActivity.class);
            mIntent.putExtra("CHOICE_MODE", false);
            mIntent.putParcelableArrayListExtra("PRE_SELECT_LIST", mDbHelper.getWhitelistContacts());
            startActivityForResult(mIntent, ContactPickerActivity.PICKER_REQUEST_CODE);
            mDialog.dismiss();
        });

        TextView mAddGroup = mContentView.findViewById(R.id.tvAddGroup);
        mAddGroup.setOnClickListener(mView -> {
            if (mDbHelper == null) mDbHelper = new DatabaseHelper(getContext());
            Intent mIntent = new Intent(getActivity(), GroupPickerActivity.class);
            mIntent.putExtra("CHOICE_MODE", false);
            mIntent.putParcelableArrayListExtra("PRE_SELECT_LIST", mDbHelper.getWhitelistGroup());
            startActivityForResult(mIntent, GroupPickerActivity.PICKER_REQUEST_CODE);
            mDialog.dismiss();
        });

        TextView mAddNumber = mContentView.findViewById(R.id.tvAddNumber);
        mAddNumber.setOnClickListener(mView -> dialogLayoutNumber(mDialog));

        TextView mAddStarts = mContentView.findViewById(R.id.tvAddStarts);
        mAddStarts.setOnClickListener(mView -> dialogLayoutStarts(mDialog));

        TextView mAddEnds = mContentView.findViewById(R.id.tvAddEnds);
        mAddEnds.setOnClickListener(mView -> dialogLayoutEnds(mDialog));

        TextView mAddContains = mContentView.findViewById(R.id.tvAddContains);
        mAddContains.setOnClickListener(mView -> dialogLayoutContains(mDialog));

        TextView mAddRange = mContentView.findViewById(R.id.tvAddRange);
        mAddRange.setOnClickListener(mView -> dialogLayoutRange(mDialog));
        mDialog.show();
    }

    @SuppressWarnings("ConstantConditions")
    @SuppressLint("InflateParams")
    private void dialogLayoutNumber(Dialog mDialog) {
        View mAddNumberView = LayoutInflater.from(getContext()).inflate(R.layout.dg_generic_add_number, null, false);
        mDialog.setContentView(mAddNumberView);

        TextInputLayout mPhoneNumberLayout = mAddNumberView.findViewById(R.id.tiPhoneNumber);
        TextInputEditText mPhoneNumber = mAddNumberView.findViewById(R.id.etPhoneNumber);
        mPhoneNumber.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence mSequence, int mStart, int mCount, int mAfter) {
            }

            @Override
            public void onTextChanged(CharSequence mSequence, int mStart, int mBefore, int mCount) {
            }

            @Override
            public void afterTextChanged(Editable mEditable) {
                mPhoneNumberLayout.setError(null);
            }
        });

        Button mNegative = mAddNumberView.findViewById(R.id.btNegative);
        mNegative.setOnClickListener(mButtonView -> {
            UIHelper.hideSoftKeyboard(getContext(), mPhoneNumber);
            mDialog.dismiss();
        });

        Button mPositive = mAddNumberView.findViewById(R.id.btPositive);
        mPositive.setOnClickListener(mButtonView -> {
            String mNumber = mPhoneNumber.getText().toString();
            Pattern mPattern = Pattern.compile("[0-9+]+");
            if (!mPattern.matcher(mNumber).matches()) {
                mPhoneNumberLayout.setError("Enter a valid number.");
                return;
            }

            if (mDbHelper == null) mDbHelper = new DatabaseHelper(getContext());
            if (!mDbHelper.chkWhitelistNumber(mNumber)) {
                mDbHelper.putWhitelistData(DatabaseHelper.BW_ENTRY_TYPE_NUMBER, DatabaseHelper.DEFAULT_GROUP_ID, "", "", mNumber, "", "", "");
                mAdapter = new WhitelistAdapter(this, getContext(), mDbHelper.getWhitelistData());
                mRecyclerView.setAdapter(mAdapter);
                UIHelper.hideSoftKeyboard(getContext(), mPhoneNumber);
                mDialog.dismiss();
            } else {
                mPhoneNumberLayout.setError("Number is already stored in whitelist.");
            }
        });
    }

    @SuppressWarnings("ConstantConditions")
    @SuppressLint("InflateParams")
    private void dialogLayoutStarts(Dialog mDialog) {
        View mAddStartsView = LayoutInflater.from(getContext()).inflate(R.layout.dg_generic_add_starts, null, false);
        mDialog.setContentView(mAddStartsView);

        TextInputLayout mPhoneNumberLayout = mAddStartsView.findViewById(R.id.tiPhoneNumber);
        TextInputEditText mPhoneNumber = mAddStartsView.findViewById(R.id.etPhoneNumber);
        mPhoneNumber.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence mSequence, int mStart, int mCount, int mAfter) {
            }

            @Override
            public void onTextChanged(CharSequence mSequence, int mStart, int mBefore, int mCount) {
            }

            @Override
            public void afterTextChanged(Editable mEditable) {
                mPhoneNumberLayout.setError(null);
            }
        });

        Button mNegative = mAddStartsView.findViewById(R.id.btNegative);
        mNegative.setOnClickListener(mButtonView -> {
            UIHelper.hideSoftKeyboard(getContext(), mPhoneNumber);
            mDialog.dismiss();
        });

        Button mPositive = mAddStartsView.findViewById(R.id.btPositive);
        mPositive.setOnClickListener(mButtonView -> {
            String mNumber = mPhoneNumber.getText().toString();
            Pattern mPattern = Pattern.compile("[0-9]+");
            if (!mPattern.matcher(mNumber).matches()) {
                mPhoneNumberLayout.setError("Enter a valid number.");
                return;
            }

            if (mDbHelper == null) mDbHelper = new DatabaseHelper(getContext());
            if (!mDbHelper.chkWhitelistStarts(mNumber)) {
                mDbHelper.putWhitelistData(DatabaseHelper.BW_ENTRY_TYPE_STARTS, DatabaseHelper.DEFAULT_GROUP_ID, "", "", mNumber, "", "", "");
                mAdapter = new WhitelistAdapter(this, getContext(), mDbHelper.getWhitelistData());
                mRecyclerView.setAdapter(mAdapter);
                UIHelper.hideSoftKeyboard(getContext(), mPhoneNumber);
                mDialog.dismiss();
            } else {
                mPhoneNumberLayout.setError("Entry is already stored in whitelist.");
            }
        });
    }

    @SuppressWarnings("ConstantConditions")
    @SuppressLint("InflateParams")
    private void dialogLayoutEnds(Dialog mDialog) {
        View mAddEndsView = LayoutInflater.from(getContext()).inflate(R.layout.dg_generic_add_ends, null, false);
        mDialog.setContentView(mAddEndsView);

        TextInputLayout mPhoneNumberLayout = mAddEndsView.findViewById(R.id.tiPhoneNumber);
        TextInputEditText mPhoneNumber = mAddEndsView.findViewById(R.id.etPhoneNumber);
        mPhoneNumber.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence mSequence, int mStart, int mCount, int mAfter) {
            }

            @Override
            public void onTextChanged(CharSequence mSequence, int mStart, int mBefore, int mCount) {
            }

            @Override
            public void afterTextChanged(Editable mEditable) {
                mPhoneNumberLayout.setError(null);
            }
        });

        Button mNegative = mAddEndsView.findViewById(R.id.btNegative);
        mNegative.setOnClickListener(mButtonView -> {
            UIHelper.hideSoftKeyboard(getContext(), mPhoneNumber);
            mDialog.dismiss();
        });

        Button mPositive = mAddEndsView.findViewById(R.id.btPositive);
        mPositive.setOnClickListener(mButtonView -> {
            String mNumber = mPhoneNumber.getText().toString();
            Pattern mPattern = Pattern.compile("[0-9]+");
            if (!mPattern.matcher(mNumber).matches()) {
                mPhoneNumberLayout.setError("Enter a valid number.");
                return;
            }

            if (mDbHelper == null) mDbHelper = new DatabaseHelper(getContext());
            if (!mDbHelper.chkWhitelistEnds(mNumber)) {
                mDbHelper.putWhitelistData(DatabaseHelper.BW_ENTRY_TYPE_ENDS, DatabaseHelper.DEFAULT_GROUP_ID, "", "", mNumber, "", "", "");
                mAdapter = new WhitelistAdapter(this, getContext(), mDbHelper.getWhitelistData());
                mRecyclerView.setAdapter(mAdapter);
                UIHelper.hideSoftKeyboard(getContext(), mPhoneNumber);
                mDialog.dismiss();
            } else {
                mPhoneNumberLayout.setError("Entry is already stored in whitelist.");
            }
        });
    }

    @SuppressWarnings("ConstantConditions")
    @SuppressLint("InflateParams")
    private void dialogLayoutContains(Dialog mDialog) {
        View mAddContainsView = LayoutInflater.from(getContext()).inflate(R.layout.dg_generic_add_contains, null, false);
        mDialog.setContentView(mAddContainsView);

        TextInputLayout mPhoneNumberLayout = mAddContainsView.findViewById(R.id.tiPhoneNumber);
        TextInputEditText mPhoneNumber = mAddContainsView.findViewById(R.id.etPhoneNumber);
        mPhoneNumber.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence mSequence, int mStart, int mCount, int mAfter) {
            }

            @Override
            public void onTextChanged(CharSequence mSequence, int mStart, int mBefore, int mCount) {
            }

            @Override
            public void afterTextChanged(Editable mEditable) {
                mPhoneNumberLayout.setError(null);
            }
        });

        Button mNegative = mAddContainsView.findViewById(R.id.btNegative);
        mNegative.setOnClickListener(mButtonView -> {
            UIHelper.hideSoftKeyboard(getContext(), mPhoneNumber);
            mDialog.dismiss();
        });

        Button mPositive = mAddContainsView.findViewById(R.id.btPositive);
        mPositive.setOnClickListener(mButtonView -> {
            String mNumber = mPhoneNumber.getText().toString();
            Pattern mPattern = Pattern.compile("[0-9]+");
            if (!mPattern.matcher(mNumber).matches()) {
                mPhoneNumberLayout.setError("Enter a valid number.");
                return;
            }

            if (mDbHelper == null) mDbHelper = new DatabaseHelper(getContext());
            if (!mDbHelper.chkWhitelistContains(mNumber)) {
                mDbHelper.putWhitelistData(DatabaseHelper.BW_ENTRY_TYPE_CONTAINS, DatabaseHelper.DEFAULT_GROUP_ID, "", "", mNumber, "", "", "");
                mAdapter = new WhitelistAdapter(this, getContext(), mDbHelper.getWhitelistData());
                mRecyclerView.setAdapter(mAdapter);
                UIHelper.hideSoftKeyboard(getContext(), mPhoneNumber);
                mDialog.dismiss();
            } else {
                mPhoneNumberLayout.setError("Entry is already stored in whitelist.");
            }
        });
    }

    @SuppressWarnings("ConstantConditions")
    @SuppressLint("InflateParams")
    private void dialogLayoutRange(Dialog mDialog) {
        View mAddRangeView = LayoutInflater.from(getContext()).inflate(R.layout.dg_generic_add_range, null, false);
        mDialog.setContentView(mAddRangeView);

        TextInputLayout mRangeStartLayout = mAddRangeView.findViewById(R.id.tiRangeStart);
        TextInputEditText mRangeStart = mAddRangeView.findViewById(R.id.etRangeStart);
        mRangeStart.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence mSequence, int mStart, int mCount, int mAfter) {
            }

            @Override
            public void onTextChanged(CharSequence mSequence, int mStart, int mBefore, int mCount) {
            }

            @Override
            public void afterTextChanged(Editable mEditable) {
                mRangeStartLayout.setError(null);
            }
        });

        TextInputLayout mRangeEndLayout = mAddRangeView.findViewById(R.id.tiRangeEnd);
        TextInputEditText mRangeEnd = mAddRangeView.findViewById(R.id.etRangeEnd);
        mRangeEnd.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence mSequence, int mStart, int mCount, int mAfter) {
            }

            @Override
            public void onTextChanged(CharSequence mSequence, int mStart, int mBefore, int mCount) {
            }

            @Override
            public void afterTextChanged(Editable mEditable) {
                mRangeEndLayout.setError(null);
            }
        });

        Button mNegative = mAddRangeView.findViewById(R.id.btNegative);
        mNegative.setOnClickListener(mButtonView -> {
            UIHelper.hideSoftKeyboard(getContext(), mNegative);
            mDialog.dismiss();
        });

        Button mPositive = mAddRangeView.findViewById(R.id.btPositive);
        mPositive.setOnClickListener(mButtonView -> {
            String mStartNumber = mRangeStart.getText().toString();
            String mEndNumber = mRangeEnd.getText().toString();
            Pattern mPattern = Pattern.compile("[0-9]+");

            if (!mPattern.matcher(mStartNumber).matches()) {
                mRangeStartLayout.setError("Enter a valid number.");
                return;
            }
            if (!mPattern.matcher(mEndNumber).matches()) {
                mRangeEndLayout.setError("Enter a valid number.");
                return;
            }

            long mNumberOne = Long.valueOf(mStartNumber);
            long mNumberTwo = Long.valueOf(mEndNumber);

            if (mNumberOne >= mNumberTwo) {
                mRangeStartLayout.setError("First number must be less than last number.");
                return;
            }
            if (mDbHelper == null) mDbHelper = new DatabaseHelper(getContext());
            if (!mDbHelper.chkWhitelistRange(String.valueOf(mNumberOne), String.valueOf(mNumberTwo))) {
                mDbHelper.putWhitelistData(DatabaseHelper.BW_ENTRY_TYPE_RANGE, DatabaseHelper.DEFAULT_GROUP_ID, "", "", String.valueOf(mNumberOne), String.valueOf(mNumberTwo), "", "");
                mAdapter = new WhitelistAdapter(this, getContext(), mDbHelper.getWhitelistData());
                mRecyclerView.setAdapter(mAdapter);
                UIHelper.hideSoftKeyboard(getContext(), mPositive);
                mDialog.dismiss();
            } else {
                mRangeEndLayout.setError("Entry is already stored in whitelist.");
            }
        });
    }
}