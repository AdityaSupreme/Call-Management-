package com.callfence.android.utilities.picker.group;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.AsyncTask;
import android.util.Log;

import com.callfence.android.groups.GroupDataPair;
import com.callfence.android.utilities.helpers.database.DatabaseHelper;

import java.util.ArrayList;

class GroupPickerTask extends AsyncTask<Void, Void, Void> {

    @SuppressLint("StaticFieldLeak")
    private Activity mActivity;
    private ArrayList<GroupDataPair> mGroupList;
    private GroupPickerResponse mResponse;

    GroupPickerTask(Activity mActivity, GroupPickerResponse mResponse) {
        this.mActivity = mActivity;
        this.mResponse = mResponse;
    }

    @Override
    protected Void doInBackground(Void... mVoid) {
        try {

            // Initialize contact list
            mGroupList = new ArrayList<>();

            // Fetch groups
            DatabaseHelper mDbHelper = new DatabaseHelper(mActivity);
            mGroupList = mDbHelper.getGroupList();
        } catch (Exception mException) {
            Log.d("BLOKET_LOGS", "ContactPickerTask: Error fetching contacts for contact picker, Details: " + mException.toString());
        }
        return null;
    }

    @Override
    protected void onPostExecute(Void mVoid) {
        mResponse.onTaskCompletion(mGroupList);
    }

    public interface GroupPickerResponse {

        void onTaskCompletion(ArrayList<GroupDataPair> mGroupList);

    }
}