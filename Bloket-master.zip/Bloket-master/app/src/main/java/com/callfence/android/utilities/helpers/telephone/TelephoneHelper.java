package com.callfence.android.utilities.helpers.telephone;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;

import androidx.core.app.ActivityCompat;

import java.util.List;

public class TelephoneHelper {

    public static void placeCall(Context mContext, String mNumber) {
        if (mNumber.length() < 1) return;
        if (ActivityCompat.checkSelfPermission(mContext, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED)
            return;

        Intent mCallIntent = new Intent(Intent.ACTION_CALL);
        mCallIntent.setData(Uri.parse("tel:" + Uri.encode(mNumber)));
        mCallIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        mContext.startActivity(mCallIntent);

    }

    @SuppressWarnings("ConstantConditions")
    public static boolean isDualSimDevice(Context mContext) {
        if (ActivityCompat.checkSelfPermission(mContext, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED)
            return false;

        final SubscriptionManager mManager = (SubscriptionManager) mContext.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
        final List<SubscriptionInfo> mActiveSubList = mManager.getActiveSubscriptionInfoList();
        return mActiveSubList.size() > 1;
    }
}