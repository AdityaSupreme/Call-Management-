package com.callfence.android.modules.whitelist;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.callfence.android.R;
import com.callfence.android.utilities.helpers.database.DatabaseHelper;
import com.github.florent37.singledateandtimepicker.dialog.DoubleDateAndTimePickerDialog;
import com.mikhaellopez.circularimageview.CircularImageView;

import java.util.ArrayList;
import java.util.Date;

class WhitelistAdapter extends RecyclerView.Adapter {

    private ArrayList<WhitelistDataPair> mList;
    private ContentResolver mContentResolver;
    private Context mContext;
    private DatabaseHelper mDbHelper;
    private WhitelistFragment mFragment;

    WhitelistAdapter(WhitelistFragment mFragment, Context mContext, ArrayList<WhitelistDataPair> mList) {
        this.mFragment = mFragment;
        this.mContext = mContext;
        this.mList = mList;
        this.mContentResolver = mContext.getContentResolver();
        this.mDbHelper = new DatabaseHelper(mContext);
    }

    @Override
    public int getItemViewType(int mPosition) {
        if (mList.isEmpty()) {
            return 0;
        } else {
            return mList.get(mPosition).getType();
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup mParent, int mViewType) {
        if (mViewType == 0) {
            View mView = LayoutInflater.from(mParent.getContext()).inflate(R.layout.fm_whitelist_empty, mParent, false);
            return new EmptyViewHolder(mView);
        } else if (mViewType == DatabaseHelper.BW_ENTRY_TYPE_CONTACT) {
            View mView = LayoutInflater.from(mParent.getContext()).inflate(R.layout.fm_whitelist_row, mParent, false);
            return new ContactViewHolder(mView);
        } else if (mViewType == DatabaseHelper.BW_ENTRY_TYPE_NUMBER) {
            View mView = LayoutInflater.from(mParent.getContext()).inflate(R.layout.fm_whitelist_row, mParent, false);
            return new NumberViewHolder(mView);
        } else if (mViewType == DatabaseHelper.BW_ENTRY_TYPE_STARTS) {
            View mView = LayoutInflater.from(mParent.getContext()).inflate(R.layout.fm_whitelist_row, mParent, false);
            return new StartsViewHolder(mView);
        } else if (mViewType == DatabaseHelper.BW_ENTRY_TYPE_ENDS) {
            View mView = LayoutInflater.from(mParent.getContext()).inflate(R.layout.fm_whitelist_row, mParent, false);
            return new EndsViewHolder(mView);
        } else if (mViewType == DatabaseHelper.BW_ENTRY_TYPE_CONTAINS) {
            View mView = LayoutInflater.from(mParent.getContext()).inflate(R.layout.fm_whitelist_row, mParent, false);
            return new ContainsViewHolder(mView);
        } else if (mViewType == DatabaseHelper.BW_ENTRY_TYPE_RANGE) {
            View mView = LayoutInflater.from(mParent.getContext()).inflate(R.layout.fm_whitelist_row, mParent, false);
            return new RangeViewHolder(mView);
        } else {
            View mView = LayoutInflater.from(mParent.getContext()).inflate(R.layout.fm_whitelist_row, mParent, false);
            return new GroupViewHolder(mView);
        }
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder mHolder, int mPosition) {
        if (mHolder instanceof ContactViewHolder) {
            WhitelistDataPair mDataPair = mList.get(mPosition);
            ContactViewHolder mDataHolder = ((ContactViewHolder) mHolder);

            if (mDataPair.getDisplayName() == null || mDataPair.getPhotoUri() == null) {
                String[] mDetails = getNameAndImage(mDataPair.getContactId());
                mDataPair.setDisplayName(mDetails[0] == null || mDetails[0].equals("") ? mDataPair.getMatchData() : mDetails[0]);
                mDataPair.setPhotoUri(mDetails[1]);
            }

            mDataHolder.mContactName.setText(mDataPair.getDisplayName());
            if (mDataPair.getDisplayName().equals(mDataPair.getMatchData())) {
                mDataHolder.mPhoneNumber.setVisibility(View.GONE);
            } else {
                mDataHolder.mPhoneNumber.setVisibility(View.VISIBLE);
                mDataHolder.mPhoneNumber.setText(mDataPair.getMatchData());
            }

            if ((mDataPair.getPhotoUri() == null || mDataPair.getPhotoUri().equals("")) && !mDataPair.getDisplayName().equals("")) {
                mDataHolder.mContactLetter.setVisibility(View.VISIBLE);
                mDataHolder.mContactLetter.setText(mDataPair.getDisplayName().substring(0, 1));
                mDataHolder.mContactImage.setImageResource(R.drawable.ic_contact_default);
            } else {
                mDataHolder.mContactLetter.setVisibility(View.INVISIBLE);
                mDataHolder.mContactImage.setImageURI(Uri.parse(mDataPair.getPhotoUri()));
            }

            mDataHolder.mActionSchedule.setVisibility(mDataPair.getStartTime().length() > 0 ? View.VISIBLE : View.GONE);
        }

        if (mHolder instanceof NumberViewHolder) {
            WhitelistDataPair mDataPair = mList.get(mPosition);
            NumberViewHolder mDataHolder = ((NumberViewHolder) mHolder);
            mDataHolder.mPhoneNumber.setVisibility(View.GONE);
            mDataHolder.mContactName.setText(mDataPair.getMatchData());
            mDataHolder.mContactLetter.setText(mDataPair.getMatchData().substring(0, 1));
            mDataHolder.mContactImage.setImageResource(R.drawable.ic_contact_default);
            mDataHolder.mActionSchedule.setVisibility(mDataPair.getStartTime().length() > 0 ? View.VISIBLE : View.GONE);
        }

        if (mHolder instanceof StartsViewHolder) {
            WhitelistDataPair mDataPair = mList.get(mPosition);
            StartsViewHolder mDataHolder = ((StartsViewHolder) mHolder);
            mDataHolder.mContactName.setText(mContext.getString(R.string.gr_title_starts));
            mDataHolder.mPhoneNumber.setText(mDataPair.getMatchData());
            mDataHolder.mContactLetter.setText("?..");
            mDataHolder.mContactImage.setImageResource(R.drawable.ic_contact_default);
            mDataHolder.mActionSchedule.setVisibility(mDataPair.getStartTime().length() > 0 ? View.VISIBLE : View.GONE);
        }

        if (mHolder instanceof EndsViewHolder) {
            WhitelistDataPair mDataPair = mList.get(mPosition);
            EndsViewHolder mDataHolder = ((EndsViewHolder) mHolder);
            mDataHolder.mContactName.setText(mContext.getString(R.string.gr_title_ends));
            mDataHolder.mPhoneNumber.setText(mDataPair.getMatchData());
            mDataHolder.mContactLetter.setText("..?");
            mDataHolder.mContactImage.setImageResource(R.drawable.ic_contact_default);
            mDataHolder.mActionSchedule.setVisibility(mDataPair.getStartTime().length() > 0 ? View.VISIBLE : View.GONE);
        }

        if (mHolder instanceof ContainsViewHolder) {
            WhitelistDataPair mDataPair = mList.get(mPosition);
            ContainsViewHolder mDataHolder = ((ContainsViewHolder) mHolder);
            mDataHolder.mContactName.setText(mContext.getString(R.string.gr_title_contains));
            mDataHolder.mPhoneNumber.setText(mDataPair.getMatchData());
            mDataHolder.mContactLetter.setText(".?.");
            mDataHolder.mContactImage.setImageResource(R.drawable.ic_contact_default);
            mDataHolder.mActionSchedule.setVisibility(mDataPair.getStartTime().length() > 0 ? View.VISIBLE : View.GONE);
        }

        if (mHolder instanceof RangeViewHolder) {
            WhitelistDataPair mDataPair = mList.get(mPosition);
            RangeViewHolder mDataHolder = ((RangeViewHolder) mHolder);
            mDataHolder.mContactName.setText(mContext.getString(R.string.gr_title_range));
            mDataHolder.mPhoneNumber.setText(mDataPair.getMatchData() + " to " + mDataPair.getRangeData());
            mDataHolder.mContactLetter.setText("?.?");
            mDataHolder.mContactImage.setImageResource(R.drawable.ic_contact_default);
            mDataHolder.mActionSchedule.setVisibility(mDataPair.getStartTime().length() > 0 ? View.VISIBLE : View.GONE);
        }

        if (mHolder instanceof GroupViewHolder) {
            WhitelistDataPair mDataPair = mList.get(mPosition);
            GroupViewHolder mDataHolder = ((GroupViewHolder) mHolder);
            mDataHolder.mContactName.setText(mContext.getString(R.string.gr_title_group));
            mDataHolder.mPhoneNumber.setText(mDataPair.getGroupName());
            mDataHolder.mContactLetter.setVisibility(View.GONE);
            mDataHolder.mContactImage.setImageResource(R.drawable.ic_action_group);
            mDataHolder.mActionSchedule.setVisibility(mDataPair.getStartTime().length() > 0 ? View.VISIBLE : View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        if (mList.size() == 0) {
            return 1;
        } else {
            return mList.size();
        }
    }

    private String[] getNameAndImage(String mContactId) {
        String mContactName = "", mContactImage = "";
        if (mContactId == null || mContactId.equals(""))
            return new String[]{mContactName, mContactImage};

        final Cursor mCursor = mContentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.Contacts.DISPLAY_NAME, ContactsContract.Contacts.PHOTO_URI},
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                new String[]{mContactId}, null);
        if (mCursor != null && mCursor.moveToFirst()) {
            mContactName = mCursor.getString(0);
            mContactImage = mCursor.getString(1);
        }
        if (mCursor != null) mCursor.close();
        return new String[]{mContactName, mContactImage};
    }

    private void removeListItem(int mPosition) {
        mList.remove(mPosition);
        notifyDataSetChanged();
    }

    @SuppressLint({"InflateParams", "SetTextI18n"})
    private void showOptionsDialog(final int mPosition, final int mType, final String mTitle, final String mDescription) {
        View mContentView = LayoutInflater.from(mContext).inflate(R.layout.fm_whitelist_option, null);
        final Dialog mDialog = new Dialog(mContext);
        mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        mDialog.setContentView(mContentView);

        TextView mTitleView = mDialog.findViewById(R.id.tvTitle);
        mTitleView.setText(mTitle);
        TextView mDescriptionView = mDialog.findViewById(R.id.tvDescription);
        mDescriptionView.setText(mDescription);

        TextView mSetTime = mContentView.findViewById(R.id.tvSetTime);
        mSetTime.setOnClickListener(mView -> {
            setAllowSchedule(mPosition);
            mDialog.dismiss();
        });

        TextView mRemoveTime = mContentView.findViewById(R.id.tvRemoveTime);
        mRemoveTime.setOnClickListener(mView -> {
            delAllowSchedule(mPosition);
            mDialog.dismiss();
        });

        TextView mDeleteItem = mContentView.findViewById(R.id.tvDeleteItem);
        mDeleteItem.setOnClickListener(mView -> {
            switch (mType) {
                case DatabaseHelper.BW_ENTRY_TYPE_CONTACT:
                    removeTypeContact(mPosition);
                    break;

                case DatabaseHelper.BW_ENTRY_TYPE_NUMBER:
                    removeTypeNumber(mPosition);
                    break;

                case DatabaseHelper.BW_ENTRY_TYPE_STARTS:
                    removeTypeStarts(mPosition);
                    break;

                case DatabaseHelper.BW_ENTRY_TYPE_ENDS:
                    removeTypeEnds(mPosition);
                    break;

                case DatabaseHelper.BW_ENTRY_TYPE_CONTAINS:
                    removeTypeContains(mPosition);
                    break;

                case DatabaseHelper.BW_ENTRY_TYPE_RANGE:
                    removeTypeRange(mPosition);
                    break;

                case DatabaseHelper.BW_ENTRY_TYPE_GROUP:
                    removeTypeGroup(mPosition);
                    break;

                default:
                    break;
            }
            mDialog.dismiss();
        });
        mDialog.show();
    }

    private void setAllowSchedule(final int mPosition) {
        if (mDbHelper == null) mDbHelper = new DatabaseHelper(mContext);
        String[] mSchedule = mDbHelper.getWhitelistSchedule(mList.get(mPosition).getId());
        Date mDateOne = (mSchedule == null || mSchedule[0].equals("")) ? new Date(System.currentTimeMillis()) : new Date(Long.valueOf(mSchedule[0]));
        Date mDateTwo = (mSchedule == null || mSchedule[1].equals("")) ? new Date(System.currentTimeMillis()) : new Date(Long.valueOf(mSchedule[1]));
        mFragment.mPickerDialog = new DoubleDateAndTimePickerDialog.Builder(mContext)
                .titleTextColor(mContext.getColor(R.color.colorWhite))
                .backgroundColor(mContext.getColor(R.color.colorWhite))
                .mainColor(mContext.getColor(R.color.colorPrimary))
                .tab0Text(mContext.getString(R.string.bp_start_time))
                .tab0Date(mDateOne)
                .tab1Text(mContext.getString(R.string.bp_end_time))
                .tab1Date(mDateTwo)
                .minutesStep(1)
                .buttonOkText(mContext.getString(R.string.gr_btn_set))
                .listener(mDates -> {
                    long mStrDate = mDates.get(0).getTime();
                    long mEndDate = mDates.get(1).getTime();
                    mDbHelper.updWhitelistSchedule(mList.get(mPosition).getId(), String.valueOf(mStrDate), String.valueOf(mEndDate));

                    mList.get(mPosition).setStartTime(String.valueOf(mStrDate));
                    mList.get(mPosition).setEndTime(String.valueOf(mEndDate));
                    notifyDataSetChanged();
                }).build();
        mFragment.mPickerDialog.display();
    }

    private void delAllowSchedule(final int mPosition) {
        if (mDbHelper == null) mDbHelper = new DatabaseHelper(mContext);
        mDbHelper.updWhitelistSchedule(mList.get(mPosition).getId(), "", "");

        mList.get(mPosition).setStartTime("");
        mList.get(mPosition).setEndTime("");
        notifyDataSetChanged();
    }

    private void removeTypeContact(final int mPosition) {
        if (mDbHelper == null) mDbHelper = new DatabaseHelper(mContext);
        mDbHelper.delWhitelistContact(Integer.valueOf(mList.get(mPosition).getContactId()), mList.get(mPosition).getMatchData());
        removeListItem(mPosition);
    }

    private void removeTypeNumber(final int mPosition) {
        if (mDbHelper == null) mDbHelper = new DatabaseHelper(mContext);
        mDbHelper.delWhitelistNumber(mList.get(mPosition).getMatchData());
        removeListItem(mPosition);
    }

    private void removeTypeStarts(final int mPosition) {
        if (mDbHelper == null) mDbHelper = new DatabaseHelper(mContext);
        mDbHelper.delWhitelistStarts(mList.get(mPosition).getMatchData());
        removeListItem(mPosition);
    }

    private void removeTypeEnds(final int mPosition) {
        if (mDbHelper == null) mDbHelper = new DatabaseHelper(mContext);
        mDbHelper.delWhitelistEnds(mList.get(mPosition).getMatchData());
        removeListItem(mPosition);
    }

    private void removeTypeContains(final int mPosition) {
        if (mDbHelper == null) mDbHelper = new DatabaseHelper(mContext);
        mDbHelper.delWhitelistContains(mList.get(mPosition).getMatchData());
        removeListItem(mPosition);
    }

    private void removeTypeRange(final int mPosition) {
        if (mDbHelper == null) mDbHelper = new DatabaseHelper(mContext);
        mDbHelper.delWhitelistRange(mList.get(mPosition).getMatchData(), mList.get(mPosition).getRangeData());
        removeListItem(mPosition);
    }

    private void removeTypeGroup(final int mPosition) {
        if (mDbHelper == null) mDbHelper = new DatabaseHelper(mContext);
        mDbHelper.delWhitelistGroup(mList.get(mPosition).getGroupId());
        removeListItem(mPosition);
    }

    class EmptyViewHolder extends RecyclerView.ViewHolder {

        EmptyViewHolder(View mView) {
            super(mView);
        }
    }

    class ContactViewHolder extends RecyclerView.ViewHolder {

        CircularImageView mContactImage;
        ImageView mActionOptions, mActionSchedule;
        TextView mContactLetter, mContactName, mPhoneNumber;

        ContactViewHolder(View mView) {
            super(mView);
            mContactImage = mView.findViewById(R.id.ivContactImage);
            mContactLetter = mView.findViewById(R.id.tvContactLetter);
            mContactName = mView.findViewById(R.id.tvContactName);
            mPhoneNumber = mView.findViewById(R.id.tvPhoneNumber);
            mActionOptions = mView.findViewById(R.id.ivOptions);
            mActionSchedule = mView.findViewById(R.id.ivSchedule);
            mActionOptions.setOnClickListener(mItemView -> showOptionsDialog(getAdapterPosition(), DatabaseHelper.BW_ENTRY_TYPE_CONTACT, mList.get(getAdapterPosition()).getDisplayName(), mList.get(getAdapterPosition()).getMatchData()));
            mActionSchedule.setOnClickListener(mItemView -> setAllowSchedule(getAdapterPosition()));
        }
    }

    class NumberViewHolder extends RecyclerView.ViewHolder {

        CircularImageView mContactImage;
        ImageView mActionOptions, mActionSchedule;
        TextView mContactLetter, mContactName, mPhoneNumber;

        NumberViewHolder(View mView) {
            super(mView);
            mContactImage = mView.findViewById(R.id.ivContactImage);
            mContactLetter = mView.findViewById(R.id.tvContactLetter);
            mContactName = mView.findViewById(R.id.tvContactName);
            mPhoneNumber = mView.findViewById(R.id.tvPhoneNumber);
            mActionOptions = mView.findViewById(R.id.ivOptions);
            mActionSchedule = mView.findViewById(R.id.ivSchedule);
            mActionOptions.setOnClickListener(mItemView -> showOptionsDialog(getAdapterPosition(), DatabaseHelper.BW_ENTRY_TYPE_NUMBER, mContext.getString(R.string.gr_title_number), mList.get(getAdapterPosition()).getMatchData()));
            mActionSchedule.setOnClickListener(mItemView -> setAllowSchedule(getAdapterPosition()));
        }
    }

    class StartsViewHolder extends RecyclerView.ViewHolder {

        CircularImageView mContactImage;
        ImageView mActionOptions, mActionSchedule;
        TextView mContactLetter, mContactName, mPhoneNumber;

        StartsViewHolder(View mView) {
            super(mView);
            mContactImage = mView.findViewById(R.id.ivContactImage);
            mContactLetter = mView.findViewById(R.id.tvContactLetter);
            mContactName = mView.findViewById(R.id.tvContactName);
            mPhoneNumber = mView.findViewById(R.id.tvPhoneNumber);
            mActionOptions = mView.findViewById(R.id.ivOptions);
            mActionSchedule = mView.findViewById(R.id.ivSchedule);
            mActionOptions.setOnClickListener(mItemView -> showOptionsDialog(getAdapterPosition(), DatabaseHelper.BW_ENTRY_TYPE_STARTS, mContext.getString(R.string.gr_title_starts), mList.get(getAdapterPosition()).getMatchData()));
            mActionSchedule.setOnClickListener(mItemView -> setAllowSchedule(getAdapterPosition()));
        }
    }

    class EndsViewHolder extends RecyclerView.ViewHolder {

        CircularImageView mContactImage;
        ImageView mActionOptions, mActionSchedule;
        TextView mContactLetter, mContactName, mPhoneNumber;

        EndsViewHolder(View mView) {
            super(mView);
            mContactImage = mView.findViewById(R.id.ivContactImage);
            mContactLetter = mView.findViewById(R.id.tvContactLetter);
            mContactName = mView.findViewById(R.id.tvContactName);
            mPhoneNumber = mView.findViewById(R.id.tvPhoneNumber);
            mActionOptions = mView.findViewById(R.id.ivOptions);
            mActionSchedule = mView.findViewById(R.id.ivSchedule);
            mActionOptions.setOnClickListener(mItemView -> showOptionsDialog(getAdapterPosition(), DatabaseHelper.BW_ENTRY_TYPE_ENDS, mContext.getString(R.string.gr_title_ends), mList.get(getAdapterPosition()).getMatchData()));
            mActionSchedule.setOnClickListener(mItemView -> setAllowSchedule(getAdapterPosition()));
        }
    }

    class ContainsViewHolder extends RecyclerView.ViewHolder {

        CircularImageView mContactImage;
        ImageView mActionOptions, mActionSchedule;
        TextView mContactLetter, mContactName, mPhoneNumber;

        ContainsViewHolder(View mView) {
            super(mView);
            mContactImage = mView.findViewById(R.id.ivContactImage);
            mContactLetter = mView.findViewById(R.id.tvContactLetter);
            mContactName = mView.findViewById(R.id.tvContactName);
            mPhoneNumber = mView.findViewById(R.id.tvPhoneNumber);
            mActionOptions = mView.findViewById(R.id.ivOptions);
            mActionSchedule = mView.findViewById(R.id.ivSchedule);
            mActionOptions.setOnClickListener(mItemView -> showOptionsDialog(getAdapterPosition(), DatabaseHelper.BW_ENTRY_TYPE_CONTAINS, mContext.getString(R.string.gr_title_contains), mList.get(getAdapterPosition()).getMatchData()));
            mActionSchedule.setOnClickListener(mItemView -> setAllowSchedule(getAdapterPosition()));
        }
    }

    class RangeViewHolder extends RecyclerView.ViewHolder {

        CircularImageView mContactImage;
        ImageView mActionOptions, mActionSchedule;
        TextView mContactLetter, mContactName, mPhoneNumber;

        RangeViewHolder(View mView) {
            super(mView);
            mContactImage = mView.findViewById(R.id.ivContactImage);
            mContactLetter = mView.findViewById(R.id.tvContactLetter);
            mContactName = mView.findViewById(R.id.tvContactName);
            mPhoneNumber = mView.findViewById(R.id.tvPhoneNumber);
            mActionOptions = mView.findViewById(R.id.ivOptions);
            mActionSchedule = mView.findViewById(R.id.ivSchedule);
            mActionOptions.setOnClickListener(mItemView -> showOptionsDialog(getAdapterPosition(), DatabaseHelper.BW_ENTRY_TYPE_RANGE, mContext.getString(R.string.gr_title_range), mList.get(getAdapterPosition()).getMatchData() + " to " + mList.get(getAdapterPosition()).getRangeData()));
            mActionSchedule.setOnClickListener(mItemView -> setAllowSchedule(getAdapterPosition()));
        }
    }

    class GroupViewHolder extends RecyclerView.ViewHolder {

        CircularImageView mContactImage;
        ImageView mActionOptions, mActionSchedule;
        TextView mContactLetter, mContactName, mPhoneNumber;

        GroupViewHolder(View mView) {
            super(mView);
            mContactImage = mView.findViewById(R.id.ivContactImage);
            mContactLetter = mView.findViewById(R.id.tvContactLetter);
            mContactName = mView.findViewById(R.id.tvContactName);
            mPhoneNumber = mView.findViewById(R.id.tvPhoneNumber);
            mActionOptions = mView.findViewById(R.id.ivOptions);
            mActionSchedule = mView.findViewById(R.id.ivSchedule);
            mActionOptions.setOnClickListener(mItemView -> showOptionsDialog(getAdapterPosition(), DatabaseHelper.BW_ENTRY_TYPE_GROUP, mContext.getString(R.string.gr_title_group), mList.get(getAdapterPosition()).getGroupName()));
            mActionSchedule.setOnClickListener(mItemView -> setAllowSchedule(getAdapterPosition()));
        }
    }
}