package com.callfence.android.utilities.picker.group;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.callfence.android.R;
import com.callfence.android.groups.GroupDataPair;

import java.util.ArrayList;

class GroupPickerAdapter extends RecyclerView.Adapter {

    private ArrayList<GroupDataPair> mGroupList;
    private GroupSelectListener mListener;

    GroupPickerAdapter(ArrayList<GroupDataPair> mGroupList, GroupSelectListener mListener) {
        this.mGroupList = mGroupList;
        this.mListener = mListener;
    }

    @Override
    public int getItemViewType(int mPosition) {
        if (mGroupList.isEmpty()) {
            return 0;
        } else {
            return 1;
        }
    }

    @SuppressWarnings("NullableProblems")
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup mParent, int mViewType) {
        if (mViewType == 0) {
            View mView = LayoutInflater.from(mParent.getContext()).inflate(R.layout.ac_group_picker_empty, mParent, false);
            return new EmptyViewHolder(mView);
        } else {
            View mView = LayoutInflater.from(mParent.getContext()).inflate(R.layout.ac_group_picker_row, mParent, false);
            return new GroupViewHolder(mView);
        }
    }

    @SuppressWarnings("NullableProblems")
    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder mHolder, int mPosition) {
        if (mHolder instanceof GroupViewHolder) {
            GroupViewHolder mGroupHolder = ((GroupViewHolder) mHolder);
            GroupDataPair mDataPair = mGroupList.get(mPosition);
            mGroupHolder.mGroupImage.setImageResource(mDataPair.isSelected() ? R.drawable.ic_action_check : R.drawable.ic_action_group);
            mGroupHolder.mGroupName.setText(mDataPair.getGroupName());
            mGroupHolder.mView.setOnClickListener(mView -> {
                setItemSelected(mDataPair.getGroupId());
                if (mListener != null)
                    mListener.onGroupSelected(mDataPair, getSelectedGroupsCount());
                notifyDataSetChanged();
            });
        }
    }

    @Override
    public int getItemCount() {
        if (mGroupList.size() == 0) {
            return 1;
        } else {
            return mGroupList.size();
        }
    }

    private int getItemPosition(String mGroupId) {
        int mPosition = 0;
        for (GroupDataPair mDataPair : mGroupList) {
            if (mDataPair.getGroupId().equals(mGroupId)) return mPosition;
            mPosition++;
        }
        return -1;
    }

    private void setItemSelected(String mGroupId) {
        int mPosition = getItemPosition(mGroupId);
        mGroupList.get(mPosition).setSelected(!mGroupList.get(mPosition).isSelected());
    }

    void setGroupPreSelected(String mGroupId) {
        int mPosition = getItemPosition(mGroupId);
        if (mPosition < 0 || !mGroupList.get(mPosition).getGroupId().equals(mGroupId))
            return;
        mGroupList.get(mPosition).setSelected(!mGroupList.get(mPosition).isSelected());
    }

    @SuppressWarnings("unused")
    void setGroupAllSelected(boolean isAll) {
        for (GroupDataPair mDataPair : mGroupList) {
            if (mDataPair.getGroupId() != null) mDataPair.setSelected(isAll);
            if (mListener != null) {
                mListener.onGroupSelected(mDataPair, getSelectedGroupsCount());
            }
        }
        notifyDataSetChanged();
    }

    int getSelectedGroupsCount() {
        return ((getSelectedGroups() != null) ? getSelectedGroups().size() : 0);
    }

    ArrayList<GroupDataPair> getSelectedGroups() {
        ArrayList<GroupDataPair> mSelectedGroups = new ArrayList<>();
        for (GroupDataPair mGroup : mGroupList) {
            if (mGroup.isSelected()) {
                mSelectedGroups.add(mGroup);
            }
        }
        return mSelectedGroups;
    }

    interface GroupSelectListener {

        void onGroupSelected(GroupDataPair mGroup, int mTotalSelectedGroups);
    }

    class EmptyViewHolder extends RecyclerView.ViewHolder {

        EmptyViewHolder(View mView) {
            super(mView);
        }
    }

    class GroupViewHolder extends RecyclerView.ViewHolder {

        View mView;
        ImageView mGroupImage;
        TextView mGroupName;

        GroupViewHolder(View mView) {
            super(mView);
            this.mView = mView;
            mGroupImage = mView.findViewById(R.id.ivGroupImage);
            mGroupName = mView.findViewById(R.id.tvGroupName);
        }
    }
}