package com.callfence.android.modules.whitelist;

public class WhitelistDataPair {

    private int mId, mType;
    private String mGroupId, mGroupName, mContactId, mMatchData, mRangeData, mStartTime, mEndTime;
    private String mDisplayName, mPhotoUri;

    public WhitelistDataPair(int mId, int mType, String mGroupId, String mGroupName, String mContactId, String mMatchData, String mRangeData, String mStartTime, String mEndTime) {
        this.mId = mId;
        this.mType = mType;
        this.mGroupId = mGroupId;
        this.mGroupName = mGroupName;
        this.mContactId = mContactId;
        this.mMatchData = mMatchData;
        this.mRangeData = mRangeData;
        this.mStartTime = mStartTime;
        this.mEndTime = mEndTime;
    }

    public int getId() {
        return mId;
    }

    int getType() {
        return mType;
    }

    public String getGroupId() {
        return mGroupId;
    }

    public String getGroupName() {
        return mGroupName;
    }

    public String getContactId() {
        return mContactId;
    }

    String getMatchData() {
        return mMatchData;
    }

    String getRangeData() {
        return mRangeData;
    }

    String getStartTime() {
        return mStartTime;
    }

    void setStartTime(String mStartTime) {
        this.mStartTime = mStartTime;
    }

    @SuppressWarnings("unused")
    public String getEndTime() {
        return mEndTime;
    }

    void setEndTime(String mEndTime) {
        this.mEndTime = mEndTime;
    }

    public String getDisplayName() {
        return mDisplayName;
    }

    void setDisplayName(String mDisplayName) {
        this.mDisplayName = mDisplayName;
    }

    public String getPhotoUri() {
        return mPhotoUri;
    }

    void setPhotoUri(String mPhotoUri) {
        this.mPhotoUri = mPhotoUri;
    }
}
