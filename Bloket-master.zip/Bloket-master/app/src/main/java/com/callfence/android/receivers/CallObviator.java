package com.callfence.android.receivers;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.ContactsContract;
import android.telecom.Call;
import android.telecom.CallScreeningService;
import android.telephony.SmsManager;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;

import com.callfence.android.R;
import com.callfence.android.homescreen.HomeScreenActivity;
import com.callfence.android.utilities.helpers.database.DatabaseHelper;
import com.callfence.android.utilities.helpers.observers.CallLogObserver;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class CallObviator extends CallScreeningService {

    private DatabaseHelper mDbHelper;
    private FirebaseAnalytics mFirebaseAnalytics;
    private SharedPreferences mPreferences;
    private int mId;

    @Override
    public void onScreenCall(@NonNull Call.Details mCallDetails) {

        try {
            Uri mPhoneUri = mCallDetails.getHandle();
            Context mContext = getBaseContext();
            if (mPreferences == null)
                mPreferences = PreferenceManager.getDefaultSharedPreferences(mContext);
            CallResponse.Builder mResponse = new CallResponse.Builder();
            if (mPhoneUri == null || !mPreferences.getBoolean("BL_PF_BLOCK_CL_ENABLED", false)) {
                respondToCall(mCallDetails, mResponse.build());
                return;
            }

            Calendar mCalendar = Calendar.getInstance();
            Date mDate = mCalendar.getTime();
            String mDayOfWeek = new SimpleDateFormat("EE", Locale.ENGLISH).format(mDate.getTime());
            DateFormat mFormat = new SimpleDateFormat("hh:mm a", Locale.getDefault());
            if (!mPreferences.getBoolean("BL_PF_BLOCK_" + mDayOfWeek.toUpperCase(), true) || !inBlockTime(
                    mPreferences.getString("BL_PF_BLOCK_START_TIME_DIS", "12:00 AM"),
                    mPreferences.getString("BL_PF_BLOCK_END_TIME_DIS", "11:59 PM"),
                    mFormat.format(mCalendar.getTime()))) {
                respondToCall(mCallDetails, mResponse.build());
                return;
            }

            String mPhoneNumber = URLDecoder.decode(mPhoneUri.toString(), StandardCharsets.UTF_8.name()).substring(4);
            if (!isBlocked(getBaseContext(), mPhoneNumber)) {
                respondToCall(mCallDetails, mResponse.build());
                return;
            }

            mResponse.setDisallowCall(true);
            mResponse.setSkipCallLog(true);
            mResponse.setSkipNotification(true);
            mResponse.setRejectCall(true);
            respondToCall(mCallDetails, mResponse.build());

            // If user has allowed to log calls, put in blocklogs
            mDbHelper.putBlockLogs(DatabaseHelper.BL_ENTRY_TYPE_CALL, mPhoneNumber, "");

            // Update call log
            CallLogObserver.putCallLogVersion(mPreferences, "BL_CL_OB_TIMESTAMP");

            // Show block notification
            if (mPreferences.getBoolean("BL_PF_NOTIFICATIONS", true))
                showBlockNotification(getContactName(getBaseContext(), mPhoneNumber));

            // Log firebase event
            logFirebaseEvent();

            // Send user defined message, if available
            if (mDbHelper == null) mDbHelper = new DatabaseHelper(mContext);
            sendUserMessage(mPhoneNumber, mDbHelper.getBlacklistMessage(mId));
        } catch (Exception mException) {
            Log.d("BLOKET_LOGS", "CallObviator: Error :: " + mException.getMessage());
        }
    }

    private boolean inBlockTime(String mStrTime, String mEndTime, String mCurTime) {
        try {
            DateFormat mFormat = new SimpleDateFormat("hh:mm a", Locale.getDefault());
            Date mStrDate = mFormat.parse(mStrTime);
            Calendar mStrCal = Calendar.getInstance();
            mStrCal.setTime(mStrDate);

            Date mEndDate = mFormat.parse(mEndTime);
            Calendar mEndCal = Calendar.getInstance();
            mEndCal.setTime(mEndDate);

            Date mCurDate = mFormat.parse(mCurTime);
            Calendar mCurCal = Calendar.getInstance();
            mCurCal.setTime(mCurDate);

            if (mCurDate.compareTo(mEndDate) < 0) {
                mCurCal.add(Calendar.DATE, 1);
                mCurDate = mCurCal.getTime();
            }

            if (mStrDate.compareTo(mEndDate) < 0) {
                mStrCal.add(Calendar.DATE, 1);
                mStrDate = mStrCal.getTime();
            }

            if (mCurDate.before(mStrDate)) {
                return false;
            } else {
                if (mCurDate.after(mEndDate)) {
                    mEndCal.add(Calendar.DATE, 1);
                    mEndDate = mEndCal.getTime();
                }
                return mCurDate.before(mEndDate);
            }
        } catch (Exception mException) {
            Log.d("BLOKET_LOGS", "CallObviator: Error checking block time, " + mException);
        }
        return false;
    }

    private boolean isBlocked(Context mContext, String mPhoneNumber) {
        try {

            // Prepare searchable number
            String mSearchableNumber;
            PhoneNumberUtil mPhoneUtil = PhoneNumberUtil.getInstance();
            DecimalFormat mFormatter = new DecimalFormat("#,#");
            if (mPhoneNumber.startsWith("+")) {
                Phonenumber.PhoneNumber mNumber = mPhoneUtil.parse(mPhoneNumber, "");
                mSearchableNumber = mFormatter.format(mNumber.getNationalNumber());
                mPhoneNumber = String.valueOf(mNumber.getNationalNumber());
            } else {
                mSearchableNumber = mFormatter.format(Long.valueOf(mPhoneNumber));
            }
            mSearchableNumber = mSearchableNumber.replaceAll(",", "%");

            // Check if number is in whitelist
            boolean isWhitelisted = isWhitelisted(mContext, mPhoneNumber, mSearchableNumber);

            // Check user preferences
            if (mPreferences == null)
                mPreferences = PreferenceManager.getDefaultSharedPreferences(mContext);
            if (mPreferences.getBoolean("BL_PF_BLOCK_ALL", false) && !isWhitelisted)
                return true;

            if (mPreferences.getBoolean("BL_PF_BLOCK_CONTACTS", false) && !isWhitelisted && isSavedContact(mContext, mPhoneNumber))
                return true;

            if (mPreferences.getBoolean("BL_PF_BLOCK_UNKNOWN", false) && !isWhitelisted && !isSavedContact(mContext, mPhoneNumber))
                return true;

            if (mPreferences.getBoolean("BL_PF_BLOCK_PRIVATE", false) && !isWhitelisted && isPrivateNumber(mPhoneNumber))
                return true;

            return !isWhitelisted && isBlacklisted(mContext, mPhoneNumber, mSearchableNumber);

        } catch (Exception mException) {
            Log.d("BLOKET_LOGS", "CallInterceptor: Error while checking if number is blocked");
        }
        return false;
    }

    private boolean isBlacklisted(Context mContext, String mPhoneNumber, String mSearchableNumber) {
        if (mDbHelper == null) mDbHelper = new DatabaseHelper(mContext);
        mId = mDbHelper.chkBlacklistData(mPhoneNumber, mSearchableNumber);
        if (mId == -1) return false;
        return mDbHelper.chkBlacklistSchedule(mId);
    }

    private boolean isWhitelisted(Context mContext, String mPhoneNumber, String mSearchableNumber) {
        if (mDbHelper == null) mDbHelper = new DatabaseHelper(mContext);
        mId = mDbHelper.chkWhitelistData(mPhoneNumber, mSearchableNumber);
        if (mId == -1) return false;
        return mDbHelper.chkWhitelistSchedule(mId);
    }

    private boolean isSavedContact(Context mContext, String mPhoneNumber) {
        Uri mUri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(mPhoneNumber));
        try (Cursor mCursor = mContext.getContentResolver().query(mUri, new String[]{ContactsContract.PhoneLookup._ID, ContactsContract.PhoneLookup.NUMBER, ContactsContract.PhoneLookup.DISPLAY_NAME}, null, null, null)) {
            if (mCursor != null && mCursor.moveToFirst()) return true;
        }
        return false;
    }

    private boolean isPrivateNumber(String mPhoneNumber) {
        return Long.valueOf(mPhoneNumber) < 0;
    }

    private void showBlockNotification(String mPhoneNumber) {
        NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        String mChannelID = "Block Notifications";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel mNotificationChannel = new NotificationChannel(mChannelID, mChannelID, NotificationManager.IMPORTANCE_HIGH);
            mNotificationChannel.setDescription("Notifies you when an incoming call is blocked.");
            mNotificationChannel.enableLights(true);
            mNotificationChannel.setLightColor(Color.WHITE);
            mNotificationChannel.setVibrationPattern(new long[]{0, 1000, 500, 1000});
            mNotificationChannel.enableVibration(true);
            if (mNotificationManager != null) {
                mNotificationManager.createNotificationChannel(mNotificationChannel);
            } else return;
        }

        Intent mActionIntent = new Intent(getApplicationContext(), HomeScreenActivity.class);
        mActionIntent.putExtra("BL_OPEN_CALL_LOGS", true);
        NotificationCompat.Builder mNotification = new NotificationCompat.Builder(getApplicationContext(), mChannelID)
                .setStyle(new NotificationCompat.BigTextStyle().bigText("Blocked incoming call from " + mPhoneNumber + ". Tap to view details!"))
                .setContentTitle("Call Blocked")
                .setContentText("Blocked call from " + mPhoneNumber)
                .setContentIntent(PendingIntent.getActivity(getApplicationContext(), 0, mActionIntent, PendingIntent.FLAG_UPDATE_CURRENT))
                .setSmallIcon(R.drawable.ic_notification_block)
                .setColor(getColor(R.color.colorPrimary))
                .setLights(0xff00ffff, 1000, 5000)
                .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
                .setAutoCancel(true);
        if (mNotificationManager != null) mNotificationManager.notify(0, mNotification.build());
    }

    private String getContactName(Context mContext, String mPhoneNumber) {
        Uri mUri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(mPhoneNumber));
        try (Cursor mCursor = mContext.getContentResolver().query(mUri, new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME}, null, null, null)) {
            if (mCursor != null && mCursor.moveToFirst()) return mCursor.getString(0);
        }
        return mPhoneNumber;
    }

    private void sendUserMessage(String mPhoneNumber, String mReplyMessage) {
        if (mReplyMessage.length() < 1) return;
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(mPhoneNumber, null, mReplyMessage, null, null);
    }

    private void logFirebaseEvent() {
        Bundle mData = new Bundle();
        mData.putBoolean("call_blocked", true);
        if (mFirebaseAnalytics == null) mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        mFirebaseAnalytics.logEvent("total_calls_blocked", mData);
    }
}