package com.callfence.android.preferences;

import android.annotation.SuppressLint;
import android.app.TimePickerDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.MenuItem;
import android.view.View;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.callfence.android.R;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class BlockPreferences extends AppCompatActivity implements View.OnClickListener {

    private CheckBox mBlockAll, mBlockContacts, mBlockUnknown, mBlockPrivate, mBlockSun, mBlockMon, mBlockTue, mBlockWed, mBlockThu, mBlockFri, mBlockSat;
    private LinearLayout mStartLayout, mEndLayout;
    private SharedPreferences mPreferences;
    private Switch mEnableBlock, mEnableNotifications;
    private TextView mStartTime, mEndTime;

    @SuppressWarnings("ConstantConditions")
    @Override
    protected void onCreate(@Nullable Bundle mSavedInstanceState) {
        super.onCreate(mSavedInstanceState);
        setContentView(R.layout.ac_block_preferences);

        Toolbar mToolbar = findViewById(R.id.tbToolbar);
        if (mToolbar != null) {
            setSupportActionBar(mToolbar);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Block Preferences");
        }

        mPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        mEnableBlock = findViewById(R.id.swEnableBlock);
        mEnableBlock.setOnClickListener(this);
        mEnableBlock.setChecked(mPreferences.getBoolean("BL_PF_BLOCK_CL_ENABLED", false));

        mStartLayout = findViewById(R.id.llStartTime);
        mStartLayout.setOnClickListener(this);
        mStartTime = findViewById(R.id.tvStartTime);
        mStartTime.setText(mPreferences.getString("BL_PF_BLOCK_START_TIME_DIS", "12:00 AM"));

        mEndLayout = findViewById(R.id.llEndTime);
        mEndLayout.setOnClickListener(this);
        mEndTime = findViewById(R.id.tvEndTime);
        mEndTime.setText(mPreferences.getString("BL_PF_BLOCK_END_TIME_DIS", "11:59 PM"));

        mBlockSun = findViewById(R.id.cbBlockSun);
        mBlockSun.setOnClickListener(this);
        mBlockSun.setChecked(mPreferences.getBoolean("BL_PF_BLOCK_SUN", true));

        mBlockMon = findViewById(R.id.cbBlockMon);
        mBlockMon.setOnClickListener(this);
        mBlockMon.setChecked(mPreferences.getBoolean("BL_PF_BLOCK_MON", true));

        mBlockTue = findViewById(R.id.cbBlockTue);
        mBlockTue.setOnClickListener(this);
        mBlockTue.setChecked(mPreferences.getBoolean("BL_PF_BLOCK_TUE", true));

        mBlockWed = findViewById(R.id.cbBlockWed);
        mBlockWed.setOnClickListener(this);
        mBlockWed.setChecked(mPreferences.getBoolean("BL_PF_BLOCK_WED", true));

        mBlockThu = findViewById(R.id.cbBlockThu);
        mBlockThu.setOnClickListener(this);
        mBlockThu.setChecked(mPreferences.getBoolean("BL_PF_BLOCK_THU", true));

        mBlockFri = findViewById(R.id.cbBlockFri);
        mBlockFri.setOnClickListener(this);
        mBlockFri.setChecked(mPreferences.getBoolean("BL_PF_BLOCK_FRI", true));

        mBlockSat = findViewById(R.id.cbBlockSat);
        mBlockSat.setOnClickListener(this);
        mBlockSat.setChecked(mPreferences.getBoolean("BL_PF_BLOCK_SAT", true));

        enableWeekBoxes(mEnableBlock.isChecked());

        mBlockAll = findViewById(R.id.cbBlockAll);
        mBlockAll.setOnClickListener(this);
        mBlockAll.setChecked(mPreferences.getBoolean("BL_PF_BLOCK_ALL", false));

        mBlockContacts = findViewById(R.id.cbBlockContacts);
        mBlockContacts.setOnClickListener(this);
        mBlockContacts.setChecked(mPreferences.getBoolean("BL_PF_BLOCK_CONTACTS", false));

        mBlockUnknown = findViewById(R.id.cbBlockUnknown);
        mBlockUnknown.setOnClickListener(this);
        mBlockUnknown.setChecked(mPreferences.getBoolean("BL_PF_BLOCK_UNKNOWN", false));

        mBlockPrivate = findViewById(R.id.cbBlockPrivate);
        mBlockPrivate.setOnClickListener(this);
        mBlockPrivate.setChecked(mPreferences.getBoolean("BL_PF_BLOCK_PRIVATE", false));

        mEnableNotifications = findViewById(R.id.swEnableNotifications);
        mEnableNotifications.setOnClickListener(this);
        mEnableNotifications.setChecked(mPreferences.getBoolean("BL_PF_NOTIFICATIONS", true));

        if (mBlockAll.isChecked()) {
            mBlockContacts.setChecked(true);
            mBlockContacts.setEnabled(false);
            mBlockUnknown.setChecked(true);
            mBlockUnknown.setEnabled(false);
            mBlockPrivate.setChecked(true);
            mBlockPrivate.setEnabled(false);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem mItem) {
        finish();
        return super.onOptionsItemSelected(mItem);
    }

    @Override
    public void onClick(View mView) {
        if (mPreferences == null)
            mPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor mEditor = mPreferences.edit();

        switch (mView.getId()) {
            case R.id.swEnableBlock:
                mEditor.putBoolean("BL_PF_BLOCK_CL_ENABLED", mEnableBlock.isChecked());
                mEditor.apply();

                enableWeekBoxes(mEnableBlock.isChecked());
                break;

            case R.id.llStartTime:
                Calendar mStartCal = Calendar.getInstance();
                @SuppressLint("SetTextI18n") TimePickerDialog mStartPicker = new TimePickerDialog(this, (mPicker, mSelectedHour, mSelectedMin) -> {
                    mStartCal.set(Calendar.HOUR_OF_DAY, mSelectedHour);
                    mStartCal.set(Calendar.MINUTE, mSelectedMin);
                    DateFormat mFormat = new SimpleDateFormat("hh:mm a", Locale.getDefault());
                    mStartTime.setText(mFormat.format(mStartCal.getTime()));

                    // Write to shared preferences
                    mEditor.putString("BL_PF_BLOCK_START_TIME_DIS", mFormat.format(mStartCal.getTime()));
                    mEditor.putInt("BL_PF_BLOCK_START_TIME", Integer.valueOf(mSelectedHour + "" + String.format(Locale.getDefault(), "%02d", mSelectedMin)));
                    mEditor.apply();
                }, mStartCal.get(Calendar.HOUR_OF_DAY), mStartCal.get(Calendar.MINUTE), false);
                mStartPicker.show();
                break;

            case R.id.llEndTime:
                Calendar mEndCal = Calendar.getInstance();
                @SuppressLint("SetTextI18n") TimePickerDialog mEndPicker = new TimePickerDialog(this, (mPicker, mSelectedHour, mSelectedMin) -> {
                    mEndCal.set(Calendar.HOUR_OF_DAY, mSelectedHour);
                    mEndCal.set(Calendar.MINUTE, mSelectedMin);
                    DateFormat mFormat = new SimpleDateFormat("hh:mm a", Locale.getDefault());
                    mEndTime.setText(mFormat.format(mEndCal.getTime()));

                    // Write to shared preferences
                    mEditor.putString("BL_PF_BLOCK_END_TIME_DIS", mFormat.format(mEndCal.getTime()));
                    mEditor.putInt("BL_PF_BLOCK_END_TIME", Integer.valueOf(mSelectedHour + "" + String.format(Locale.getDefault(), "%02d", mSelectedMin)));
                    mEditor.apply();
                }, mEndCal.get(Calendar.HOUR_OF_DAY), mEndCal.get(Calendar.MINUTE), false);
                mEndPicker.show();
                break;

            case R.id.cbBlockSun:
                mEditor.putBoolean("BL_PF_BLOCK_SUN", mBlockSun.isChecked());
                mEditor.apply();
                break;

            case R.id.cbBlockMon:
                mEditor.putBoolean("BL_PF_BLOCK_MON", mBlockMon.isChecked());
                mEditor.apply();
                break;

            case R.id.cbBlockTue:
                mEditor.putBoolean("BL_PF_BLOCK_TUE", mBlockTue.isChecked());
                mEditor.apply();
                break;

            case R.id.cbBlockWed:
                mEditor.putBoolean("BL_PF_BLOCK_WED", mBlockWed.isChecked());
                mEditor.apply();
                break;

            case R.id.cbBlockThu:
                mEditor.putBoolean("BL_PF_BLOCK_THU", mBlockThu.isChecked());
                mEditor.apply();
                break;

            case R.id.cbBlockFri:
                mEditor.putBoolean("BL_PF_BLOCK_FRI", mBlockFri.isChecked());
                mEditor.apply();
                break;

            case R.id.cbBlockSat:
                mEditor.putBoolean("BL_PF_BLOCK_SAT", mBlockSat.isChecked());
                mEditor.apply();
                break;

            case R.id.cbBlockAll:
                onAllChecked(mPreferences, mEditor);
                mEditor.apply();
                break;

            case R.id.cbBlockContacts:
                mEditor.putBoolean("BL_PF_BLOCK_CONTACTS", mBlockContacts.isChecked());
                if (mBlockUnknown.isChecked()) {
                    mBlockAll.setChecked(true);
                    onAllChecked(mPreferences, mEditor);
                }
                mEditor.apply();
                break;

            case R.id.cbBlockUnknown:
                mEditor.putBoolean("BL_PF_BLOCK_UNKNOWN", mBlockUnknown.isChecked());
                if (mBlockContacts.isChecked()) {
                    mBlockAll.setChecked(true);
                    onAllChecked(mPreferences, mEditor);
                }
                mEditor.apply();
                break;

            case R.id.cbBlockPrivate:
                mEditor.putBoolean("BL_PF_BLOCK_PRIVATE", mBlockPrivate.isChecked());
                mEditor.apply();
                break;

            case R.id.swEnableNotifications:
                mEditor.putBoolean("BL_PF_NOTIFICATIONS", mEnableNotifications.isChecked());
                mEditor.apply();
                break;
        }
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    private void enableWeekBoxes(boolean mValue) {
        mStartLayout.setEnabled(mValue);
        mEndLayout.setEnabled(mValue);
        mBlockSun.setEnabled(mValue);
        mBlockMon.setEnabled(mValue);
        mBlockTue.setEnabled(mValue);
        mBlockWed.setEnabled(mValue);
        mBlockThu.setEnabled(mValue);
        mBlockFri.setEnabled(mValue);
        mBlockSat.setEnabled(mValue);
    }

    private void onAllChecked(SharedPreferences mPreferences, SharedPreferences.Editor mEditor) {
        if (mBlockAll.isChecked()) {
            mBlockContacts.setChecked(true);
            mBlockContacts.setEnabled(false);
            mBlockUnknown.setChecked(true);
            mBlockUnknown.setEnabled(false);
            mBlockPrivate.setChecked(true);
            mBlockPrivate.setEnabled(false);
            mEditor.putBoolean("BL_PF_BLOCK_ALL", true);
        } else {
            mBlockContacts.setChecked(false);
            mBlockContacts.setEnabled(true);
            mBlockUnknown.setChecked(false);
            mBlockUnknown.setEnabled(true);
            mBlockPrivate.setChecked(mPreferences.getBoolean("BL_PF_BLOCK_PRIVATE", false));
            mBlockPrivate.setEnabled(true);
            mEditor.putBoolean("BL_PF_BLOCK_ALL", false);
            mEditor.putBoolean("BL_PF_BLOCK_CONTACTS", false);
            mEditor.putBoolean("BL_PF_BLOCK_UNKNOWN", false);
        }
    }
}
