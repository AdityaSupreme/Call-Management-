package com.callfence.android.utilities.dummy;

import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.callfence.android.R;

public class ComposerActivity extends AppCompatActivity {

    @SuppressWarnings("ConstantConditions")
    @Override
    protected void onCreate(@Nullable Bundle mSavedInstanceState) {
        super.onCreate(mSavedInstanceState);
        setContentView(R.layout.ac_composer_notification);

        // Set up toolbar
        Toolbar mToolbar = findViewById(R.id.tbToolbar);
        if (mToolbar != null) {
            setSupportActionBar(mToolbar);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Message");
        }
    }

    @SuppressWarnings("NullableProblems")
    @Override
    public boolean onOptionsItemSelected(MenuItem mItem) {
        finish();
        return super.onOptionsItemSelected(mItem);
    }

    @Override
    public void onBackPressed() {
        finish();
    }
}