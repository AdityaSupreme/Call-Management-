package com.callfence.android.groups;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.callfence.android.utilities.helpers.database.DatabaseHelper;

import java.util.ArrayList;

class GroupListTask extends AsyncTask<Void, Void, Void> {

    private ArrayList<GroupDataPair> mGroupList;
    @SuppressLint("StaticFieldLeak")
    private Context mContext;
    private GroupTaskResponse mResponse;

    GroupListTask(Context mContext, GroupTaskResponse mResponse) {
        this.mContext = mContext;
        this.mResponse = mResponse;
    }

    @Override
    protected Void doInBackground(Void... mVoid) {
        try {

            // Set existing group list to null
            mGroupList = new ArrayList<>();

            // Fetch group list
            DatabaseHelper mDbHelper = new DatabaseHelper(mContext);
            mGroupList = mDbHelper.getGroupList();
        } catch (Exception mException) {
            Log.d("BLOKET_LOGS", "GroupListTask: Error fetching group list, Details: " + mException.toString());
        }
        return null;
    }

    @Override
    protected void onPostExecute(Void mVoid) {
        mResponse.onTaskCompletion(mGroupList);
    }

    public interface GroupTaskResponse {

        void onTaskCompletion(ArrayList<GroupDataPair> mGroupList);

    }
}