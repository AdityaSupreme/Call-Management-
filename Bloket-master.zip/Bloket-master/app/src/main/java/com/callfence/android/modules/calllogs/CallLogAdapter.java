package com.callfence.android.modules.calllogs;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.callfence.android.R;
import com.callfence.android.modules.calllogs.calldetails.CallDetailsActivity;
import com.callfence.android.modules.calllogs.calldetails.CallDetailsTask;
import com.callfence.android.utilities.events.RefreshBlacklistEvent;
import com.callfence.android.utilities.events.RefreshWhitelistEvent;
import com.callfence.android.utilities.helpers.database.DatabaseHelper;
import com.callfence.android.utilities.helpers.telephone.TelephoneHelper;
import com.mikhaellopez.circularimageview.CircularImageView;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

class CallLogAdapter extends RecyclerView.Adapter {

    private ArrayList<CallLogDataPair> mCallList;
    private ContentResolver mContentResolver;
    private Context mContext;
    private Map<Integer, Integer> mCallTypeIcons = new HashMap<Integer, Integer>() {{
        put(CallLog.Calls.INCOMING_TYPE, R.drawable.ic_call_incoming);
        put(CallLog.Calls.OUTGOING_TYPE, R.drawable.ic_call_outgoing);
        put(CallLog.Calls.MISSED_TYPE, R.drawable.ic_call_missed);
        put(CallLog.Calls.REJECTED_TYPE, R.drawable.ic_call_rejected);
        put(CallLog.Calls.BLOCKED_TYPE, R.drawable.ic_call_blocked);
    }};

    CallLogAdapter(Context mContext, ArrayList<CallLogDataPair> mCallList) {
        this.mContext = mContext;
        this.mCallList = mCallList;
        this.mContentResolver = mContext.getContentResolver();
    }

    @Override
    public int getItemViewType(int mPosition) {
        return mCallList.isEmpty() ? 0 : 1;
    }

    @SuppressWarnings("NullableProblems")
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup mParent, int mViewType) {
        if (mViewType == 0) {
            View mView = LayoutInflater.from(mParent.getContext()).inflate(R.layout.fm_calllogs_list_empty, mParent, false);
            return new EmptyViewHolder(mView);
        } else {
            View mView = LayoutInflater.from(mParent.getContext()).inflate(R.layout.fm_calllogs_list_row, mParent, false);
            return new CallLogsViewHolder(mView);
        }
    }

    @SuppressWarnings({"NullableProblems"})
    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder mHolder, int mPosition) {
        if (mHolder instanceof CallLogsViewHolder) {
            CallLogsViewHolder mDataHolder = ((CallLogsViewHolder) mHolder);
            CallLogDataPair mDataPair = mCallList.get(mPosition);

            if (mDataPair.getDisplayName() == null || mDataPair.getPhotoUri() == null) {
                String[] mDetails = getNameAndImage(mDataPair.getPhoneNumber());
                mDataPair.setDisplayName(mDetails[0].equals("") ? mDataPair.getPhoneNumber() : mDetails[0]);
                mDataPair.setPhotoUri(mDetails[1]);
            }

            mDataHolder.mContactName.setText(mDataPair.getDisplayName());
            mDataHolder.mContactName.setCompoundDrawablesWithIntrinsicBounds(mCallTypeIcons.getOrDefault(mDataPair.getCallType(), R.drawable.ic_call_missed), 0, 0, 0);
            mDataHolder.mCallDetails.setText(mDataPair.getCallDate());
            mDataHolder.mCallCount.setText(String.valueOf(mDataPair.getCallCount()));
            if (mDataPair.getPhotoUri() == null || mDataPair.getPhotoUri().equals("")) {
                mDataHolder.mContactImage.setImageResource(R.drawable.ic_action_person);
            } else {
                mDataHolder.mContactImage.setImageURI(Uri.parse(mDataPair.getPhotoUri()));
            }
        }
    }

    @Override
    public int getItemCount() {
        if (mCallList.size() == 0) {
            return 1;
        } else {
            return mCallList.size();
        }
    }

    private void removeListItem(int mPosition) {
        mCallList.remove(mPosition);
        notifyDataSetChanged();
    }

    private String[] getNameAndImage(String mPhoneNumber) {
        String mContactName = "", mContactImage = "";
        if (mPhoneNumber == null || mPhoneNumber.equals(""))
            return new String[]{mContactName, mContactImage};

        final Cursor mCursor = mContentResolver.query(
                Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(mPhoneNumber)),
                new String[]{ContactsContract.Contacts.DISPLAY_NAME, ContactsContract.Contacts.PHOTO_URI},
                null, null, null);
        if (mCursor != null && mCursor.moveToFirst()) {
            mContactName = mCursor.getString(0);
            mContactImage = mCursor.getString(1);
        }
        if (mCursor != null) mCursor.close();
        return new String[]{mContactName, mContactImage};
    }

    private void placeVoiceCall(String mPhoneNumber) {
        if (mContext.checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED)
            return;

        TelephoneHelper.placeCall(mContext, mPhoneNumber);
    }

    class CallLogsViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        CircularImageView mContactImage;
        RelativeLayout mCallLogContainer;
        TextView mContactName, mCallDetails, mCallCount;
        ImageView mCallNumber;

        CallLogsViewHolder(View mView) {
            super(mView);
            mContactImage = mView.findViewById(R.id.ivContactImage);
            mContactName = mView.findViewById(R.id.tvContactName);
            mCallDetails = mView.findViewById(R.id.tvCallDetails);
            mCallCount = mView.findViewById(R.id.tvCallCount);
            mCallNumber = mView.findViewById(R.id.ivCallNumber);
            mCallLogContainer = mView.findViewById(R.id.rlCallLogContainer);

            // Set click listeners
            mCallNumber.setOnClickListener(this);
            mCallLogContainer.setOnClickListener(this);
        }


        @Override
        public void onClick(View mView) {
            if (mView.getId() == R.id.ivCallNumber) {
                placeVoiceCall(mCallList.get(getAdapterPosition()).getPhoneNumber());
            } else {
                showOptionsDialog(getAdapterPosition());
            }
        }

        private void showOptionsDialog(final int mPosition) {
            @SuppressLint("InflateParams") View mContentView = LayoutInflater.from(mContext).inflate(R.layout.fm_callogs_option, null);
            final Dialog mDialog = new Dialog(mContext);
            mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            mDialog.setContentView(mContentView);

            CallLogDataPair mDataPair = mCallList.get(mPosition);
            TextView mDisplayName = mDialog.findViewById(R.id.tvDisplayName);
            mDisplayName.setText(mDataPair.getDisplayName());

            TextView mViewDetails = mContentView.findViewById(R.id.tvViewDetails);
            mViewDetails.setOnClickListener(mView -> {
                Intent mIntent = new Intent(mContext, CallDetailsActivity.class);
                mIntent.putExtra("CALL_LOG_TYPE", mDataPair.getCallType());
                mIntent.putExtra("PHONE_NUMBER", mDataPair.getPhoneNumber());
                mIntent.putExtra("RAW_DATE", mDataPair.getRawDate().getTime());
                mIntent.putExtra("CALL_COUNT", mDataPair.getCallCount());
                mContext.startActivity(mIntent);
                mDialog.dismiss();
            });

            TextView mAddBlacklist = mContentView.findViewById(R.id.tvAddBlacklist);
            mAddBlacklist.setOnClickListener(mView -> {
                DatabaseHelper mDbHelper = new DatabaseHelper(mContext);
                String mPhoneNumber = mDataPair.getPhoneNumber();
                String mContactId = getContactId(mPhoneNumber);
                if (mContactId == null) {
                    // Add as number
                    if (!mDbHelper.chkBlacklistNumber(mPhoneNumber)) {
                        mDbHelper.putBlacklistData(DatabaseHelper.BW_ENTRY_TYPE_NUMBER, DatabaseHelper.DEFAULT_GROUP_ID, "", "", mPhoneNumber, "", "", "", "");
                        EventBus.getDefault().post(new RefreshBlacklistEvent(true));
                    }
                } else {
                    // Add as a contact
                    if (!mDbHelper.chkBlacklistContact(mContactId, mPhoneNumber)) {
                        mDbHelper.putBlacklistData(DatabaseHelper.BW_ENTRY_TYPE_CONTACT, DatabaseHelper.DEFAULT_GROUP_ID, "", mContactId, mPhoneNumber, "", "", "", "");
                        EventBus.getDefault().post(new RefreshBlacklistEvent(true));
                    }
                }
                Toast.makeText(mContext, "Success", Toast.LENGTH_SHORT).show();
                mDialog.dismiss();
            });

            TextView mAddWhitelist = mContentView.findViewById(R.id.tvAddWhitelist);
            mAddWhitelist.setOnClickListener(mView -> {
                DatabaseHelper mDbHelper = new DatabaseHelper(mContext);
                String mPhoneNumber = mDataPair.getPhoneNumber();
                String mContactId = getContactId(mPhoneNumber);
                if (mContactId == null) {
                    // Add as number
                    if (!mDbHelper.chkWhitelistNumber(mPhoneNumber)) {
                        mDbHelper.putWhitelistData(DatabaseHelper.BW_ENTRY_TYPE_NUMBER, DatabaseHelper.DEFAULT_GROUP_ID, "", "", mPhoneNumber, "", "", "");
                        EventBus.getDefault().post(new RefreshWhitelistEvent(true));
                    }
                } else {
                    // Add as a contact
                    if (!mDbHelper.chkWhitelistContact(mContactId, mPhoneNumber)) {
                        mDbHelper.putWhitelistData(DatabaseHelper.BW_ENTRY_TYPE_CONTACT, DatabaseHelper.DEFAULT_GROUP_ID, "", mContactId, mPhoneNumber, "", "", "");
                        EventBus.getDefault().post(new RefreshWhitelistEvent(true));
                    }
                }
                Toast.makeText(mContext, "Success", Toast.LENGTH_SHORT).show();
                mDialog.dismiss();
            });

            TextView mDeleteItem = mContentView.findViewById(R.id.tvDeleteItem);
            mDeleteItem.setOnClickListener(mView -> {
                // Delete from block logs
                if (mDataPair.getCallType() == CallLog.Calls.BLOCKED_TYPE) {
                    DatabaseHelper mDbHelper = new DatabaseHelper(mContext);
                    for (CallLogDataPair mPair : mDbHelper.getBlockLogsSlab(mDataPair.getPhoneNumber(), mDataPair.getRawDate().getTime(), mDataPair.getCallCount()))
                        mDbHelper.delBlockLogs(mPair.getCallLogId());
                    removeListItem(mPosition);
                    mDialog.dismiss();
                    return;
                }

                // Delete from call logs
                CallDetailsTask mAsyncTask = new CallDetailsTask(mContext, mDataPair.getCallType(), mDataPair.getPhoneNumber(), mDataPair.getRawDate().getTime(), mDataPair.getCallCount(), mCallList -> {
                    if (mContext.checkSelfPermission(Manifest.permission.WRITE_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
                        mDialog.dismiss();
                        return;
                    }
                    for (CallLogDataPair mPair : mCallList)
                        mContext.getContentResolver().delete(CallLog.Calls.CONTENT_URI, CallLog.Calls._ID + " = " + mPair.getCallLogId(), null);
                    removeListItem(mPosition);
                    Toast.makeText(mContext, "Deleted", Toast.LENGTH_SHORT).show();
                    mDialog.dismiss();
                });
                mAsyncTask.execute();
            });
            mDialog.show();
        }

        private String getContactId(String mPhoneNumber) {
            Uri mUri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(mPhoneNumber));
            try (Cursor mCursor = mContext.getContentResolver().query(
                    mUri,
                    new String[]{ContactsContract.PhoneLookup._ID},
                    null, null, null)) {
                if (mCursor != null && mCursor.moveToNext()) {
                    return mCursor.getString(0);
                } else return null;
            }
        }
    }

    class EmptyViewHolder extends RecyclerView.ViewHolder {

        EmptyViewHolder(View mView) {
            super(mView);
        }
    }
}