package com.callfence.android.modules.contacts;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.callfence.android.R;
import com.callfence.android.groups.GroupAddTask;
import com.callfence.android.utilities.helpers.database.DatabaseHelper;
import com.callfence.android.utilities.helpers.observers.ContactObserver;
import com.callfence.android.utilities.picker.contact.ContactPickerDataPair;
import com.callfence.android.utilities.picker.contact.ContactPickerIdNumber;
import com.callfence.android.utilities.picker.contact.ContactPickerResult;
import com.callfence.android.utilities.picker.group.GroupPickerActivity;
import com.callfence.android.utilities.picker.group.GroupPickerResult;
import com.l4digital.fastscroll.FastScrollRecyclerView;

import java.util.ArrayList;

import static android.app.Activity.RESULT_OK;

public class ContactsFragment extends Fragment {

    private ContactsAdapter mAdapter;
    private FastScrollRecyclerView mRecyclerView;
    private SearchView mSearchView;
    static String mAddContactId;
    private SharedPreferences mPreferences;

    public static ContactsFragment newInstance() {
        return new ContactsFragment();
    }

    @SuppressWarnings({"deprecation"})
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater mInflater, @Nullable ViewGroup mContainer, @Nullable Bundle mSavedInstance) {
        View mView = mInflater.inflate(R.layout.fm_contacts_layout, mContainer, false);
        mSearchView = mView.findViewById(R.id.cfSearchView);
        View mSearchBackground = mSearchView.findViewById(androidx.appcompat.R.id.search_plate);
        mSearchBackground.setBackgroundColor(getResources().getColor(R.color.colorTransparent));
        mSearchView.setQueryHint("Search contacts");
        mSearchView.setOnClickListener(mTempView -> mSearchView.setIconified(false));
        mSearchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String mSearchText) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String mSearchText) {
                if (mAdapter != null) mAdapter.getFilter().filter(mSearchText);
                return false;
            }
        });

        mRecyclerView = mView.findViewById(R.id.cfRecyclerView);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        return mView;
    }

    @SuppressWarnings("ConstantConditions")
    @Override
    public void onResume() {
        super.onResume();
        if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
            return;

        if (mPreferences == null)
            mPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        if (mAdapter == null || ContactObserver.isFtsChanged(getContext()))
            loadContactList();
    }

    @Override
    public void onActivityResult(int mRequestCode, int mResultCode, Intent mData) {
        super.onActivityResult(mRequestCode, mResultCode, mData);
        if (mRequestCode == GroupPickerActivity.PICKER_REQUEST_CODE) {
            if (mResultCode != RESULT_OK) return;
            if (mAddContactId == null) return;

            DatabaseHelper mDbHelper = new DatabaseHelper(getContext());
            ArrayList<GroupPickerResult> mSelectedGroup = new ArrayList<>(GroupPickerResult.obtainResult(mData));
            ArrayList<ContactPickerIdNumber> mGroupContacts = mDbHelper.getGroupListContact(mSelectedGroup.get(0).getGroupId());
            ArrayList<ContactPickerResult> mSelectedContacts = new ArrayList<>();
            for (String mNumber : getPhoneNumbers(mAddContactId))
                mSelectedContacts.add(new ContactPickerResult(new ContactPickerDataPair(mAddContactId, "", "", mNumber, "", 0)));
            for (ContactPickerIdNumber mContact : mGroupContacts)
                mSelectedContacts.add(new ContactPickerResult(new ContactPickerDataPair(mContact.getContactId(), "", "", mContact.getPhoneNumber(), "", 0)));

            GroupAddTask mAddTask = new GroupAddTask(getContext(), mSelectedGroup.get(0).getGroupId(), mSelectedGroup.get(0).getGroupName(), mSelectedContacts, mSuccess ->
                    Toast.makeText(getContext(), mSuccess ? "Success" : "Failed", Toast.LENGTH_SHORT).show());
            mAddTask.execute();
        }
    }

    public void fabClickAction() {
        Intent mIntent = new Intent(ContactsContract.Intents.Insert.ACTION);
        mIntent.setType(ContactsContract.RawContacts.CONTENT_TYPE);
        startActivityForResult(mIntent, 1);
    }

    void loadContactList() {
        ContactsListTask mAsyncTask = new ContactsListTask(getContext(), mContactList -> {
            mAdapter = new ContactsAdapter(this, getContext(), mContactList);
            mRecyclerView.setAdapter(mAdapter);
            mSearchView.setQueryHint("Search among your " + sizeContactList(mContactList) + " contacts");
        });
        mAsyncTask.execute();
    }

    @SuppressWarnings("ConstantConditions")
    private ArrayList<String> getPhoneNumbers(String mContactId) {
        ArrayList<String> mNumbers = null;
        @SuppressLint("Recycle") Cursor mCursor = getContext().getContentResolver().query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER},
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                new String[]{mContactId},
                null);
        if (mCursor != null) {
            mNumbers = new ArrayList<>();
            while (mCursor.moveToNext()) mNumbers.add(mCursor.getString(0));
        }
        return mNumbers;
    }

    private int sizeContactList(ArrayList<ContactsDataPair> mContactList) {
        int mSize = 0;
        for (ContactsDataPair mContact : mContactList)
            if (mContact.getContactId() != null) mSize++;
        return mSize;
    }
}