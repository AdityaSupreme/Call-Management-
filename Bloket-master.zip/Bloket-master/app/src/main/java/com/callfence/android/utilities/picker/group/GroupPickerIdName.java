package com.callfence.android.utilities.picker.group;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.Nullable;

public class GroupPickerIdName implements Parcelable {

    public static final Creator<GroupPickerIdName> CREATOR = new Creator<GroupPickerIdName>() {
        @Override
        public GroupPickerIdName createFromParcel(Parcel mParcel) {
            return new GroupPickerIdName(mParcel);
        }

        @Override
        public GroupPickerIdName[] newArray(int mSize) {
            return new GroupPickerIdName[mSize];
        }
    };
    private String mGroupId, mGroupName;

    public GroupPickerIdName(String mGroupId, String mGroupName) {
        this.mGroupId = mGroupId;
        this.mGroupName = mGroupName;
    }

    private GroupPickerIdName(Parcel mParcel) {
        mGroupId = mParcel.readString();
        mGroupName = mParcel.readString();
    }

    @Override
    public boolean equals(@Nullable Object mObject) {
        return mObject instanceof GroupPickerIdName &&
                this.mGroupId != null && this.mGroupId.equals(((GroupPickerIdName) mObject).mGroupId) &&
                this.mGroupName != null && this.mGroupName.equals(((GroupPickerIdName) mObject).mGroupName);
    }

    @Override
    public void writeToParcel(Parcel mParcel, int mFlags) {
        mParcel.writeString(mGroupId);
        mParcel.writeString(mGroupName);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public String getGroupId() {
        return mGroupId;
    }

    public String getGroupName() {
        return mGroupName;
    }
}