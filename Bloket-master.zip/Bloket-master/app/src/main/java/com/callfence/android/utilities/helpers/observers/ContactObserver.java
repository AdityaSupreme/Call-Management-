package com.callfence.android.utilities.helpers.observers;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.ContentObserver;
import android.os.Handler;
import android.preference.PreferenceManager;

import com.callfence.android.groups.GroupRemovalTask;

public class ContactObserver extends ContentObserver {

    @SuppressLint("StaticFieldLeak")
    private static Context mContext;
    private static SharedPreferences mPreferences;

    public ContactObserver(Context mContext, Handler mHandler) {
        super(mHandler);
        ContactObserver.mContext = mContext;
    }

    public static boolean isDtsChanged(Context mContext) {
        if (ContactObserver.mContext == null) ContactObserver.mContext = mContext;
        if (mPreferences == null)
            mPreferences = PreferenceManager.getDefaultSharedPreferences(mContext);

        long mObTimestamp = mPreferences.getLong("BL_CT_OB_TIMESTAMP", 0);
        long mDrTimestamp = mPreferences.getLong("BL_CT_DR_TIMESTAMP", 0);
        if (mObTimestamp > mDrTimestamp) {
            putContactVersion(mPreferences, "BL_CT_DR_TIMESTAMP");
            return true;
        }
        return false;
    }

    public static boolean isFtsChanged(Context mContext) {
        if (ContactObserver.mContext == null) ContactObserver.mContext = mContext;
        if (mPreferences == null)
            mPreferences = PreferenceManager.getDefaultSharedPreferences(mContext);

        long mObTimestamp = mPreferences.getLong("BL_CT_OB_TIMESTAMP", 0);
        long mFgTimestamp = mPreferences.getLong("BL_CT_FG_TIMESTAMP", 0);
        if (mObTimestamp > mFgTimestamp) {
            putContactVersion(mPreferences, "BL_CT_FG_TIMESTAMP");
            return true;
        }
        return false;
    }

    private static void putContactVersion(SharedPreferences mPreferences, String mKeyName) {
        SharedPreferences.Editor mEditor = mPreferences.edit();
        mEditor.putLong(mKeyName, System.currentTimeMillis());
        mEditor.apply();
    }

    @Override
    public void onChange(boolean mSelfChange) {
        super.onChange(mSelfChange);
        if (mPreferences == null)
            mPreferences = PreferenceManager.getDefaultSharedPreferences(mContext);

        SharedPreferences.Editor mEditor = mPreferences.edit();
        mEditor.putLong("BL_CT_OB_TIMESTAMP", System.currentTimeMillis());
        mEditor.apply();

        // Run group removal task
        if (mContext != null) new GroupRemovalTask(mContext).execute();
    }
}