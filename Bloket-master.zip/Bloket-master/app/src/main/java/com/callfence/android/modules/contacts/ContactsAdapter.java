package com.callfence.android.modules.contacts;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;
import android.text.Spannable;
import android.text.style.StyleSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.callfence.android.R;
import com.callfence.android.utilities.events.RefreshBlacklistEvent;
import com.callfence.android.utilities.events.RefreshCallLogEvent;
import com.callfence.android.utilities.events.RefreshDialerEvent;
import com.callfence.android.utilities.events.RefreshWhitelistEvent;
import com.callfence.android.utilities.helpers.database.DatabaseHelper;
import com.callfence.android.utilities.picker.group.GroupPickerActivity;
import com.l4digital.fastscroll.FastScroller;
import com.mikhaellopez.circularimageview.CircularImageView;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;

class ContactsAdapter extends RecyclerView.Adapter implements FastScroller.SectionIndexer, Filterable {

    private ArrayList<ContactsDataPair> mContactsList;
    private ArrayList<ContactsDataPair> mFilteredList;
    private ContactsFragment mFragment;
    private Context mContext;
    private String mSearchText = "";
    private StyleSpan mBoldSpan;

    ContactsAdapter(ContactsFragment mFragment, Context mContext, ArrayList<ContactsDataPair> mContactsList) {
        this.mFragment = mFragment;
        this.mContext = mContext;
        this.mContactsList = mContactsList;
        this.mFilteredList = mContactsList;
        this.mBoldSpan = new StyleSpan(android.graphics.Typeface.BOLD);
    }

    @Override
    public int getItemViewType(int mPosition) {
        if (mFilteredList.isEmpty())
            return -1;
        return mFilteredList.get(mPosition).getRowType();
    }

    @SuppressWarnings("NullableProblems")
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup mParent, int mViewType) {
        if (mViewType == -1) {
            View mView = LayoutInflater.from(mParent.getContext()).inflate(R.layout.fm_contacts_list_empty, mParent, false);
            return new EmptyViewHolder(mView);
        } else if (mViewType == 0) {
            View mView = LayoutInflater.from(mParent.getContext()).inflate(R.layout.fm_contacts_list_row, mParent, false);
            return new ContactsViewHolder(mView);
        } else {
            View mView = LayoutInflater.from(mParent.getContext()).inflate(R.layout.fm_contacts_list_header, mParent, false);
            return new HeaderViewHolder(mView);
        }
    }

    @SuppressWarnings("NullableProblems")
    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder mHolder, int mPosition) {
        if (mHolder instanceof ContactsViewHolder) {
            ContactsViewHolder mContactsHolder = ((ContactsViewHolder) mHolder);
            ContactsDataPair mDataPair = mFilteredList.get(mPosition);

            // Highlight filtered text
            String mDisplayName = mDataPair.getDisplayName();
            String mLowerCaseName = mDisplayName.toLowerCase();
            if (mLowerCaseName.contains(mSearchText)) {
                int mPosStr = mLowerCaseName.indexOf(mSearchText);
                int mPosEnd = mPosStr + mSearchText.length();
                Spannable mSpanString = Spannable.Factory.getInstance().newSpannable(mDisplayName);
                mSpanString.setSpan(mBoldSpan, mPosStr, mPosEnd, Spannable.SPAN_EXCLUSIVE_INCLUSIVE);
                mContactsHolder.mContactName.setText(mSpanString);
            } else {
                mContactsHolder.mContactName.setText(mDisplayName);
            }

            if (mDataPair.getPhotoUri() == null) {
                mContactsHolder.mContactFirstLetter.setVisibility(View.VISIBLE);
                mContactsHolder.mContactFirstLetter.setText(mDataPair.getDisplayName().substring(0, 1));
                mContactsHolder.mContactImage.setImageResource(R.drawable.ic_contact_default);
            } else {
                mContactsHolder.mContactFirstLetter.setVisibility(View.INVISIBLE);
                mContactsHolder.mContactImage.setImageURI(Uri.parse(mDataPair.getPhotoUri()));
            }
        }

        if (mHolder instanceof HeaderViewHolder) {
            if (mPosition >= 0)
                ((HeaderViewHolder) mHolder).mHeaderText.setText(mFilteredList.get(mPosition).getHeaderName());
        }
    }

    @Override
    public CharSequence getSectionText(int position) {
        return mFilteredList.get(position).getDisplayName().substring(0, 1);
    }

    @Override
    public int getItemCount() {
        if (mFilteredList.size() == 0)
            return 1;
        return mFilteredList.size();
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence mCharSequence) {
                mSearchText = mCharSequence.toString().toLowerCase();
                if (mSearchText.isEmpty()) {
                    mFilteredList = mContactsList;
                } else {
                    // Normal search
                    ArrayList<ContactsDataPair> mList = new ArrayList<>();
                    for (ContactsDataPair mPair : mContactsList) {
                        if (mPair.getRowType() == 0 && mPair.getDisplayName().toLowerCase().contains(mSearchText))
                            mList.add(mPair);
                    }
                    mFilteredList = mList;
                }
                FilterResults mFilteredResults = new FilterResults();
                mFilteredResults.values = mFilteredList;
                return mFilteredResults;
            }

            @SuppressWarnings("unchecked")
            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                mFilteredList = (ArrayList<ContactsDataPair>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }

    private void removeListItem(int mPosition) {
        mContactsList.remove(mFilteredList.get(mPosition));
        mFilteredList.remove(mPosition);
        notifyDataSetChanged();
    }

    class EmptyViewHolder extends RecyclerView.ViewHolder {

        EmptyViewHolder(View mView) {
            super(mView);
        }
    }

    class HeaderViewHolder extends RecyclerView.ViewHolder {
        TextView mHeaderText;

        HeaderViewHolder(View mView) {
            super(mView);
            mHeaderText = mView.findViewById(R.id.cfHeaderText);
        }
    }

    class ContactsViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        CircularImageView mContactImage;
        LinearLayout mContactContainer;
        TextView mContactName, mContactFirstLetter;

        ContactsViewHolder(View mView) {
            super(mView);
            mContactName = mView.findViewById(R.id.drContactName);
            mContactFirstLetter = mView.findViewById(R.id.drContactFirstLetter);
            mContactImage = mView.findViewById(R.id.drContactImage);
            mContactContainer = mView.findViewById(R.id.cnContactContainer);

            // Set click listeners
            mContactContainer.setOnClickListener(this);
        }

        @Override
        public void onClick(View mView) {
            showOptionsDialog(getAdapterPosition());
        }

        private void showOptionsDialog(final int mPosition) {
            @SuppressLint("InflateParams") View mContentView = LayoutInflater.from(mContext).inflate(R.layout.fm_contacts_option, null);
            final Dialog mDialog = new Dialog(mContext);
            mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            mDialog.setContentView(mContentView);

            TextView mDisplayName = mDialog.findViewById(R.id.tvDisplayName);
            mDisplayName.setText(mFilteredList.get(mPosition).getDisplayName());

            TextView mViewDetails = mContentView.findViewById(R.id.tvViewDetails);
            mViewDetails.setOnClickListener(mView -> {
                Intent mIntent = new Intent(Intent.ACTION_VIEW);
                mIntent.setData(Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_URI, mFilteredList.get(mPosition).getContactId()));
                mContext.startActivity(mIntent);
                mDialog.dismiss();
            });

            TextView mAddToGroup = mContentView.findViewById(R.id.tvAddToGroup);
            mAddToGroup.setOnClickListener(mView -> {
                ContactsFragment.mAddContactId = mFilteredList.get(mPosition).getContactId();
                Intent mIntent = new Intent(mContext, GroupPickerActivity.class);
                mIntent.putExtra("CHOICE_MODE", true);
                mFragment.startActivityForResult(mIntent, GroupPickerActivity.PICKER_REQUEST_CODE);
                mDialog.dismiss();
            });

            TextView mAddBlacklist = mContentView.findViewById(R.id.tvAddBlacklist);
            mAddBlacklist.setOnClickListener(mView -> {
                String mContactId = mFilteredList.get(mPosition).getContactId();
                DatabaseHelper mDbHelper = new DatabaseHelper(mContext);
                for (String mNumber : getPhoneNumbers(mContactId)) {
                    if (!mDbHelper.chkBlacklistContact(mContactId, mNumber)) {
                        mDbHelper.putBlacklistData(DatabaseHelper.BW_ENTRY_TYPE_CONTACT, DatabaseHelper.DEFAULT_GROUP_ID, "", mContactId, mNumber, "", "", "", "");
                        EventBus.getDefault().post(new RefreshBlacklistEvent(true));
                    }
                }
                Toast.makeText(mContext, "Success", Toast.LENGTH_SHORT).show();
                mDialog.dismiss();
            });

            TextView mAddWhitelist = mContentView.findViewById(R.id.tvAddWhitelist);
            mAddWhitelist.setOnClickListener(mView -> {
                String mContactId = mFilteredList.get(mPosition).getContactId();
                DatabaseHelper mDbHelper = new DatabaseHelper(mContext);
                for (String mNumber : getPhoneNumbers(mContactId)) {
                    if (!mDbHelper.chkWhitelistContact(mContactId, mNumber)) {
                        mDbHelper.putWhitelistData(DatabaseHelper.BW_ENTRY_TYPE_CONTACT, DatabaseHelper.DEFAULT_GROUP_ID, "", mContactId, mNumber, "", "", "");
                        EventBus.getDefault().post(new RefreshWhitelistEvent(true));
                    }
                }
                Toast.makeText(mContext, "Success", Toast.LENGTH_SHORT).show();
                mDialog.dismiss();
            });

            TextView mDeleteItem = mContentView.findViewById(R.id.tvDeleteItem);
            mDeleteItem.setOnClickListener(mView -> {
                @SuppressLint("Recycle") Cursor mCursor = mContext.getContentResolver().query(ContactsContract.Contacts.CONTENT_URI, null, ContactsContract.Contacts._ID + "=" + mFilteredList.get(mPosition).getContactId(), null, null);
                if (mCursor != null) {
                    while (mCursor.moveToNext()) {
                        try {
                            String mKey = mCursor.getString(mCursor.getColumnIndex(ContactsContract.Contacts.LOOKUP_KEY));
                            Uri mUri = Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_LOOKUP_URI, mKey);
                            mContext.getContentResolver().delete(mUri, ContactsContract.Contacts._ID + "=" + mFilteredList.get(mPosition).getContactId(), null);
                        } catch (Exception mException) {
                            Log.d("ContactsAdapter", "Error deleting contact, " + mException.getMessage());
                        }
                    }
                    mCursor.close();
                }

                removeListItem(mPosition);
                mFragment.loadContactList();
                EventBus.getDefault().post(new RefreshDialerEvent(true));
                EventBus.getDefault().post(new RefreshCallLogEvent(true));
                EventBus.getDefault().post(new RefreshBlacklistEvent(true));
                EventBus.getDefault().post(new RefreshWhitelistEvent(true));
                Toast.makeText(mContext, "Deleted", Toast.LENGTH_SHORT).show();
                mDialog.dismiss();
            });
            mDialog.show();
        }

        private ArrayList<String> getPhoneNumbers(String mContactId) {
            ArrayList<String> mNumbers = null;
            @SuppressLint("Recycle") Cursor mCursor = mContext.getContentResolver().query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER},
                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                    new String[]{mContactId},
                    null);
            if (mCursor != null) {
                mNumbers = new ArrayList<>();
                while (mCursor.moveToNext()) mNumbers.add(mCursor.getString(0));
            }
            return mNumbers;
        }
    }
}