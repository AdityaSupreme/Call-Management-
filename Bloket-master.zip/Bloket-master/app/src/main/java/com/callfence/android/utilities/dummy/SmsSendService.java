package com.callfence.android.utilities.dummy;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class SmsSendService extends Service {

    @Override
    public IBinder onBind(Intent mIntent) {
        return null;
    }
}
