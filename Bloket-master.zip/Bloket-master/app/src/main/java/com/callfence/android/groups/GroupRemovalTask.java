package com.callfence.android.groups;

import android.annotation.SuppressLint;
import android.content.ContentProviderClient;
import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.os.AsyncTask;
import android.provider.ContactsContract;
import android.util.Log;

import com.callfence.android.utilities.helpers.database.DatabaseHelper;

import java.util.ArrayList;

public class GroupRemovalTask extends AsyncTask<Void, Void, Void> {

    @SuppressLint("StaticFieldLeak")
    private Context mContext;
    private DatabaseHelper mDbHelper;

    public GroupRemovalTask(Context mContext) {
        this.mContext = mContext;
    }

    @Override
    protected Void doInBackground(Void... mVoid) {
        try {
            mDbHelper = new DatabaseHelper(mContext);
            ArrayList<String> mBlacklistContacts = mDbHelper.getBlacklistGroupContacts();
            ArrayList<String> mWhitelistContacts = mDbHelper.getWhitelistGroupContacts();
            if (!mBlacklistContacts.isEmpty()) deleteInvalidItems(0, mBlacklistContacts);
            if (!mWhitelistContacts.isEmpty()) deleteInvalidItems(1, mWhitelistContacts);
        } catch (Exception mException) {
            Log.d("BLOKET_LOGS", "GroupRemovalTask: Error fetching data, Details: " + mException.toString());
        }
        return null;
    }

    @SuppressWarnings("ConstantConditions")
    @SuppressLint("Recycle")
    private void deleteInvalidItems(int mType, ArrayList<String> mContactIds) {
        try {
            Cursor mCursor;
            ContentResolver mContactResolver = mContext.getContentResolver();
            ContentProviderClient mProviderClient = mContactResolver.acquireContentProviderClient(ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
            if (mProviderClient == null) return;
            if (mDbHelper == null) mDbHelper = new DatabaseHelper(mContext);

            for (String mContactId : mContactIds) {
                if (mContactId.equals("")) continue;
                mCursor = mProviderClient.query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        new String[]{ContactsContract.Contacts.DISPLAY_NAME},
                        ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                        new String[]{mContactId}, null);

                if (mCursor != null && mCursor.moveToFirst()) {
                    mCursor.close();
                    continue;
                } else {
                    if (mType == 0) {
                        mDbHelper.delBlacklistInvalidGroupItem(mContactId);
                    } else {
                        mDbHelper.delWhitelistInvalidGroupItem(mContactId);
                    }
                }
                mCursor.close();
            }
        } catch (Exception mException) {
            Log.d("BLOKET_LOGS", "GroupRemovalTask: Error performing invalid item removal, Details: " + mException.getMessage());
        }
    }
}