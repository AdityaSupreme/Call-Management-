package com.callfence.android.modules.blacklist;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.callfence.android.R;
import com.callfence.android.preferences.BlockPreferences;
import com.callfence.android.utilities.helpers.database.DatabaseHelper;
import com.callfence.android.utilities.helpers.ui.UIHelper;
import com.github.florent37.singledateandtimepicker.dialog.DoubleDateAndTimePickerDialog;
import com.mikhaellopez.circularimageview.CircularImageView;

import java.util.ArrayList;
import java.util.Date;

class BlacklistAdapter extends RecyclerView.Adapter {

    private ArrayList<BlacklistDataPair> mList;
    private BlacklistFragment mFragment;
    private ContentResolver mContentResolver;
    private Context mContext;
    private DatabaseHelper mDbHelper;
    private SharedPreferences mPreferences;

    BlacklistAdapter(BlacklistFragment mFragment, Context mContext, ArrayList<BlacklistDataPair> mList) {
        this.mFragment = mFragment;
        this.mContext = mContext;
        this.mList = mList;
        this.mContentResolver = mContext.getContentResolver();
        this.mPreferences = PreferenceManager.getDefaultSharedPreferences(mContext);
        this.mDbHelper = new DatabaseHelper(mContext);
    }

    @Override
    public int getItemViewType(int mPosition) {
        if (mPosition == 0) {
            return 0;
        } else {
            return mList.get(mPosition - 1).getType();
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup mParent, int mViewType) {
        if (mViewType == 0) {
            View mView = LayoutInflater.from(mParent.getContext()).inflate(R.layout.fm_blacklist_preferences, mParent, false);
            return new PreferencesViewHolder(mView);
        } else if (mViewType == DatabaseHelper.BW_ENTRY_TYPE_CONTACT) {
            View mView = LayoutInflater.from(mParent.getContext()).inflate(R.layout.fm_blacklist_row, mParent, false);
            return new ContactViewHolder(mView);
        } else if (mViewType == DatabaseHelper.BW_ENTRY_TYPE_NUMBER) {
            View mView = LayoutInflater.from(mParent.getContext()).inflate(R.layout.fm_blacklist_row, mParent, false);
            return new NumberViewHolder(mView);
        } else if (mViewType == DatabaseHelper.BW_ENTRY_TYPE_STARTS) {
            View mView = LayoutInflater.from(mParent.getContext()).inflate(R.layout.fm_blacklist_row, mParent, false);
            return new StartsViewHolder(mView);
        } else if (mViewType == DatabaseHelper.BW_ENTRY_TYPE_ENDS) {
            View mView = LayoutInflater.from(mParent.getContext()).inflate(R.layout.fm_blacklist_row, mParent, false);
            return new EndsViewHolder(mView);
        } else if (mViewType == DatabaseHelper.BW_ENTRY_TYPE_CONTAINS) {
            View mView = LayoutInflater.from(mParent.getContext()).inflate(R.layout.fm_blacklist_row, mParent, false);
            return new ContainsViewHolder(mView);
        } else if (mViewType == DatabaseHelper.BW_ENTRY_TYPE_RANGE) {
            View mView = LayoutInflater.from(mParent.getContext()).inflate(R.layout.fm_blacklist_row, mParent, false);
            return new RangeViewHolder(mView);
        } else {
            View mView = LayoutInflater.from(mParent.getContext()).inflate(R.layout.fm_blacklist_row, mParent, false);
            return new GroupViewHolder(mView);
        }
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder mHolder, int mPosition) {
        if (mHolder instanceof PreferencesViewHolder) {
            PreferencesViewHolder mDataHolder = ((PreferencesViewHolder) mHolder);
            if (mPreferences == null)
                mPreferences = PreferenceManager.getDefaultSharedPreferences(mContext);
            mDataHolder.mEnableBlock.setChecked(mPreferences.getBoolean("BL_PF_BLOCK_CL_ENABLED", false));
        }

        if (mHolder instanceof ContactViewHolder) {
            BlacklistDataPair mDataPair = mList.get(mPosition - 1);
            ContactViewHolder mDataHolder = ((ContactViewHolder) mHolder);

            if (mDataPair.getDisplayName() == null || mDataPair.getPhotoUri() == null) {
                String[] mDetails = getNameAndImage(mDataPair.getContactId());
                mDataPair.setDisplayName(mDetails[0] == null || mDetails[0].equals("") ? mDataPair.getMatchData() : mDetails[0]);
                mDataPair.setPhotoUri(mDetails[1]);
            }

            mDataHolder.mContactName.setText(mDataPair.getDisplayName());
            if (mDataPair.getDisplayName().equals(mDataPair.getMatchData())) {
                mDataHolder.mPhoneNumber.setVisibility(View.GONE);
            } else {
                mDataHolder.mPhoneNumber.setVisibility(View.VISIBLE);
                mDataHolder.mPhoneNumber.setText(mDataPair.getMatchData());
            }

            if ((mDataPair.getPhotoUri() == null || mDataPair.getPhotoUri().equals("")) && !mDataPair.getDisplayName().equals("")) {
                mDataHolder.mContactLetter.setVisibility(View.VISIBLE);
                mDataHolder.mContactLetter.setText(mDataPair.getDisplayName().substring(0, 1));
                mDataHolder.mContactImage.setImageResource(R.drawable.ic_contact_default);
            } else {
                mDataHolder.mContactLetter.setVisibility(View.INVISIBLE);
                mDataHolder.mContactImage.setImageURI(Uri.parse(mDataPair.getPhotoUri()));
            }

            mDataHolder.mActionMessage.setVisibility(mDataPair.getReplyMessage().length() > 0 ? View.VISIBLE : View.GONE);
            mDataHolder.mActionSchedule.setVisibility(mDataPair.getStartTime().length() > 0 ? View.VISIBLE : View.GONE);
        }

        if (mHolder instanceof NumberViewHolder) {
            BlacklistDataPair mDataPair = mList.get(mPosition - 1);
            NumberViewHolder mDataHolder = ((NumberViewHolder) mHolder);
            mDataHolder.mPhoneNumber.setVisibility(View.GONE);
            mDataHolder.mContactName.setText(mDataPair.getMatchData());
            mDataHolder.mContactLetter.setText(mDataPair.getMatchData().substring(0, 1));
            mDataHolder.mContactImage.setImageResource(R.drawable.ic_contact_default);
            mDataHolder.mActionMessage.setVisibility(mDataPair.getReplyMessage().length() > 0 ? View.VISIBLE : View.GONE);
            mDataHolder.mActionSchedule.setVisibility(mDataPair.getStartTime().length() > 0 ? View.VISIBLE : View.GONE);
        }

        if (mHolder instanceof StartsViewHolder) {
            BlacklistDataPair mDataPair = mList.get(mPosition - 1);
            StartsViewHolder mDataHolder = ((StartsViewHolder) mHolder);
            mDataHolder.mContactName.setText(mContext.getString(R.string.gr_title_starts));
            mDataHolder.mPhoneNumber.setText(mDataPair.getMatchData());
            mDataHolder.mContactLetter.setText("?..");
            mDataHolder.mContactImage.setImageResource(R.drawable.ic_contact_default);
            mDataHolder.mActionMessage.setVisibility(mDataPair.getReplyMessage().length() > 0 ? View.VISIBLE : View.GONE);
            mDataHolder.mActionSchedule.setVisibility(mDataPair.getStartTime().length() > 0 ? View.VISIBLE : View.GONE);
        }

        if (mHolder instanceof EndsViewHolder) {
            BlacklistDataPair mDataPair = mList.get(mPosition - 1);
            EndsViewHolder mDataHolder = ((EndsViewHolder) mHolder);
            mDataHolder.mContactName.setText(mContext.getString(R.string.gr_title_ends));
            mDataHolder.mPhoneNumber.setText(mDataPair.getMatchData());
            mDataHolder.mContactLetter.setText("..?");
            mDataHolder.mContactImage.setImageResource(R.drawable.ic_contact_default);
            mDataHolder.mActionMessage.setVisibility(mDataPair.getReplyMessage().length() > 0 ? View.VISIBLE : View.GONE);
            mDataHolder.mActionSchedule.setVisibility(mDataPair.getStartTime().length() > 0 ? View.VISIBLE : View.GONE);
        }

        if (mHolder instanceof ContainsViewHolder) {
            BlacklistDataPair mDataPair = mList.get(mPosition - 1);
            ContainsViewHolder mDataHolder = ((ContainsViewHolder) mHolder);
            mDataHolder.mContactName.setText(mContext.getString(R.string.gr_title_contains));
            mDataHolder.mPhoneNumber.setText(mDataPair.getMatchData());
            mDataHolder.mContactLetter.setText(".?.");
            mDataHolder.mContactImage.setImageResource(R.drawable.ic_contact_default);
            mDataHolder.mActionMessage.setVisibility(mDataPair.getReplyMessage().length() > 0 ? View.VISIBLE : View.GONE);
            mDataHolder.mActionSchedule.setVisibility(mDataPair.getStartTime().length() > 0 ? View.VISIBLE : View.GONE);
        }

        if (mHolder instanceof RangeViewHolder) {
            BlacklistDataPair mDataPair = mList.get(mPosition - 1);
            RangeViewHolder mDataHolder = ((RangeViewHolder) mHolder);
            mDataHolder.mContactName.setText(mContext.getString(R.string.gr_title_range));
            mDataHolder.mPhoneNumber.setText(mDataPair.getMatchData() + " to " + mDataPair.getRangeData());
            mDataHolder.mContactLetter.setText("?.?");
            mDataHolder.mContactImage.setImageResource(R.drawable.ic_contact_default);
            mDataHolder.mActionMessage.setVisibility(mDataPair.getReplyMessage().length() > 0 ? View.VISIBLE : View.GONE);
            mDataHolder.mActionSchedule.setVisibility(mDataPair.getStartTime().length() > 0 ? View.VISIBLE : View.GONE);
        }

        if (mHolder instanceof GroupViewHolder) {
            BlacklistDataPair mDataPair = mList.get(mPosition - 1);
            GroupViewHolder mDataHolder = ((GroupViewHolder) mHolder);
            mDataHolder.mContactName.setText(mContext.getString(R.string.gr_title_group));
            mDataHolder.mPhoneNumber.setText(mDataPair.getGroupName());
            mDataHolder.mContactLetter.setVisibility(View.GONE);
            mDataHolder.mContactImage.setImageResource(R.drawable.ic_action_group);
            mDataHolder.mActionMessage.setVisibility(mDataPair.getReplyMessage().length() > 0 ? View.VISIBLE : View.GONE);
            mDataHolder.mActionSchedule.setVisibility(mDataPair.getStartTime().length() > 0 ? View.VISIBLE : View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return mList.size() + 1;
    }

    private String[] getNameAndImage(String mContactId) {
        String mContactName = "", mContactImage = "";
        if (mContactId == null || mContactId.equals(""))
            return new String[]{mContactName, mContactImage};

        final Cursor mCursor = mContentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.Contacts.DISPLAY_NAME, ContactsContract.Contacts.PHOTO_URI},
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                new String[]{mContactId}, null);
        if (mCursor != null && mCursor.moveToFirst()) {
            mContactName = mCursor.getString(0);
            mContactImage = mCursor.getString(1);
        }
        if (mCursor != null) mCursor.close();
        return new String[]{mContactName, mContactImage};
    }

    private void removeListItem(int mPosition) {
        mList.remove(mPosition);
        notifyDataSetChanged();
    }

    @SuppressLint({"InflateParams", "SetTextI18n"})
    private void showOptionsDialog(final int mPosition, final int mType, final String mTitle, final String mDescription) {
        View mContentView = LayoutInflater.from(mContext).inflate(R.layout.fm_blacklist_option, null);
        final Dialog mDialog = new Dialog(mContext);
        mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        mDialog.setContentView(mContentView);

        TextView mTitleView = mDialog.findViewById(R.id.tvTitle);
        mTitleView.setText(mTitle);
        TextView mDescriptionView = mDialog.findViewById(R.id.tvDescription);
        mDescriptionView.setText(mDescription);

        TextView mSetTime = mContentView.findViewById(R.id.tvSetTime);
        mSetTime.setOnClickListener(mView -> {
            setBlockSchedule(mPosition);
            mDialog.dismiss();
        });

        TextView mRemoveTime = mContentView.findViewById(R.id.tvRemoveTime);
        mRemoveTime.setOnClickListener(mView -> {
            delBlockSchedule(mPosition);
            mDialog.dismiss();
        });

        TextView mSetMessage = mContentView.findViewById(R.id.tvSetMessage);
        mSetMessage.setOnClickListener(mView -> {
            setReplyMessage(mPosition);
            mDialog.dismiss();
        });

        TextView mDeleteItem = mContentView.findViewById(R.id.tvDeleteItem);
        mDeleteItem.setOnClickListener(mView -> {
            switch (mType) {
                case DatabaseHelper.BW_ENTRY_TYPE_CONTACT:
                    removeTypeContact(mPosition);
                    break;

                case DatabaseHelper.BW_ENTRY_TYPE_NUMBER:
                    removeTypeNumber(mPosition);
                    break;

                case DatabaseHelper.BW_ENTRY_TYPE_STARTS:
                    removeTypeStarts(mPosition);
                    break;

                case DatabaseHelper.BW_ENTRY_TYPE_ENDS:
                    removeTypeEnds(mPosition);
                    break;

                case DatabaseHelper.BW_ENTRY_TYPE_CONTAINS:
                    removeTypeContains(mPosition);
                    break;

                case DatabaseHelper.BW_ENTRY_TYPE_RANGE:
                    removeTypeRange(mPosition);
                    break;

                case DatabaseHelper.BW_ENTRY_TYPE_GROUP:
                    removeTypeGroup(mPosition);
                    break;

                default:
                    break;
            }
            mDialog.dismiss();
        });
        mDialog.show();
    }

    private void setBlockSchedule(final int mPosition) {
        if (mDbHelper == null) mDbHelper = new DatabaseHelper(mContext);
        String[] mSchedule = mDbHelper.getBlacklistSchedule(mList.get(mPosition).getId());
        Date mDateOne = (mSchedule == null || mSchedule[0].equals("")) ? new Date(System.currentTimeMillis()) : new Date(Long.valueOf(mSchedule[0]));
        Date mDateTwo = (mSchedule == null || mSchedule[1].equals("")) ? new Date(System.currentTimeMillis()) : new Date(Long.valueOf(mSchedule[1]));
        mFragment.mPickerDialog = new DoubleDateAndTimePickerDialog.Builder(mContext)
                .titleTextColor(mContext.getColor(R.color.colorWhite))
                .backgroundColor(mContext.getColor(R.color.colorWhite))
                .mainColor(mContext.getColor(R.color.colorPrimary))
                .tab0Text(mContext.getString(R.string.bp_start_time))
                .tab0Date(mDateOne)
                .tab1Text(mContext.getString(R.string.bp_end_time))
                .tab1Date(mDateTwo)
                .minutesStep(1)
                .buttonOkText(mContext.getString(R.string.gr_btn_set))
                .listener(mDates -> {
                    long mStrDate = mDates.get(0).getTime();
                    long mEndDate = mDates.get(1).getTime();
                    mDbHelper.updBlacklistSchedule(mList.get(mPosition).getId(), String.valueOf(mStrDate), String.valueOf(mEndDate));

                    mList.get(mPosition).setStartTime(String.valueOf(mStrDate));
                    mList.get(mPosition).setEndTime(String.valueOf(mEndDate));
                    notifyDataSetChanged();
                }).build();
        mFragment.mPickerDialog.display();
    }

    private void delBlockSchedule(final int mPosition) {
        if (mDbHelper == null) mDbHelper = new DatabaseHelper(mContext);
        mDbHelper.updBlacklistSchedule(mList.get(mPosition).getId(), "", "");

        mList.get(mPosition).setStartTime("");
        mList.get(mPosition).setEndTime("");
        notifyDataSetChanged();
    }

    private void setReplyMessage(final int mPosition) {
        @SuppressLint("InflateParams") View mContentView = LayoutInflater.from(mContext).inflate(R.layout.dg_generic_add_message, null, false);
        final Dialog mDialog = new Dialog(mContext);
        mDialog.setContentView(mContentView);
        if (mDbHelper == null) mDbHelper = new DatabaseHelper(mContext);
        EditText mReplyMessage = mContentView.findViewById(R.id.etReplyMessage);
        mReplyMessage.setText(mDbHelper.getBlacklistMessage(mList.get(mPosition).getId()));
        Button mNegative = mContentView.findViewById(R.id.btNegative);
        mNegative.setOnClickListener(mButtonView -> {
            UIHelper.hideSoftKeyboard(mContext, mReplyMessage);
            mDialog.dismiss();
        });

        Button mPositive = mContentView.findViewById(R.id.btPositive);
        mPositive.setOnClickListener(mButtonView -> {
            UIHelper.hideSoftKeyboard(mContext, mReplyMessage);
            String mMessage = mReplyMessage.getText().toString();
            if (mDbHelper == null) mDbHelper = new DatabaseHelper(mContext);
            mDbHelper.updBlacklistMessage(mList.get(mPosition).getId(), mMessage);

            mList.get(mPosition).setReplyMessage(mMessage);
            notifyDataSetChanged();
            mDialog.dismiss();

        });
        mDialog.show();
    }

    private void removeTypeContact(final int mPosition) {
        if (mDbHelper == null) mDbHelper = new DatabaseHelper(mContext);
        mDbHelper.delBlacklistContact(Integer.valueOf(mList.get(mPosition).getContactId()), mList.get(mPosition).getMatchData());
        removeListItem(mPosition);
    }

    private void removeTypeNumber(final int mPosition) {
        if (mDbHelper == null) mDbHelper = new DatabaseHelper(mContext);
        mDbHelper.delBlacklistNumber(mList.get(mPosition).getMatchData());
        removeListItem(mPosition);
    }

    private void removeTypeStarts(final int mPosition) {
        if (mDbHelper == null) mDbHelper = new DatabaseHelper(mContext);
        mDbHelper.delBlacklistStarts(mList.get(mPosition).getMatchData());
        removeListItem(mPosition);
    }

    private void removeTypeEnds(final int mPosition) {
        if (mDbHelper == null) mDbHelper = new DatabaseHelper(mContext);
        mDbHelper.delBlacklistEnds(mList.get(mPosition).getMatchData());
        removeListItem(mPosition);
    }

    private void removeTypeContains(final int mPosition) {
        if (mDbHelper == null) mDbHelper = new DatabaseHelper(mContext);
        mDbHelper.delBlacklistContains(mList.get(mPosition).getMatchData());
        removeListItem(mPosition);
    }

    private void removeTypeRange(final int mPosition) {
        if (mDbHelper == null) mDbHelper = new DatabaseHelper(mContext);
        mDbHelper.delBlacklistRange(mList.get(mPosition).getMatchData(), mList.get(mPosition).getRangeData());
        removeListItem(mPosition);
    }

    private void removeTypeGroup(final int mPosition) {
        if (mDbHelper == null) mDbHelper = new DatabaseHelper(mContext);
        mDbHelper.delBlacklistGroup(mList.get(mPosition).getGroupId());
        removeListItem(mPosition);
    }

    class PreferencesViewHolder extends RecyclerView.ViewHolder {

        RelativeLayout mBlockPrefs;
        Switch mEnableBlock;

        PreferencesViewHolder(View mView) {
            super(mView);
            mEnableBlock = mView.findViewById(R.id.swEnableBlock);
            mEnableBlock.setOnClickListener(this::onClick);
            mBlockPrefs = mView.findViewById(R.id.rlBlockPrefs);
            mBlockPrefs.setOnClickListener(this::onClick);
        }

        private void onClick(View mView) {
            if (mPreferences == null)
                mPreferences = PreferenceManager.getDefaultSharedPreferences(mContext);
            SharedPreferences.Editor mEditor = mPreferences.edit();

            switch (mView.getId()) {
                case R.id.swEnableBlock:
                    if (mEnableBlock.isChecked()) {
                        mEditor.putBoolean("BL_PF_BLOCK_CL_ENABLED", true);
                    } else {
                        mEditor.putBoolean("BL_PF_BLOCK_CL_ENABLED", false);
                    }
                    mEditor.apply();
                    break;

                case R.id.rlBlockPrefs:
                    mContext.startActivity(new Intent(mContext, BlockPreferences.class));
                    break;

                default:
                    break;
            }
        }
    }

    class ContactViewHolder extends RecyclerView.ViewHolder {

        CircularImageView mContactImage;
        ImageView mActionOptions, mActionSchedule, mActionMessage;
        TextView mContactLetter, mContactName, mPhoneNumber;

        ContactViewHolder(View mView) {
            super(mView);
            mContactImage = mView.findViewById(R.id.ivContactImage);
            mContactLetter = mView.findViewById(R.id.tvContactLetter);
            mContactName = mView.findViewById(R.id.tvContactName);
            mPhoneNumber = mView.findViewById(R.id.tvPhoneNumber);
            mActionOptions = mView.findViewById(R.id.ivOptions);
            mActionSchedule = mView.findViewById(R.id.ivSchedule);
            mActionMessage = mView.findViewById(R.id.ivMessage);
            mActionOptions.setOnClickListener(mItemView -> {
                int mAdapterPosition = getAdapterPosition() - 1;
                showOptionsDialog(mAdapterPosition, DatabaseHelper.BW_ENTRY_TYPE_CONTACT, mList.get(mAdapterPosition).getDisplayName(), mList.get(mAdapterPosition).getMatchData());
            });
            mActionSchedule.setOnClickListener(mItemView -> setBlockSchedule(getAdapterPosition() - 1));
            mActionMessage.setOnClickListener(mItemView -> setReplyMessage(getAdapterPosition() - 1));
        }
    }

    class NumberViewHolder extends RecyclerView.ViewHolder {

        CircularImageView mContactImage;
        ImageView mActionOptions, mActionSchedule, mActionMessage;
        TextView mContactLetter, mContactName, mPhoneNumber;

        NumberViewHolder(View mView) {
            super(mView);
            mContactImage = mView.findViewById(R.id.ivContactImage);
            mContactLetter = mView.findViewById(R.id.tvContactLetter);
            mContactName = mView.findViewById(R.id.tvContactName);
            mPhoneNumber = mView.findViewById(R.id.tvPhoneNumber);
            mActionOptions = mView.findViewById(R.id.ivOptions);
            mActionSchedule = mView.findViewById(R.id.ivSchedule);
            mActionMessage = mView.findViewById(R.id.ivMessage);
            mActionOptions.setOnClickListener(mItemView -> {
                int mAdapterPosition = getAdapterPosition() - 1;
                showOptionsDialog(mAdapterPosition, DatabaseHelper.BW_ENTRY_TYPE_NUMBER, mContext.getString(R.string.gr_title_number), mList.get(mAdapterPosition).getMatchData());
            });
            mActionSchedule.setOnClickListener(mItemView -> setBlockSchedule(getAdapterPosition() - 1));
            mActionMessage.setOnClickListener(mItemView -> setReplyMessage(getAdapterPosition() - 1));
        }
    }

    class StartsViewHolder extends RecyclerView.ViewHolder {

        CircularImageView mContactImage;
        ImageView mActionOptions, mActionSchedule, mActionMessage;
        TextView mContactLetter, mContactName, mPhoneNumber;

        StartsViewHolder(View mView) {
            super(mView);
            mContactImage = mView.findViewById(R.id.ivContactImage);
            mContactLetter = mView.findViewById(R.id.tvContactLetter);
            mContactName = mView.findViewById(R.id.tvContactName);
            mPhoneNumber = mView.findViewById(R.id.tvPhoneNumber);
            mActionOptions = mView.findViewById(R.id.ivOptions);
            mActionSchedule = mView.findViewById(R.id.ivSchedule);
            mActionMessage = mView.findViewById(R.id.ivMessage);
            mActionOptions.setOnClickListener(mItemView -> {
                int mAdapterPosition = getAdapterPosition() - 1;
                showOptionsDialog(mAdapterPosition, DatabaseHelper.BW_ENTRY_TYPE_STARTS, mContext.getString(R.string.gr_title_starts), mList.get(mAdapterPosition).getMatchData());
            });
            mActionSchedule.setOnClickListener(mItemView -> setBlockSchedule(getAdapterPosition() - 1));
            mActionMessage.setOnClickListener(mItemView -> setReplyMessage(getAdapterPosition() - 1));
        }
    }

    class EndsViewHolder extends RecyclerView.ViewHolder {

        CircularImageView mContactImage;
        ImageView mActionOptions, mActionSchedule, mActionMessage;
        TextView mContactLetter, mContactName, mPhoneNumber;

        EndsViewHolder(View mView) {
            super(mView);
            mContactImage = mView.findViewById(R.id.ivContactImage);
            mContactLetter = mView.findViewById(R.id.tvContactLetter);
            mContactName = mView.findViewById(R.id.tvContactName);
            mPhoneNumber = mView.findViewById(R.id.tvPhoneNumber);
            mActionOptions = mView.findViewById(R.id.ivOptions);
            mActionSchedule = mView.findViewById(R.id.ivSchedule);
            mActionMessage = mView.findViewById(R.id.ivMessage);
            mActionOptions.setOnClickListener(mItemView -> {
                int mAdapterPosition = getAdapterPosition() - 1;
                showOptionsDialog(mAdapterPosition, DatabaseHelper.BW_ENTRY_TYPE_ENDS, mContext.getString(R.string.gr_title_ends), mList.get(mAdapterPosition).getMatchData());
            });
            mActionSchedule.setOnClickListener(mItemView -> setBlockSchedule(getAdapterPosition() - 1));
            mActionMessage.setOnClickListener(mItemView -> setReplyMessage(getAdapterPosition() - 1));
        }
    }

    class ContainsViewHolder extends RecyclerView.ViewHolder {

        CircularImageView mContactImage;
        ImageView mActionOptions, mActionSchedule, mActionMessage;
        TextView mContactLetter, mContactName, mPhoneNumber;

        ContainsViewHolder(View mView) {
            super(mView);
            mContactImage = mView.findViewById(R.id.ivContactImage);
            mContactLetter = mView.findViewById(R.id.tvContactLetter);
            mContactName = mView.findViewById(R.id.tvContactName);
            mPhoneNumber = mView.findViewById(R.id.tvPhoneNumber);
            mActionOptions = mView.findViewById(R.id.ivOptions);
            mActionSchedule = mView.findViewById(R.id.ivSchedule);
            mActionMessage = mView.findViewById(R.id.ivMessage);
            mActionOptions.setOnClickListener(mItemView -> {
                int mAdapterPosition = getAdapterPosition() - 1;
                showOptionsDialog(mAdapterPosition, DatabaseHelper.BW_ENTRY_TYPE_CONTAINS, mContext.getString(R.string.gr_title_contains), mList.get(mAdapterPosition).getMatchData());
            });
            mActionSchedule.setOnClickListener(mItemView -> setBlockSchedule(getAdapterPosition() - 1));
            mActionMessage.setOnClickListener(mItemView -> setReplyMessage(getAdapterPosition() - 1));
        }
    }

    class RangeViewHolder extends RecyclerView.ViewHolder {

        CircularImageView mContactImage;
        ImageView mActionOptions, mActionSchedule, mActionMessage;
        TextView mContactLetter, mContactName, mPhoneNumber;

        RangeViewHolder(View mView) {
            super(mView);
            mContactImage = mView.findViewById(R.id.ivContactImage);
            mContactLetter = mView.findViewById(R.id.tvContactLetter);
            mContactName = mView.findViewById(R.id.tvContactName);
            mPhoneNumber = mView.findViewById(R.id.tvPhoneNumber);
            mActionOptions = mView.findViewById(R.id.ivOptions);
            mActionSchedule = mView.findViewById(R.id.ivSchedule);
            mActionMessage = mView.findViewById(R.id.ivMessage);
            mActionOptions.setOnClickListener(mItemView -> {
                int mAdapterPosition = getAdapterPosition() - 1;
                showOptionsDialog(mAdapterPosition, DatabaseHelper.BW_ENTRY_TYPE_RANGE, mContext.getString(R.string.gr_title_range), mList.get(mAdapterPosition).getMatchData() + " to " + mList.get(mAdapterPosition).getRangeData());
            });
            mActionSchedule.setOnClickListener(mItemView -> setBlockSchedule(getAdapterPosition() - 1));
            mActionMessage.setOnClickListener(mItemView -> setReplyMessage(getAdapterPosition() - 1));
        }
    }

    class GroupViewHolder extends RecyclerView.ViewHolder {

        CircularImageView mContactImage;
        ImageView mActionOptions, mActionSchedule, mActionMessage;
        TextView mContactLetter, mContactName, mPhoneNumber;

        GroupViewHolder(View mView) {
            super(mView);
            mContactImage = mView.findViewById(R.id.ivContactImage);
            mContactLetter = mView.findViewById(R.id.tvContactLetter);
            mContactName = mView.findViewById(R.id.tvContactName);
            mPhoneNumber = mView.findViewById(R.id.tvPhoneNumber);
            mActionOptions = mView.findViewById(R.id.ivOptions);
            mActionSchedule = mView.findViewById(R.id.ivSchedule);
            mActionMessage = mView.findViewById(R.id.ivMessage);
            mActionOptions.setOnClickListener(mItemView -> {
                int mAdapterPosition = getAdapterPosition() - 1;
                showOptionsDialog(mAdapterPosition, DatabaseHelper.BW_ENTRY_TYPE_GROUP, mContext.getString(R.string.gr_title_group), mList.get(mAdapterPosition).getGroupName());
            });
            mActionSchedule.setOnClickListener(mItemView -> setBlockSchedule(getAdapterPosition() - 1));
            mActionMessage.setOnClickListener(mItemView -> setReplyMessage(getAdapterPosition() - 1));
        }
    }
}