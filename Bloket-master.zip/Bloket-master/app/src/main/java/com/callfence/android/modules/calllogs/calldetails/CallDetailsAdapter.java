package com.callfence.android.modules.calllogs.calldetails;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.callfence.android.R;
import com.callfence.android.homescreen.HomeScreenActivity;
import com.callfence.android.modules.calllogs.CallLogDataPair;
import com.callfence.android.utilities.helpers.database.DatabaseHelper;
import com.callfence.android.utilities.helpers.observers.CallLogObserver;
import com.callfence.android.utilities.helpers.telephone.TelephoneHelper;
import com.callfence.android.utilities.helpers.ui.UIHelper;
import com.mikhaellopez.circularimageview.CircularImageView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;

class CallDetailsAdapter extends RecyclerView.Adapter {

    private ArrayList<CallLogDataPair> mCallList;
    private Context mContext;
    private Map<Integer, Integer> mCallTypeIcons = new HashMap<Integer, Integer>() {{
        put(CallLog.Calls.INCOMING_TYPE, R.drawable.ic_call_incoming);
        put(CallLog.Calls.OUTGOING_TYPE, R.drawable.ic_call_outgoing);
        put(CallLog.Calls.MISSED_TYPE, R.drawable.ic_call_missed);
        put(CallLog.Calls.REJECTED_TYPE, R.drawable.ic_call_rejected);
        put(CallLog.Calls.BLOCKED_TYPE, R.drawable.ic_call_blocked);
    }};

    private Map<Integer, String> mCallTypeText = new HashMap<Integer, String>() {{
        put(CallLog.Calls.INCOMING_TYPE, "Incoming call");
        put(CallLog.Calls.OUTGOING_TYPE, "Outgoing call");
        put(CallLog.Calls.MISSED_TYPE, "Missed call");
        put(CallLog.Calls.REJECTED_TYPE, "Rejected call");
        put(CallLog.Calls.BLOCKED_TYPE, "Blocked call");
    }};
    private String mPhoneNumber;

    CallDetailsAdapter(Context mContext, ArrayList<CallLogDataPair> mCallList, String mPhoneNumber) {
        this.mContext = mContext;
        this.mCallList = mCallList;
        this.mPhoneNumber = mPhoneNumber;
    }

    @Override
    public int getItemViewType(int mPosition) {
        if (mCallList.isEmpty())
            return 0;
        else if (mPosition == 0)
            return 1;
        else
            return 2;
    }

    @SuppressWarnings("NullableProblems")
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup mParent, int mViewType) {
        if (mViewType == 0) {
            View mView = LayoutInflater.from(mParent.getContext()).inflate(R.layout.ac_calllog_details_empty, mParent, false);
            return new EmptyViewHolder(mView);
        } else if (mViewType == 1) {
            View mView = LayoutInflater.from(mParent.getContext()).inflate(R.layout.ac_calllog_details_header, mParent, false);
            return new HeaderViewHolder(mView);
        } else {
            View mView = LayoutInflater.from(mParent.getContext()).inflate(R.layout.ac_calllog_details_row, mParent, false);
            return new CallLogsViewHolder(mView);
        }
    }

    @SuppressLint("SetTextI18n")
    @SuppressWarnings({"NullableProblems"})
    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder mHolder, int mPosition) {
        if (mHolder instanceof HeaderViewHolder) {
            HeaderViewHolder mDataHolder = ((HeaderViewHolder) mHolder);

            String[] mDetails = getNameAndImage(mPhoneNumber);
            boolean isNameEmpty = mDetails[0] == null || mDetails[0].equals("");
            if (isNameEmpty) {
                mDataHolder.mContactName.setText(mPhoneNumber);
                mDataHolder.mPhoneNumber.setVisibility(View.GONE);
            } else {
                mDataHolder.mContactName.setText(mDetails[0]);
                mDataHolder.mPhoneNumber.setText(mPhoneNumber);
                mDataHolder.mPhoneNumber.setVisibility(View.VISIBLE);
            }

            if (mDetails[1] == null || mDetails[1].equals("")) {
                if (isNameEmpty) {
                    mDataHolder.mContactLetter.setVisibility(View.INVISIBLE);
                    mDataHolder.mContactImage.setImageResource(R.drawable.ic_action_person);
                } else {
                    mDataHolder.mContactLetter.setVisibility(View.VISIBLE);
                    mDataHolder.mContactLetter.setText(mDetails[0].substring(0, 1));
                    mDataHolder.mContactImage.setImageResource(R.drawable.ic_contact_default);
                }
            } else {
                mDataHolder.mContactLetter.setVisibility(View.INVISIBLE);
                mDataHolder.mContactImage.setImageURI(Uri.parse(mDetails[1]));
            }
            return;
        }

        if (mHolder instanceof CallLogsViewHolder) {
            CallLogsViewHolder mDataHolder = ((CallLogsViewHolder) mHolder);
            CallLogDataPair mDataPair = mCallList.get(mPosition - 1);

            mDataHolder.mCallType.setImageResource(mCallTypeIcons.get(mDataPair.getCallType()));
            mDataHolder.mCallName.setText(mCallTypeText.get(mDataPair.getCallType()));
            mDataHolder.mTimeStamp.setText(mDataPair.getCallDate());
            if (mDataPair.getCallType() == CallLog.Calls.INCOMING_TYPE || mDataPair.getCallType() == CallLog.Calls.OUTGOING_TYPE) {
                long mSeconds = Long.valueOf(mDataPair.getCallDuration()) * 1000;
                mDataHolder.mCallDuration.setVisibility(View.VISIBLE);
                mDataHolder.mCallDuration.setText(String.format(Locale.getDefault(), "%02d min %02d sec", TimeUnit.MILLISECONDS.toMinutes(mSeconds), TimeUnit.MILLISECONDS.toSeconds(mSeconds) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(mSeconds))));
            } else {
                mDataHolder.mCallDuration.setVisibility(View.GONE);
            }
        }
    }

    @Override
    public int getItemCount() {
        return mCallList.size() + 1;
    }

    private void removeListItem(int mPosition) {
        mCallList.remove(mPosition);
        notifyDataSetChanged();
    }

    private String[] getNameAndImage(String mPhoneNumber) {
        String mContactName = "", mContactImage = "";
        if (mPhoneNumber == null || mPhoneNumber.equals(""))
            return new String[]{mContactName, mContactImage};

        final Cursor mCursor = mContext.getContentResolver().query(
                Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(mPhoneNumber)),
                new String[]{ContactsContract.Contacts.DISPLAY_NAME, ContactsContract.Contacts.PHOTO_URI},
                null, null, null);
        if (mCursor != null && mCursor.moveToFirst()) {
            mContactName = mCursor.getString(0);
            mContactImage = mCursor.getString(1);
        }
        if (mCursor != null) mCursor.close();
        return new String[]{mContactName, mContactImage};
    }

    class CallLogsViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        ImageView mCallType, mDeleteItem;
        TextView mCallName, mTimeStamp, mCallDuration;

        CallLogsViewHolder(View mView) {
            super(mView);
            mCallType = mView.findViewById(R.id.ivCallType);
            mDeleteItem = mView.findViewById(R.id.ivDeleteItem);
            mCallName = mView.findViewById(R.id.tvCallName);
            mTimeStamp = mView.findViewById(R.id.tvTimestamp);
            mCallDuration = mView.findViewById(R.id.tvCallDuration);

            // Set on click listener
            mDeleteItem.setOnClickListener(this);
        }

        @Override
        public void onClick(View mView) {
            if (mCallList.get(getAdapterPosition() - 1).getCallType() == CallLog.Calls.BLOCKED_TYPE) {
                DatabaseHelper mDbHelper = new DatabaseHelper(mContext);
                mDbHelper.delBlockLogs(mCallList.get(getAdapterPosition() - 1).getCallLogId());
                removeListItem(getAdapterPosition() - 1);
                CallLogObserver.putCallLogVersion(PreferenceManager.getDefaultSharedPreferences(mContext), "BL_CL_OB_TIMESTAMP");
            } else {
                if (mContext.checkSelfPermission(Manifest.permission.WRITE_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
                    UIHelper.showPermissionSnack((HomeScreenActivity) mContext, "write call log");
                    return;
                }
                mContext.getContentResolver().delete(
                        CallLog.Calls.CONTENT_URI,
                        CallLog.Calls._ID + " = " + mCallList.get(getAdapterPosition() - 1).getCallLogId(),
                        null);
                removeListItem(getAdapterPosition() - 1);
            }
        }
    }

    class HeaderViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        CircularImageView mContactImage;
        ImageView mCallNumber;
        TextView mContactLetter, mContactName, mPhoneNumber;

        HeaderViewHolder(View mView) {
            super(mView);
            mContactImage = mView.findViewById(R.id.ivContactImage);
            mContactLetter = mView.findViewById(R.id.tvContactLetter);
            mContactName = mView.findViewById(R.id.tvContactName);
            mPhoneNumber = mView.findViewById(R.id.tvPhoneNumber);
            mCallNumber = mView.findViewById(R.id.ivCallNumber);

            // Set on click listener
            mCallNumber.setOnClickListener(this);
        }

        @Override
        public void onClick(View mView) {
            if (mContext.checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                UIHelper.showPermissionSnack((HomeScreenActivity) mContext, "call phone");
                return;
            }
            TelephoneHelper.placeCall(mContext, mCallList.get(getAdapterPosition()).getPhoneNumber());
        }
    }

    class EmptyViewHolder extends RecyclerView.ViewHolder {

        EmptyViewHolder(View mView) {
            super(mView);
        }
    }
}