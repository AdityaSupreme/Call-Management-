package com.callfence.android.groups;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.callfence.android.R;
import com.callfence.android.utilities.helpers.database.DatabaseHelper;
import com.callfence.android.utilities.helpers.ui.UIHelper;
import com.callfence.android.utilities.picker.contact.ContactPickerActivity;
import com.callfence.android.utilities.picker.contact.ContactPickerResult;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.ArrayList;
import java.util.regex.Pattern;

public class GroupActivity extends AppCompatActivity implements View.OnClickListener {

    private DatabaseHelper mDbHelper;
    private GroupAdapter mAdapter;
    private RecyclerView mRecyclerView;
    private boolean mNewGroup;
    static String mGroupName;

    @SuppressWarnings("ConstantConditions")
    @Override
    protected void onCreate(@Nullable Bundle mSavedInstanceState) {
        super.onCreate(mSavedInstanceState);
        setContentView(R.layout.ac_group_list);

        // Set up toolbar
        Toolbar mToolbar = findViewById(R.id.tbToolbar);
        if (mToolbar != null) {
            setSupportActionBar(mToolbar);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Groups");
        }

        // Floating action button
        findViewById(R.id.btFabButton).setOnClickListener(this);

        // Set up group list
        mRecyclerView = findViewById(R.id.rvRecyclerView);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Load group list
        loadGroupList();
    }

    @Override
    public void onClick(View mView) {
        if (mView.getId() == R.id.btFabButton) {
            mNewGroup = true;
            Intent mIntent = new Intent(this, ContactPickerActivity.class);
            mIntent.putExtra("CHOICE_MODE", false);
            startActivityForResult(mIntent, ContactPickerActivity.PICKER_REQUEST_CODE);
        }
    }

    @Override
    protected void onActivityResult(int mRequestCode, int mResultCode, Intent mData) {
        super.onActivityResult(mRequestCode, mResultCode, mData);
        if (mRequestCode == ContactPickerActivity.PICKER_REQUEST_CODE) {
            if (mResultCode != RESULT_OK) return;
            ArrayList<ContactPickerResult> mSelectedContacts = new ArrayList<>(ContactPickerResult.obtainResult(mData));
            if (mNewGroup) {
                mNewGroup = false;
                showAddDialog(mSelectedContacts);
            } else {
                if (mDbHelper == null) mDbHelper = new DatabaseHelper(this);
                if (mGroupName == null || mGroupName.equals("")) return;
                GroupAddTask mAddTask = new GroupAddTask(this, mGroupName.replaceAll(" ", "").toUpperCase(), mGroupName, mSelectedContacts, mSuccess -> {
                    if (mSuccess) {
                        mAdapter = new GroupAdapter(this, mDbHelper.getGroupList());
                        mRecyclerView.setAdapter(mAdapter);
                    }
                });
                mAddTask.execute();
            }
        }
    }

    @SuppressWarnings("NullableProblems")
    @Override
    public boolean onOptionsItemSelected(MenuItem mItem) {
        finish();
        return super.onOptionsItemSelected(mItem);
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    private void loadGroupList() {
        GroupListTask mAsyncTask = new GroupListTask(getBaseContext(), mGroupList -> {
            if (mGroupList != null) {
                mAdapter = new GroupAdapter(this, mGroupList);
                mRecyclerView.setAdapter(mAdapter);
            }
        });
        mAsyncTask.execute();
    }

    @SuppressWarnings("ConstantConditions")
    private void showAddDialog(final ArrayList<ContactPickerResult> mSelectedContacts) {
        @SuppressLint("InflateParams") View mContentView = LayoutInflater.from(this).inflate(R.layout.ac_group_list_name, null, false);
        final Dialog mDialog = new Dialog(this);
        mDialog.setCanceledOnTouchOutside(false);
        mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        mDialog.setContentView(mContentView);

        TextInputLayout mGroupNameLayout = mContentView.findViewById(R.id.tiGroupName);
        TextInputEditText mGroupName = mContentView.findViewById(R.id.etGroupName);
        mGroupName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence mSequence, int mStart, int mCount, int mAfter) {
            }

            @Override
            public void onTextChanged(CharSequence mSequence, int mStart, int mBefore, int mCount) {
            }

            @Override
            public void afterTextChanged(Editable mEditable) {
                mGroupNameLayout.setError(null);
            }
        });

        Button mNegative = mContentView.findViewById(R.id.btNegative);
        mNegative.setOnClickListener(mButtonView -> {
            UIHelper.hideSoftKeyboard(this, mGroupName);
            mDialog.dismiss();
        });

        Button mPositive = mContentView.findViewById(R.id.btPositive);
        mPositive.setOnClickListener(mButtonView -> {
            String mName = mGroupName.getText().toString().trim();
            Pattern mPattern = Pattern.compile("[a-zA-Z0-9 ]+");
            if (mName.length() > 16) {
                mGroupNameLayout.setError("Name should be less than 16 characters.");
                return;
            }
            if (mName.length() > 0 && mPattern.matcher(mName).matches()) {
                if (mDbHelper == null) mDbHelper = new DatabaseHelper(this);
                if (!mDbHelper.chkGroupListName(mName)) {
                    GroupAddTask mAddTask = new GroupAddTask(this, mName.replaceAll(" ", "").toUpperCase(), mName, mSelectedContacts, mSuccess -> {
                        if (mSuccess) {
                            mAdapter = new GroupAdapter(this, mDbHelper.getGroupList());
                            mRecyclerView.setAdapter(mAdapter);
                        }
                    });
                    mAddTask.execute();
                    mDialog.dismiss();
                } else
                    mGroupNameLayout.setError("A group already exists with this name.");
            } else {
                mGroupNameLayout.setError("Enter a valid group name. Only letter, numbers and spaces are allowed.");
            }
        });
        mDialog.show();
    }
}
