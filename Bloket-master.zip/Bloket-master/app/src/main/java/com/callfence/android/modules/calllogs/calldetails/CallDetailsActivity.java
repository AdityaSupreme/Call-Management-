package com.callfence.android.modules.calllogs.calldetails;

import android.Manifest;
import android.app.Dialog;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.callfence.android.R;
import com.callfence.android.utilities.helpers.ui.UIHelper;

public class CallDetailsActivity extends AppCompatActivity {

    private CallDetailsAdapter mAdapter;
    private static final int PERM_READ_CALL_LOG = 0;
    private Dialog mProgressDialog;
    private RecyclerView mRecyclerView;

    @SuppressWarnings("ConstantConditions")
    @Override
    protected void onCreate(@Nullable Bundle mSavedInstanceState) {
        super.onCreate(mSavedInstanceState);
        setContentView(R.layout.ac_calllog_details);

        // Set up toolbar
        Toolbar mToolbar = findViewById(R.id.tbToolbar);
        if (mToolbar != null) {
            setSupportActionBar(mToolbar);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Call Details");
        }

        // Set up call log list
        mRecyclerView = findViewById(R.id.rvRecyclerView);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Show progress bar
        mProgressDialog = UIHelper.makeProgressDialog(this);
        mProgressDialog.show();

        // Load call log
        int mCallType = getIntent().getExtras().getInt("CALL_LOG_TYPE");
        int mCallCount = getIntent().getExtras().getInt("CALL_COUNT");
        long mRawDate = getIntent().getExtras().getLong("RAW_DATE");
        String mPhoneNumber = getIntent().getExtras().getString("PHONE_NUMBER");

        if (checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_CALL_LOG}, PERM_READ_CALL_LOG);
        } else {
            loadCallLog(mCallType, mPhoneNumber, mRawDate, mCallCount);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem mItem) {
        finish();
        return super.onOptionsItemSelected(mItem);
    }

    @Override
    public void onBackPressed() {
        finish();
    }


    private void loadCallLog(int mCallType, String mPhoneNumber, long mRawDate, int mCallCount) {
        CallDetailsTask mAsyncTask = new CallDetailsTask(this, mCallType, mPhoneNumber, mRawDate, mCallCount, mCallList -> {
            mAdapter = new CallDetailsAdapter(getBaseContext(), mCallList, mPhoneNumber);
            mRecyclerView.setAdapter(mAdapter);

            // Close progress dialog
            if (mProgressDialog != null && mProgressDialog.isShowing()) mProgressDialog.dismiss();
        });
        mAsyncTask.execute();
    }
}
