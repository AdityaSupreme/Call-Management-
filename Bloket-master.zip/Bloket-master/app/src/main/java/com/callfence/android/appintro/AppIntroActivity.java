package com.callfence.android.appintro;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.telecom.TelecomManager;

import androidx.annotation.Nullable;

import com.callfence.android.R;
import com.callfence.android.homescreen.HomeScreenActivity;

import io.github.dreierf.materialintroscreen.MaterialIntroActivity;
import io.github.dreierf.materialintroscreen.MessageButtonBehaviour;
import io.github.dreierf.materialintroscreen.SlideFragmentBuilder;

public class AppIntroActivity extends MaterialIntroActivity {

    private final int DEFAULT_DIALER = 1;

    @Override
    protected void onCreate(@Nullable Bundle mSavedInstanceState) {
        super.onCreate(mSavedInstanceState);

        String[] mPermissions;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            mPermissions = new String[]{
                    Manifest.permission.ANSWER_PHONE_CALLS,
                    Manifest.permission.CALL_PHONE,
                    Manifest.permission.READ_CALL_LOG,
                    Manifest.permission.READ_CONTACTS,
                    Manifest.permission.READ_PHONE_STATE,
                    Manifest.permission.SEND_SMS,
                    Manifest.permission.WRITE_CALL_LOG,
                    Manifest.permission.WRITE_CONTACTS};
        } else {
            mPermissions = new String[]{
                    Manifest.permission.CALL_PHONE,
                    Manifest.permission.READ_CALL_LOG,
                    Manifest.permission.READ_CONTACTS,
                    Manifest.permission.READ_PHONE_STATE,
                    Manifest.permission.SEND_SMS,
                    Manifest.permission.WRITE_CALL_LOG,
                    Manifest.permission.WRITE_CONTACTS};
        }

        Bundle mIntentExtras = getIntent().getExtras();
        if (mIntentExtras != null && mIntentExtras.containsKey("BL_NEEDS_PERMISSION")) {
            String mDesc = getString(R.string.ai_app_desc);
            addSlide(new SlideFragmentBuilder()
                    .title(getString(R.string.ai_app_name))
                    .description("\n\n " + mDesc)
                    .backgroundColor(R.color.colorPrimary)
                    .buttonsColor(R.color.colorPrimaryDark)
                    .image(R.drawable.im_intro_bloket)
                    .build());

            addSlide(new SlideFragmentBuilder()
                    .title(getString(R.string.ai_prm_name))
                    .description("\n\n" + getString(R.string.ai_prm_ness))
                    .backgroundColor(R.color.colorPrimary)
                    .buttonsColor(R.color.colorPrimaryDark)
                    .neededPermissions(mPermissions)
                    .image(R.drawable.im_intro_permission)
                    .build());
            return;
        }

        String mDesc = getString(R.string.ai_app_desc);
        addSlide(new SlideFragmentBuilder()
                .title(getString(R.string.ai_app_name))
                .description("\n\n " + mDesc)
                .backgroundColor(R.color.colorPrimary)
                .buttonsColor(R.color.colorPrimaryDark)
                .image(R.drawable.im_intro_bloket)
                .build());

        addSlide(new SlideFragmentBuilder()
                .title(getString(R.string.ai_prm_name))
                .description("\n\n" + getString(R.string.ai_prm_desc))
                .backgroundColor(R.color.colorPrimary)
                .buttonsColor(R.color.colorPrimaryDark)
                .neededPermissions(mPermissions)
                .image(R.drawable.im_intro_permission)
                .build());

        if (isDefaultDialerApp()) return;
        addSlide(new SlideFragmentBuilder()
                .title(getString(R.string.ai_dft_name))
                .description("\n\n" + getString(R.string.ai_dft_desc))
                .backgroundColor(R.color.colorPrimary)
                .buttonsColor(R.color.colorPrimaryDark)
                .image(R.drawable.im_intro_success)
                .build(), new MessageButtonBehaviour(mView -> {
            Intent mIntent = new Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER);
            mIntent.putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, getPackageName());
            startActivityForResult(mIntent, DEFAULT_DIALER);
        }, "Set Default"));
    }

    @Override
    public void onFinish() {

        // Write to preferences
        SharedPreferences mPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        SharedPreferences.Editor mEditor = mPreferences.edit();
        mEditor.putBoolean("BL_PF_INTRO", true);
        mEditor.apply();

        super.onFinish();
        Intent mIntent = new Intent(AppIntroActivity.this, HomeScreenActivity.class);
        startActivity(mIntent);
    }

    @Override
    public void onActivityResult(int mRequestCode, int mResultCode, Intent mData) {
        super.onActivityResult(mRequestCode, mResultCode, mData);
        if (mRequestCode == DEFAULT_DIALER && mResultCode == RESULT_OK)
            onFinish();
    }

    private boolean isDefaultDialerApp() {
        TelecomManager mManager = (TelecomManager) getSystemService(TELECOM_SERVICE);
        if (mManager != null)
            return getPackageName().equals(mManager.getDefaultDialerPackage());
        return false;
    }
}