package com.callfence.android.about;

import android.annotation.SuppressLint;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.callfence.android.R;
import com.callfence.android.utilities.helpers.ui.UIHelper;

public class AboutAppActivity extends AppCompatActivity {

    @SuppressLint("SetTextI18n")
    @SuppressWarnings("ConstantConditions")
    @Override
    protected void onCreate(@Nullable Bundle mSavedInstanceState) {
        super.onCreate(mSavedInstanceState);
        setContentView(R.layout.ac_about_application);

        // Set up toolbar
        Toolbar mToolbar = findViewById(R.id.tbToolbar);
        if (mToolbar != null) {
            setSupportActionBar(mToolbar);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("About");
        }

        // Populate app version
        TextView mAppVersion = findViewById(R.id.tvAppVersion);
        try {
            PackageInfo mInfo = this.getPackageManager().getPackageInfo(getPackageName(), 0);
            mAppVersion.setOnLongClickListener(mView -> {
                UIHelper.getPackageData(this);
                return true;
            });
            mAppVersion.setText("Version " + mInfo.versionName);
        } catch (PackageManager.NameNotFoundException mException) {
            mAppVersion.setText("Version: Unknown");
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem mItem) {
        finish();
        return super.onOptionsItemSelected(mItem);
    }

    @Override
    public void onBackPressed() {
        finish();
    }
}
