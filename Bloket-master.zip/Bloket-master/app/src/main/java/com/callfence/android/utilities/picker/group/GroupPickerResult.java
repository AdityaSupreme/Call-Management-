package com.callfence.android.utilities.picker.group;

import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable;

import com.callfence.android.groups.GroupDataPair;

import java.util.ArrayList;

public class GroupPickerResult implements Parcelable {

    public static final Creator<GroupPickerResult> CREATOR = new Creator<GroupPickerResult>() {
        @Override
        public GroupPickerResult createFromParcel(Parcel mParcel) {
            return new GroupPickerResult(mParcel);
        }

        @Override
        public GroupPickerResult[] newArray(int mSize) {
            return new GroupPickerResult[mSize];
        }
    };
    private String mGroupId, mGroupName;

    private GroupPickerResult(GroupDataPair mDataPair) {
        this.mGroupId = mDataPair.getGroupId();
        this.mGroupName = mDataPair.getGroupName();
    }

    private GroupPickerResult(Parcel mParcel) {
        this.mGroupId = mParcel.readString();
        this.mGroupName = mParcel.readString();
    }

    static ArrayList<GroupPickerResult> buildResult(ArrayList<GroupDataPair> mGroups) {
        ArrayList<GroupPickerResult> mResult = new ArrayList<>();
        for (GroupDataPair mGroup : mGroups) {
            mResult.add(new GroupPickerResult(mGroup));
        }
        return mResult;
    }

    public static ArrayList<GroupPickerResult> obtainResult(Intent mData) {
        return mData.getParcelableArrayListExtra(GroupPickerActivity.RESULT);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel mParcel, int mFlags) {
        mParcel.writeString(this.mGroupId);
        mParcel.writeString(this.mGroupName);
    }

    public String getGroupId() {
        return mGroupId;
    }

    public String getGroupName() {
        return mGroupName;
    }
}