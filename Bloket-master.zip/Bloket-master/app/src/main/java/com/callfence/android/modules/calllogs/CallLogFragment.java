package com.callfence.android.modules.calllogs;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.callfence.android.R;
import com.callfence.android.utilities.events.RefreshCallLogEvent;
import com.callfence.android.utilities.helpers.observers.CallLogObserver;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

public class CallLogFragment extends Fragment {

    private CallLogAdapter mAdapter;
    private RecyclerView mRecyclerView;

    public static CallLogFragment newInstance() {
        return new CallLogFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater mInflater, @Nullable ViewGroup mContainer, @Nullable Bundle mSavedInstance) {
        View mView = mInflater.inflate(R.layout.fm_calllogs_layout, mContainer, false);
        mRecyclerView = mView.findViewById(R.id.rvRecyclerView);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        return mView;
    }

    @Override
    public void onStart() {
        super.onStart();
        EventBus.getDefault().register(this);
    }

    @SuppressWarnings("ConstantConditions")
    @Override
    public void onResume() {
        super.onResume();
        if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED ||
                ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
            return;

        if (mAdapter == null || CallLogObserver.isCtsChanged(getContext())) loadCallLogs();
    }

    @Override
    public void onStop() {
        EventBus.getDefault().unregister(this);
        super.onStop();
    }

    @SuppressWarnings("unused")
    @Subscribe(threadMode = ThreadMode.POSTING)
    public void onMessageEvent(RefreshCallLogEvent mEvent) {
        if (mEvent.mRefresh) loadCallLogs();
    }

    @SuppressWarnings("ConstantConditions")
    private void loadCallLogs() {
        CallLogTask mAsyncTask = new CallLogTask(getContext(), mCallList -> {
            mAdapter = new CallLogAdapter(getContext(), mCallList);
            mRecyclerView.setAdapter(mAdapter);
        });
        mAsyncTask.execute();
    }
}