package com.callfence.android.homescreen;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.PersistableBundle;
import android.preference.PreferenceManager;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.telecom.TelecomManager;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.balysv.materialmenu.MaterialMenuDrawable;
import com.callfence.android.R;
import com.callfence.android.about.AboutAppActivity;
import com.callfence.android.appintro.AppIntroActivity;
import com.callfence.android.groups.GroupActivity;
import com.callfence.android.groups.GroupRemovalTask;
import com.callfence.android.modules.blacklist.BlacklistFragment;
import com.callfence.android.modules.contacts.ContactsFragment;
import com.callfence.android.modules.whitelist.WhitelistFragment;
import com.callfence.android.preferences.BlockPreferences;
import com.callfence.android.utilities.helpers.observers.CallLogObserver;
import com.callfence.android.utilities.helpers.observers.ContactObserver;
import com.callfence.android.utilities.helpers.ui.UIHelper;
import com.github.florent37.singledateandtimepicker.dialog.DoubleDateAndTimePickerDialog;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.analytics.FirebaseAnalytics;

public class HomeScreenActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private ActionBarDrawerToggle mDrawerToggle;
    private DrawerLayout mDrawerLayout;
    private FloatingActionButton mFloatingButton;
    public FirebaseAnalytics mFirebaseAnalytics;
    private SharedPreferences mPreferences;
    private TextView mActionHint;
    private ViewPager mViewPager;

    @SuppressWarnings("ConstantConditions")
    @Override
    protected void onCreate(@Nullable Bundle mSavedInstanceState) {
        super.onCreate(mSavedInstanceState);

        // Start app intro
        mPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        if (!mPreferences.getBoolean("BL_PF_INTRO", false)) {
            Intent intent = new Intent(this, AppIntroActivity.class);
            startActivity(intent);
            this.finish();
        } else {

            // Set up layout
            setContentView(R.layout.ac_main_layout);

            // Set up appbar animation
            mActionHint = findViewById(R.id.tvActionHint);
            AppBarLayout mAppBarLayout = findViewById(R.id.mpAppBar);
            mAppBarLayout.addOnOffsetChangedListener((mLayout, mOffset) -> {
                if (mActionHint != null && mViewPager != null && mViewPager.getCurrentItem() > 2) {
                    if (mOffset < -24) {
                        mActionHint.animate().alpha(0.0f);
                        mActionHint.setVisibility(View.INVISIBLE);
                    } else {
                        mActionHint.setVisibility(View.VISIBLE);
                        mActionHint.animate().alpha(1.0f).setDuration(500);
                    }
                }
            });

            // Set up toolbar
            Toolbar mToolbar = findViewById(R.id.mpToolbar);
            if (mToolbar != null) {
                setSupportActionBar(mToolbar);
                getSupportActionBar().setDisplayShowTitleEnabled(false);
            }

            // Set up hamburger menu
            MaterialMenuDrawable mMaterialMenu = new MaterialMenuDrawable(this, Color.WHITE, MaterialMenuDrawable.Stroke.THIN);
            mMaterialMenu.setTransformationDuration(350);
            if (mToolbar != null) mToolbar.setNavigationIcon(mMaterialMenu);

            // Set up drawer layout
            mDrawerLayout = findViewById(R.id.mpDrawerLayout);
            mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, mToolbar, R.string.nv_drawer_open, R.string.nv_drawer_close) {
            };
            mDrawerLayout.addDrawerListener(mDrawerToggle);

            // Set up navigation view
            NavigationView mNavigationView = findViewById(R.id.mpNavigationView);
            mNavigationView.setNavigationItemSelectedListener(this);

            // Floating action button
            mFloatingButton = findViewById(R.id.mpFabButton);

            // Set up viewpager
            setViewPager();

            // Open call logs if coming from notification action
            Bundle mIntentExtras = getIntent().getExtras();
            if (mIntentExtras != null && mIntentExtras.containsKey("BL_OPEN_CALL_LOGS")) {
                SharedPreferences.Editor mEditor = mPreferences.edit();
                mEditor.putBoolean("BL_OPEN_CALL_LOGS", true);
                mEditor.apply();
            }

            // Register contact change observer
            if (checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED)
                getContentResolver().registerContentObserver(
                        ContactsContract.Contacts.CONTENT_URI, true,
                        new ContactObserver(this, new Handler()));

            // Register call log change observer
            if (checkSelfPermission(Manifest.permission.READ_CALL_LOG) == PackageManager.PERMISSION_GRANTED)
                getContentResolver().registerContentObserver(
                        CallLog.Calls.CONTENT_URI, true,
                        new CallLogObserver(this, new Handler()));

            // Set up firebase analytics
            mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        }
    }

    @Override
    public void onPostCreate(@Nullable Bundle mBundle, @Nullable PersistableBundle mState) {
        super.onPostCreate(mBundle, mState);
        mDrawerToggle.syncState();
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Check if permission required
        boolean mPermissionsRequired;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            mPermissionsRequired = checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED ||
                    checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED ||
                    checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED ||
                    checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED ||
                    checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED ||
                    checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED ||
                    checkSelfPermission(Manifest.permission.WRITE_CALL_LOG) != PackageManager.PERMISSION_GRANTED ||
                    checkSelfPermission(Manifest.permission.WRITE_CONTACTS) != PackageManager.PERMISSION_GRANTED;
        } else {
            mPermissionsRequired = checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED ||
                    checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED ||
                    checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED ||
                    checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED ||
                    checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED ||
                    checkSelfPermission(Manifest.permission.WRITE_CALL_LOG) != PackageManager.PERMISSION_GRANTED ||
                    checkSelfPermission(Manifest.permission.WRITE_CONTACTS) != PackageManager.PERMISSION_GRANTED;
        }

        // Ask for permission if required
        if (mPermissionsRequired) {
            Intent mIntent = new Intent(this, AppIntroActivity.class);
            mIntent.putExtra("BL_NEEDS_PERMISSION", true);
            startActivity(mIntent);
            return;
        }

        // Check if we are returning from a call
        if (mPreferences == null)
            mPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        if (mViewPager != null && mPreferences.getBoolean("BL_OPEN_CALL_LOGS", false)) {
            mViewPager.setCurrentItem(2, false);
            SharedPreferences.Editor mEditor = mPreferences.edit();
            mEditor.putBoolean("BL_OPEN_CALL_LOGS", false);
            mEditor.apply();
        }

        // Check and set as default handler
        setDefaultHandler();

        // Run group removal task
        new GroupRemovalTask(this).execute();
    }

    @Override
    public void onBackPressed() {
        if (mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            mDrawerLayout.closeDrawer(GravityCompat.START);
        } else {
            if (isPickerVisible()) return;
            super.onBackPressed();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem mItem) {
        if (mDrawerToggle.onOptionsItemSelected(mItem)) {
            return true;
        }
        return super.onOptionsItemSelected(mItem);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem mItem) {
        switch (mItem.getItemId()) {
            case R.id.mnManageGroups:
                startActivity(new Intent(this, GroupActivity.class));
                break;

            case R.id.mnBlockSettings:
                startActivity(new Intent(this, BlockPreferences.class));
                break;

            case R.id.mnSendFeedback:
                try {
                    Intent mIntent = new Intent(Intent.ACTION_SENDTO);
                    mIntent.setData(Uri.parse("mailto:"));
                    mIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{"callfence@docuta.com"});
                    mIntent.putExtra(Intent.EXTRA_SUBJECT, "CallFence - User feedback");
                    startActivity(Intent.createChooser(mIntent, "Send feedback ..."));
                } catch (android.content.ActivityNotFoundException ex) {
                    Toast.makeText(this, "No e-mail clients available.", Toast.LENGTH_SHORT).show();
                }
                break;

            case R.id.mnContactUs:
                try {
                    Intent mIntent = new Intent(Intent.ACTION_SENDTO);
                    mIntent.setData(Uri.parse("mailto:"));
                    mIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{"callfence@docuta.com"});
                    mIntent.putExtra(Intent.EXTRA_SUBJECT, "CallFence - Help");
                    startActivity(Intent.createChooser(mIntent, "Send email ..."));
                } catch (android.content.ActivityNotFoundException ex) {
                    Toast.makeText(this, "No e-mail clients available.", Toast.LENGTH_SHORT).show();
                }
                break;

            case R.id.mnRatePlayStore:
                try {
                    Uri mPlayStoreUri = Uri.parse("market://details?id=" + this.getPackageName());
                    Intent mIntent = new Intent(Intent.ACTION_VIEW, mPlayStoreUri);
                    mIntent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY | Intent.FLAG_ACTIVITY_NEW_DOCUMENT | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
                    startActivity(mIntent);
                } catch (ActivityNotFoundException e) {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + this.getPackageName())));
                }
                break;

            case R.id.mnAboutApp:
                startActivity(new Intent(this, AboutAppActivity.class));
                break;

            case R.id.mnPrivacyPolicy:
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://docuta.com/callfence/privacy-policy.html")));
                break;

            case R.id.mnTermsOfUse:
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://docuta.com/callfence/terms-and-conditions.html")));
                break;

            default:
                break;
        }
        mDrawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @SuppressWarnings("ConstantConditions")
    private void setViewPager() {

        // Set up pager adapter
        mViewPager = findViewById(R.id.mpViewPager);
        HomeScreenAdapter mAdapter = new HomeScreenAdapter(getSupportFragmentManager());
        mViewPager.setAdapter(mAdapter);
        mViewPager.setOffscreenPageLimit(4);
        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int mPosition, float mPosOffset, int mPosOffsetPixels) {
                UIHelper.hideSoftKeyboard(getApplicationContext(), mViewPager);
            }

            @SuppressLint("RestrictedApi")
            @Override
            public void onPageSelected(int mPosition) {
                switch (mPosition) {
                    case 1:
                        if (mFloatingButton != null) {
                            mActionHint.setVisibility(View.GONE);
                            mFloatingButton.setImageResource(R.drawable.ic_fab_contact);
                            mFloatingButton.setVisibility(View.VISIBLE);
                        }
                        break;

                    case 3:
                        if (mFloatingButton != null) {
                            mActionHint.setText(getString(R.string.gr_hint_blacklist));
                            mActionHint.setVisibility(View.VISIBLE);
                            mFloatingButton.setImageResource(R.drawable.ic_fab_blacklist);
                            mFloatingButton.setVisibility(View.VISIBLE);
                        }
                        break;

                    case 4:
                        if (mFloatingButton != null) {
                            mActionHint.setText(getString(R.string.gr_hint_whitelist));
                            mActionHint.setVisibility(View.VISIBLE);
                            mFloatingButton.setImageResource(R.drawable.ic_fab_whitelist);
                            mFloatingButton.setVisibility(View.VISIBLE);
                        }
                        break;

                    default:
                        if (mFloatingButton != null) {
                            mActionHint.setVisibility(View.GONE);
                            mFloatingButton.setVisibility(View.GONE);
                        }
                        break;
                }
            }

            @Override
            public void onPageScrollStateChanged(int mState) {
            }
        });

        // Set up tabs
        TabLayout mTabLayout = findViewById(R.id.mpTabLayout);
        mTabLayout.setupWithViewPager(mViewPager);
        mTabLayout.getTabAt(0).setIcon(R.drawable.ic_tab_dialer);
        mTabLayout.getTabAt(1).setIcon(R.drawable.ic_tab_contacts);
        mTabLayout.getTabAt(2).setIcon(R.drawable.ic_tab_blocklogs);
        mTabLayout.getTabAt(3).setIcon(R.drawable.ic_tab_blacklist);
        mTabLayout.getTabAt(4).setIcon(R.drawable.ic_tab_whitelist);

        // Set up tab icon color
        mTabLayout.getTabAt(0).getIcon().setColorFilter(ContextCompat.getColor(getApplicationContext(), R.color.colorAccent), PorterDuff.Mode.MULTIPLY);
        mTabLayout.getTabAt(1).getIcon().setColorFilter(ContextCompat.getColor(getApplicationContext(), R.color.colorWhitePressed), PorterDuff.Mode.MULTIPLY);
        mTabLayout.getTabAt(2).getIcon().setColorFilter(ContextCompat.getColor(getApplicationContext(), R.color.colorWhitePressed), PorterDuff.Mode.MULTIPLY);
        mTabLayout.getTabAt(3).getIcon().setColorFilter(ContextCompat.getColor(getApplicationContext(), R.color.colorWhitePressed), PorterDuff.Mode.MULTIPLY);
        mTabLayout.getTabAt(4).getIcon().setColorFilter(ContextCompat.getColor(getApplicationContext(), R.color.colorWhitePressed), PorterDuff.Mode.MULTIPLY);

        // Set up tab listener
        mTabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab mTab) {
                mTab.getIcon().setColorFilter(ContextCompat.getColor(getApplicationContext(), R.color.colorAccent), PorterDuff.Mode.MULTIPLY);
            }

            @Override
            public void onTabUnselected(TabLayout.Tab mTab) {
                mTab.getIcon().setColorFilter(ContextCompat.getColor(getApplicationContext(), R.color.colorWhitePressed), PorterDuff.Mode.MULTIPLY);
            }

            @Override
            public void onTabReselected(TabLayout.Tab mTab) {

            }
        });
    }

    private void setDefaultHandler() {
        TelecomManager mManager = (TelecomManager) getSystemService(TELECOM_SERVICE);
        if (mManager != null && !getPackageName().equals(mManager.getDefaultDialerPackage())) {
            Intent mIntent = new Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER);
            mIntent.putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, getPackageName());
            startActivity(mIntent);
        }
    }

    private boolean isPickerVisible() {
        try {
            if (mViewPager == null) return false;
            String mFragmentTag = "android:switcher:" + R.id.mpViewPager + ":" + mViewPager.getCurrentItem();
            Fragment mFragment = getSupportFragmentManager().findFragmentByTag(mFragmentTag);
            switch (mViewPager.getCurrentItem()) {
                case 3:
                    if (mFragment == null) return false;
                    DoubleDateAndTimePickerDialog mBlPickerDialog = ((BlacklistFragment) mFragment).mPickerDialog;
                    if (mBlPickerDialog != null && mBlPickerDialog.isDisplaying()) {
                        mBlPickerDialog.close();
                        return true;
                    }
                    return false;

                case 4:
                    if (mFragment == null) return false;
                    DoubleDateAndTimePickerDialog mWlPickerDialog = ((WhitelistFragment) mFragment).mPickerDialog;
                    if (mWlPickerDialog != null && mWlPickerDialog.isDisplaying()) {
                        mWlPickerDialog.close();
                        return true;
                    }
                    return false;

                default:
                    return false;
            }
        } catch (Exception mException) {
            Log.d("BLOKET_LOGS", "HomeScreenActivity: Attempting to close date & time picker" + mException);
            return false;
        }
    }

    public void fabClickAction(View mView) {
        try {
            if (mViewPager == null) return;
            String mFragmentTag = "android:switcher:" + R.id.mpViewPager + ":" + mViewPager.getCurrentItem();
            Fragment mFragment = getSupportFragmentManager().findFragmentByTag(mFragmentTag);
            switch (mViewPager.getCurrentItem()) {
                case 1:
                    if (mFragment != null) ((ContactsFragment) mFragment).fabClickAction();
                    break;

                case 3:
                    if (mFragment != null) ((BlacklistFragment) mFragment).fabClickAction();
                    break;

                case 4:
                    if (mFragment != null) ((WhitelistFragment) mFragment).fabClickAction();
                    break;

                default:
                    Toast.makeText(this, getString(R.string.gr_err_mesg), Toast.LENGTH_SHORT).show();
                    break;
            }
        } catch (Exception mException) {
            Log.d("BLOKET_LOGS", "HomeScreenActivity: " + mException);
        }
    }
}