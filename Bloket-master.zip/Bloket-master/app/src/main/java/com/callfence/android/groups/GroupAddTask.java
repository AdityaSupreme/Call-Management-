package com.callfence.android.groups;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.os.AsyncTask;

import com.callfence.android.utilities.helpers.database.DatabaseHelper;
import com.callfence.android.utilities.helpers.ui.UIHelper;
import com.callfence.android.utilities.picker.contact.ContactPickerIdNumber;
import com.callfence.android.utilities.picker.contact.ContactPickerResult;

import java.util.ArrayList;

public class GroupAddTask extends AsyncTask<Void, Void, Void> {

    private ArrayList<ContactPickerResult> mSelectedContacts;
    @SuppressLint("StaticFieldLeak")
    private Context mContext;
    private Dialog mProgressDialog;
    private GroupAddResponse mResponse;
    private String mGroupId, mGroupName;

    public GroupAddTask(Context mContext, String mGroupId, String mGroupName, ArrayList<ContactPickerResult> mSelectedContacts, GroupAddResponse mResponse) {
        this.mContext = mContext;
        this.mGroupId = mGroupId;
        this.mGroupName = mGroupName;
        this.mSelectedContacts = mSelectedContacts;
        this.mResponse = mResponse;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        mProgressDialog = UIHelper.makeProgressDialog(mContext);
        mProgressDialog.setOnCancelListener(mDialog -> GroupAddTask.this.cancel(true));
        mProgressDialog.show();
    }

    @Override
    protected Void doInBackground(Void... mVoid) {
        DatabaseHelper mDbHelper = new DatabaseHelper(mContext);
        ArrayList<ContactPickerIdNumber> mOldSelection = mDbHelper.getGroupListContact(mGroupId);
        ArrayList<ContactPickerIdNumber> mNewSelection = new ArrayList<>();
        for (ContactPickerResult mContact : mSelectedContacts)
            mNewSelection.add(new ContactPickerIdNumber(mContact.getContactId(), mContact.getPhoneNumber()));

        ArrayList<ContactPickerIdNumber> mIntersection = new ArrayList<>(mOldSelection);
        mIntersection.retainAll(mNewSelection);
        mNewSelection.removeAll(mIntersection);
        mOldSelection.removeAll(mIntersection);

        boolean isGroupBlacklisted = mDbHelper.chkBlacklistGroup(mGroupId);
        boolean isGroupWhitelisted = mDbHelper.chkWhitelistGroup(mGroupId);

        for (ContactPickerIdNumber mContact : mOldSelection) {
            if (mContact.getContactId() == null) continue;
            mDbHelper.delGroupListContact(mGroupId, mContact.getContactId(), mContact.getPhoneNumber());
            if (isGroupBlacklisted)
                mDbHelper.delBlacklistGroupItem(mGroupId, mContact.getContactId(), mContact.getPhoneNumber());
            if (isGroupWhitelisted)
                mDbHelper.delWhitelistGroupItem(mGroupId, mContact.getContactId(), mContact.getPhoneNumber());
        }
        for (ContactPickerIdNumber mContact : mNewSelection) {
            if (mContact.getContactId() == null) continue;
            mDbHelper.putGroupList(mGroupId, mGroupName, mContact.getContactId(), mContact.getPhoneNumber());
            if (isGroupBlacklisted)
                mDbHelper.putBlacklistData(DatabaseHelper.BW_ENTRY_TYPE_GROUP, mGroupId, mGroupName, mContact.getContactId(), mContact.getPhoneNumber(), "", "", "", "");
            if (isGroupWhitelisted)
                mDbHelper.putWhitelistData(DatabaseHelper.BW_ENTRY_TYPE_GROUP, mGroupId, mGroupName, mContact.getContactId(), mContact.getPhoneNumber(), "", "", "");
        }
        return null;
    }

    @Override
    protected void onPostExecute(Void mVoid) {
        if (mProgressDialog.isShowing()) mProgressDialog.dismiss();
        mResponse.onTaskCompletion(true);
    }

    public interface GroupAddResponse {

        void onTaskCompletion(boolean mSuccess);

    }
}